# Voice agent provider matrix — 3 Nov 2026

## What was run

- The 30 scripted scenarios were expanded into **37 scored utterances** by running the explicit variants in cases 29 and 30 separately.
- Each utterance was sent to the live intent classifier under four profiles: Gemini Flash Lite, OpenAI Luna standard, OpenAI Luna Fast, and OpenAI Terra standard. Each run used the same transcript and state label, a fixed local reference date of 3 Nov 2026, and no retries.
- Deepgram and Sarvam STT were each run on four supplied WAV files. Deepgram and Sarvam TTS were each streamed for three fixed response samples.
- This keeps the component comparisons interpretable: the LLM sees a transcript; STT and TTS are measured independently. **It is not a full 30-call end-to-end voice run.** No real bank, OTP, transfer, or customer data action was executed.
- Strict intent accuracy means exact agreement with the expected intent label. For scenarios whose next answer is determined by a pending slot, the gold label can differ from the broad intent (for example, a reply of “Net banking” is an answer in the `paid_mode` state). Treat the case examples and dialogue context alongside the strict score.

## LLM classifier results

| LLM profile | Exact intent labels | Mean classifier time | Median | p95 | Errors/timeouts |
|---|---:|---:|---:|---:|---:|
| Gemini `gemini-3.5-flash-lite` | 27/37 (73.0%) | 1.63 s | 1.59 s | 2.14 s | 0 |
| OpenAI `gpt-6-luna`, standard | 33/37 (89.2%) | 1.99 s | 1.73 s | 3.80 s | 0 |
| OpenAI `gpt-6-luna`, Fast | 31/37 (83.8%) | 1.54 s | 1.53 s | 1.83 s | 0 |
| OpenAI `gpt-6.1-terra`, standard | 34/37 (91.9%) | 2.15 s | 2.15 s | 2.41 s | 0 |

### Requested LLM × speech combinations

The LLM result repeats across speech providers because the same transcript is passed to the classifier. The voice-side metrics are specific to the selected speech stack.

| Combination | LLM exact labels / mean | STT mean | TTS first audio / completion | Run status |
|---|---:|---:|---:|---|
| Gemini Flash Lite + Deepgram | 27/37; 1.63 s | 174 ms | 217 ms / 2.44 s | sequential retry completed; 2 high-risk identity label errors |
| Gemini Flash Lite + Sarvam | 27/37; 1.63 s | 194 ms | 234 ms / 0.92 s | sequential retry completed; 2 high-risk identity label errors |
| OpenAI Luna standard + Deepgram | 33/37; 1.99 s | 174 ms | 217 ms / 2.44 s | completed |
| OpenAI Luna standard + Sarvam | 33/37; 1.99 s | 194 ms | 234 ms / 0.92 s | completed |
| OpenAI Luna Fast + Sarvam | 31/37; 1.54 s | 194 ms | 234 ms / 0.92 s | completed |
| OpenAI Terra standard + Deepgram | 34/37; 2.15 s | 174 ms | 217 ms / 2.44 s | completed |
| OpenAI Terra standard + Sarvam | 34/37; 2.15 s | 194 ms | 234 ms / 0.92 s | completed |

“Mean classifier time” is the model request duration in this harness; prompt construction and response parsing were negligible in the existing app timing design. The OpenAI numbers include the provider request and network transit. Fast was about 454 ms faster than Luna standard on this run, with two fewer exact labels. Terra was the most accurate exact-label profile here, but took about 612 ms longer than Fast on average. This sample is small and single-run; it is not a stable service-level benchmark.

### Misses and interpretation

- Gemini made two high-risk identity-status errors: before the named identity question, it labeled both “Yes” and “I'm Asha Mehta” as confirmed. The deterministic policy fixture blocks account disclosure before that question, but the classifier result is still wrong and requires the state gate to remain authoritative. Other Gemini misses: “Net banking” in the `paid_mode` slot was labeled tentative commitment; “I think so” during the old-payment recency check was labeled promise-to-pay; “Concern” after a refusal was labeled distress; “Okay, tell me” was labeled a payment question.
- Luna standard: three strict-label differences — “Net banking” during payment-mode collection was labeled `payment_method_question`; “Yes” / “I think so” during the old-payment recency check were labeled `unclear`; “What is this interest for?” was labeled `related_question` instead of `interest_question`.
- Luna Fast: the same state/context differences plus “Yeah, you are” and the Hinglish identity response were labeled `other_product` while the structured identity status was still `confirmed`.
- Terra: “I’m not sure” during the old-payment recency check was `unclear`; “My balance is only ₹5,000” was `unclear`; the interest question was `related_question` rather than `interest_question`.
- Gemini had two incorrect identity labels among the 12 cases tagged high-risk traps. OpenAI profiles had zero wrong exact labels in those 12 cases in this run. These are classifier results only; they do not prove that the spoken response or side effect was correct.
- The first parallel Gemini pass failed with 504 deadline and 429 quota responses. Retrying sequentially completed all 37 requests with no errors; 73.0% is the usable Gemini score.

## Speech results

### STT

| Provider | Mean latency (4 clips) | Observed output summary | Accuracy score |
|---|---:|---|---|
| Deepgram Nova-3 | 174 ms | One blank transcript; other clips returned Hindi/Arabic-script text, including outputs that differed from the caller’s reported English/Hinglish intent. | Not scored: reliable references are not available for all four clips. On the clip identified as “Concern,” output was blank. |
| Sarvam Saaras v4 (`translate` mode) | 194 ms | Returned “Pansan.” for the clip identified as “Concern”; other short clips produced different English paraphrases. | Not scored: reliable references are not available for all four clips. “Concern” was not preserved. |

The supplied recordings are short utterances and do not form a representative noise/accent corpus. The two STT services produced materially different hypotheses on the same clips, confirming that upstream recognition is a source of the observed failures. Sarvam is configured in `translate` mode, so its output is intended to translate toward English rather than preserve the original wording. The raw outputs and user-reported references are in the JSON artifact.

### TTS

Three fixed responses per provider; text length ranged from 77 to 111 characters.

| Provider / configured voice | Mean first audio | Mean stream completion |
|---|---:|---:|
| Deepgram Flux Naveen English | 217 ms | 2.44 s |
| Sarvam Bulbul v4 Flash, Sunny | 234 ms | 0.92 s |

Both streams began audio at similar times. Sarvam completed these short samples faster. This is timing only; no blinded listener rating of accent, pronunciation, or naturalness was performed.

## Policy and risk checks

The separate deterministic policy regression was rerun on the existing 15-case assignment harness:

| Policy fixture | Passed | Failed | Failure rate |
|---|---:|---:|---:|
| V1 local fast-path baseline | 11/15 | 4 | 26.7% |
| V2 golden-intent policy candidate | 14/15 | 1 | 6.7% |

Both versions passed the fixture checks for exact approved due facts (3.5% monthly interest, ₹750 fee conditional on balance over ₹10,000), opt-out, distress/abuse transfer, dispute pause, OTP on explicit balance request, and no OTP on an OTP-only request. The remaining V2 failure is the payment-link fixture, which returned no response in the evaluator. This harness injects expected intent for V2, so the V2 score is a policy-path ceiling, **not a live LLM result**.

### Requested risk buckets

- **Factual mistakes (rates / fees):** no wrong value was found in the deterministic policy fixture; this is one due-notice assertion, not a broad factual QA evaluation. LLM classifier output does not generate the due figures.
- **Compliance violations:** no violation was detected in the limited deterministic fixtures for OTP, opt-out, hardship/abuse, dispute, CIBIL/legal classification. Full live spoken-response compliance was not tested.
- **Scope drift:** OpenAI profiles correctly labeled the explicit new-loan/FD and unrelated-topic trap utterances in the classifier run. This checks labels, not the final answer’s wording.
- **Adherence / transfer failure:** distress, abuse, and dispute were classified correctly in the OpenAI high-risk cases; the deterministic policy fixture passed transfer/pause checks. No real transfer connector was called.

## Artifacts and limitations

- Full per-turn data: [`provider_matrix_results_2026-11-03.json`](provider_matrix_results_2026-11-03.json)
- Reproducible test-only runner: [`run_provider_matrix.py`](run_provider_matrix.py)
- Sequential Gemini retry runner: [`retry_gemini_matrix.py`](retry_gemini_matrix.py)
- Policy fixture results: [`assignment_eval_results.json`](assignment_eval_results.json)
- The combination names (for example Gemini–Deepgram versus Gemini–Sarvam) share the same LLM classifier score because the speech service does not change the text sent to the classifier. Their STT/TTS component metrics are shown separately; no complete call was replayed through all provider pairings.
- Provider timings vary with region, congestion, quota, warm-up, and account tier. This one-run sample is diagnostic, not a production SLA.
