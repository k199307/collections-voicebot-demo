"""Offline, test-only assignment evaluation of the conversation policy.

This deliberately leaves application source untouched. V1 exercises the real
policy with the shipped local fast classifier (and its normal fallback when
that classifier returns None). Candidate V2 replays the same turns with golden
structured intent outputs to measure the policy's behavior when the intent
contract is satisfied. V2 is a classifier/prompt experiment, not a live-model
or production-code result.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from collections_bot.conversation import process_otp_code, process_turn
from collections_bot.providers import fast_classify_utterance
from collections_bot.schemas import CallSession, StartCallRequest


def make_session(*, identity=False, pending=None):
    request = StartCallRequest(
        case_id=f"eval-{uuid4().hex[:8]}", episode_id="episode-eval",
        customer_id="customer-eval", account_id="account-eval",
        contact_point_id="contact-eval", timezone="Asia/Kolkata",
        first_name="Asha", last_name="Mehta", days_past_due=8,
        eligibility_confirmed=True, contact_allowed=True,
        contact_policy_version="assignment-eval-v1",
        masked_account_reference="****1234",
    )
    session = CallSession(
        session_id=uuid4(), attempt_id=uuid4(), request=request,
        started_at=datetime.now(timezone.utc), pending=pending,
        scratch={"right_party_confirmed": identity},
    )
    if pending == "identity_confirmation":
        session.scratch.update({
            "identity_opening_delivered": True,
            "awaiting_identity_confirmation": True,
        })
    return session


def intent(intent, *, confidence="high", dialogue="no_clear_act", **values):
    return {
        "intent": intent, "intent_confidence": confidence,
        "amount_inr": None, "date_iso": None, "payment_mode": None,
        "summary": "Scripted evaluation intent", "dialogue_act": dialogue,
        "pending_slot_status": "not_applicable", "date_precision": "none",
        "date_phrase": None, "identity_status": "unclear", "acknowledgment": "",
        **values,
    }


SCENARIOS = [
    {
        "id": "S01", "name": "Identity confirmation and factual due disclosure", "source": "Brief",
        "utterance": "Haan, main Asha Mehta hoon.", "state": {"pending": "identity_confirmation"},
        "v2": intent("unclear", dialogue="answers_pending", identity_status="confirmed"),
        "check": "identity_disclosed_correctly",
    },
    {
        "id": "S02", "name": "Pre-opening yes is not identity confirmation", "source": "Inferred",
        "utterance": "Yes.", "state": {"pending": "identity_confirmation", "heard_before_opening": True},
        "v2": intent("unclear", dialogue="answers_pending", identity_status="confirmed"),
        "check": "no_disclosure_before_named_prompt",
    },
    {
        "id": "S03", "name": "Wrong number", "source": "Inferred",
        "utterance": "Wrong number.", "state": {"pending": "identity_confirmation"},
        "v2": intent("unclear", dialogue="answers_pending", identity_status="not_confirmed"),
        "check": "end_without_account_disclosure",
    },
    {
        "id": "S04", "name": "Already paid with exact date and mode", "source": "Brief",
        "utterance": "I paid by UPI on 1 November 2026.", "state": {"identity": True, "pending": "paid_date"},
        "v2": intent("already_paid", dialogue="answers_pending", date_iso="2026-11-01", payment_mode="UPI", date_precision="exact"),
        "check": "reconcile_then_two_working_days",
    },
    {
        "id": "S05", "name": "Approximate date and cannot recall", "source": "Inferred",
        "utterance": "About six or seven days ago.", "state": {"identity": True, "pending": "paid_date"},
        "v2": intent("already_paid", dialogue="answers_pending", date_precision="approximate", date_phrase="six or seven days ago", pending_slot_status="provided"),
        "second": ("I don’t remember.", intent("already_paid", dialogue="cannot_provide", pending_slot_status="cannot_provide")),
        "check": "no_guessed_date_and_manual_followup",
    },
    {
        "id": "S06", "name": "Clear commitment with volunteered amount", "source": "Brief",
        "utterance": "I will pay ₹2,000 by 6 November 2026.", "state": {"identity": True, "pending": "ptp"},
        "v2": intent("promise_to_pay", date_iso="2026-11-06", amount_inr="2000"),
        "check": "date_only_confirmation_no_amount_prompt",
    },
    {
        "id": "S07", "name": "Tentative willingness is not a commitment", "source": "Inferred",
        "utterance": "I may be okay to pay.", "state": {"identity": True},
        "v2": intent("payment_commitment_interest", confidence="medium"),
        "check": "clarify_without_recording_commitment",
    },
    {
        "id": "S08", "name": "Payment not made yet", "source": "Brief",
        "utterance": "I haven’t paid yet.", "state": {"identity": True},
        "v2": intent("payment_not_made", dialogue="answers_pending"),
        "check": "ask_reason_or_expected_date_not_record_ptp",
    },
    {
        "id": "S09", "name": "Late-fee waiver request", "source": "Brief",
        "utterance": "Please waive the late fee.", "state": {"identity": True},
        "v2": intent("waiver", dialogue="new_request"),
        "check": "no_approval_human_callback",
    },
    {
        "id": "S10", "name": "Medical emergency or job loss", "source": "Brief",
        "utterance": "I lost my job and can’t pay.", "state": {"identity": True},
        "v2": intent("distress", dialogue="new_request"),
        "check": "stop_pitch_and_human_transfer",
    },
    {
        "id": "S11", "name": "Abusive caller", "source": "Brief",
        "utterance": "This is bullshit, shut up.", "state": {"identity": True},
        "v2": intent("abuse", dialogue="new_request"),
        "check": "stop_pitch_and_human_transfer",
    },
    {
        "id": "S12", "name": "Debt dispute", "source": "Brief",
        "utterance": "This isn’t my account; I dispute it.", "state": {"identity": True},
        "v2": intent("dispute", dialogue="new_request"),
        "check": "pause_collection_and_human_review",
    },
    {
        "id": "S13", "name": "Opt out", "source": "Inferred",
        "utterance": "Stop calling me.", "state": {"identity": True},
        "v2": intent("opt_out", dialogue="new_request"),
        "check": "record_opt_out_and_end",
    },
    {
        "id": "S14", "name": "Payment link and unsupported payment process", "source": "Inferred",
        "utterance": "Send me a payment link.", "state": {"identity": True},
        "v2": intent("payment_link_request", dialogue="new_request"),
        "second": ("Can I pay in cash?", intent("payment_method_question", dialogue="asks_question")),
        "check": "record_link_followup_then_defer_unknown_method",
    },
    {
        "id": "S15", "name": "Balance, OTP trap, and unrelated topic", "source": "Brief + inferred",
        "utterance": "What is my balance?", "state": {"identity": True},
        "v2": intent("balance_question", dialogue="asks_question", summary="The caller asks for their balance."),
        "second": ("Can you send me the OTP?", intent("otp_request", dialogue="asks_question")),
        "check": "otp_only_for_explicit_balance_and_no_unrelated_answer",
    },
]


def _trace_rules(session):
    return [entry.get("rule") for entry in session.scratch.get("decision_trace", []) if entry.get("status") in {"triggered", "selected", "confirmed"}]


def run_one(scenario, version):
    state = scenario["state"]
    session = make_session(identity=state.get("identity", False), pending=state.get("pending"))
    if version == "v1-fast-path-baseline":
        extracted = fast_classify_utterance(scenario["utterance"], session.pending, "2026-11-02")
    else:
        extracted = scenario["v2"].copy()
    kwargs = {"heard_before_opening": state.get("heard_before_opening", False)}
    record = {"id": scenario["id"], "name": scenario["name"], "source": scenario["source"], "version": version}
    with (
        patch("collections_bot.conversation.create_followup_task", return_value={"task_id": "task-eval"}),
        patch("collections_bot.conversation.bank_services.request_human_transfer", return_value={"transfer_id": "transfer-eval", "status": "queued"}),
        patch("collections_bot.conversation.bank_services.set_contact_preference"),
        patch("collections_bot.conversation.bank_services.issue_otp", return_value={"challenge_id": "otp-eval", "expires_at": "2026-11-02T00:05:00Z"}),
        patch("collections_bot.conversation.bank_services.reconcile_payment", return_value={"status": "confirmed", "payment_id": "pay-eval", "reference": "ref-eval"}),
        patch("collections_bot.conversation.bank_services.verify_otp", return_value={"verified": True, "verification_token": "token-eval"}),
        patch("collections_bot.conversation.bank_services.get_balance", return_value={"currency": "INR", "balance": "18500.00", "minimum_due": "1200.00", "due_date": "2026-11-02"}),
    ):
        response = process_turn(session, scenario["utterance"], extracted, **kwargs)
        if response is None:
            second_reply = None
            second_outcome = None
            if scenario.get("second"):
                utterance, second_extracted = scenario["second"]
                independent = make_session(identity=True)
                followup_response = process_turn(independent, utterance, second_extracted)
                if followup_response is not None:
                    second_reply = followup_response.bot_text
                    second_outcome = followup_response.outcome.type.value if followup_response.outcome else None
            record.update({
                "utterance": scenario["utterance"], "reply": "<no response returned>",
                "second_reply": second_reply, "outcome": session.outcome.type.value if session.outcome else None,
                "second_outcome": second_outcome, "rules": _trace_rules(session), "terminal": session.terminal,
                "passed": False,
            })
            return record
        first_text = response.bot_text
        first_terminal = response.terminal
        first_outcome = response.outcome.type.value if response.outcome else None
        first_rules = _trace_rules(session)
        second_text = None
        second_outcome = None
        second_rules = []
        if scenario.get("second") and not response.terminal:
            utterance, second_extracted = scenario["second"]
            if scenario["id"] == "S15" and session.pending == "otp_code":
                response = process_turn(session, utterance, second_extracted)
            else:
                response = process_turn(session, utterance, second_extracted)
            second_text = response.bot_text
            second_outcome = response.outcome.type.value if response.outcome else None
            second_rules = _trace_rules(session)
        if scenario["id"] == "S15" and session.pending == "otp_code":
            record["spoken_otp_reply"] = second_text
            balance_response = process_otp_code(session, "123456")
            record["verified_balance_reply"] = balance_response.bot_text
            record["verified_balance_outcome"] = balance_response.outcome.type.value if balance_response.outcome else None
        if scenario["id"] == "S15":
            otp_only_session = make_session(identity=True)
            otp_only_response = process_turn(otp_only_session, "Can you send me the OTP?", intent("otp_request", dialogue="asks_question"))
            record["otp_alone_not_issued"] = otp_only_session.pending != "otp_code" and "don’t need an otp" in otp_only_response.bot_text.casefold()
            unrelated_session = make_session(identity=True)
            unrelated_response = process_turn(unrelated_session, "What is the capital of India?", intent("unclear", confidence="low", dialogue="asks_question"))
            record["unrelated_declined"] = "can’t help with unrelated questions" in unrelated_response.bot_text.casefold()
        record.update({
            "utterance": scenario["utterance"], "reply": first_text,
            "second_reply": second_text, "outcome": first_outcome,
            "second_outcome": second_outcome,
            "outcome_fields": session.outcome.fields if session.outcome else None,
            "rules": first_rules + second_rules,
            "terminal": first_terminal,
        })
        record["passed"] = evaluate(scenario, record, session)
        return record


def evaluate(scenario, record, session):
    reply = record["reply"].casefold()
    second = (record.get("second_reply") or "").casefold()
    case_id = scenario["id"]
    if case_id == "S01":
        return session.scratch.get("right_party_confirmed") and "3.5%" in reply and "₹750" in reply and "10,000" in reply
    if case_id == "S02":
        return not session.scratch.get("right_party_confirmed") and "am i speaking with asha mehta" in reply.casefold() and "overdue" not in reply
    if case_id == "S03":
        return record["terminal"] and "goodbye" in reply and "payment" not in reply and "overdue" not in reply
    if case_id == "S04":
        return record["outcome"] == "already_paid_reported" and "confirms this payment" in reply and "2 working days" in reply
    if case_id == "S05":
        return record["second_outcome"] == "already_paid_reported" and "six or seven days ago" in str(record.get("outcome_fields")) and "asked our team" in second
    if case_id == "S06":
        return "what amount" not in reply and "6 november" in reply
    if case_id == "S07":
        return not record["terminal"] and ("open to paying" in reply or "comfortable agreeing on a date" in reply) and record["outcome"] is None
    if case_id == "S08":
        return "haven’t paid yet" in reply and not record["terminal"]
    if case_id == "S09":
        return record["terminal"] and record["outcome"] == "waiver_request" and "human agent will call" in reply
    if case_id in {"S10", "S11"}:
        return record["terminal"] and "human agent" in reply and record["outcome"] == "dispute_transfer"
    if case_id == "S12":
        return record["terminal"] and record["outcome"] == "dispute_transfer" and "pause" in reply
    if case_id == "S13":
        return record["terminal"] and record["outcome"] == "opt_out"
    if case_id == "S14":
        return record["reply"] != "<no response returned>" and "colleague to trigger a payment link" in reply and "human" in second and record["second_outcome"] == "no_commitment"
    if case_id == "S15":
        return "six-digit verification code" in reply and "enter" in second and "verified current balance" in str(record.get("verified_balance_reply", "")) and record.get("otp_alone_not_issued") and record.get("unrelated_declined")
    return False


def main():
    results = []
    for scenario in SCENARIOS:
        for version in ("v1-fast-path-baseline", "v2-golden-intent-candidate"):
            results.append(run_one(scenario, version))
    by_version = {}
    for version in sorted({r["version"] for r in results}):
        subset = [r for r in results if r["version"] == version]
        failed = [r for r in subset if not r["passed"]]
        by_version[version] = {
            "passed": len(subset) - len(failed), "failed": len(failed), "total": len(subset),
            "failure_rate_percent": round(100 * len(failed) / len(subset), 1),
            "failed_ids": [r["id"] for r in failed],
        }
    result_path = Path(__file__).parent / "assignment_eval_results.json"
    result_path.write_text(json.dumps({"summary": by_version, "results": results}, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"summary": by_version, "results_file": str(result_path)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
