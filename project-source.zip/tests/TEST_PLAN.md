# Collections voicebot test plan

This plan separates policy and workflow tests from live voice-quality tests. Automated tests should not call paid STT, LLM, or TTS services; those providers are covered by a small manual end-to-end pass.

Run the offline suite from the project root with the project virtual environment active:

```bash
python -m unittest discover -s tests -v
```

## Automated policy and workflow coverage

The companion `test_conversation.py` exercises the deterministic conversation policy with mock bank services. It covers:

- Right-party identity confirmation and no account-topic disclosure before confirmation.
- Wrong number or account holder unavailable.
- Opt-out precedence and persisted contact preference.
- Distress escalation, human transfer, and agent-task creation.
- Debt dispute escalation to human review.
- Approximate payment dates, questions during date collection, and inability to provide an exact date.
- Exact payment date plus payment method reconciliation.
- Payment-age handling: payments within two days and payments more than one calendar month ago, including a most-recent-payment check and human follow-up for yes or uncertain answers.
- Future payment amount/date capture and explicit confirmation.
- Callback request and follow-up task creation.
- OTP verification through the keypad submission path.
- Decision-trace entries for selected identity and payment rules.

## Manual browser and voice scenarios

| ID | Scenario and sample utterance | Expected behavior | Console evidence |
|---|---|---|---|
| V01 | Answer identity in English: “Yes, this is Asha.” | Confirm the account holder, then introduce the payment topic. | Identity confirmed; identity safeguard passed. |
| V02 | Answer identity in Hindi or code-switching, e.g. “हाँ, मैं आशा बोल रही हूँ.” | Understand the affirmative response; continue in the configured bot language. | Identity confirmed by contextual interpretation; no account detail disclosed before that turn. |
| V03 | Say “Wrong number” or “Asha is not available.” | End without discussing the account. | Identity not confirmed; identity safeguard active. |
| V04 | Before confirming identity, ask “What is this about?” | Identify the bot and request identity confirmation without revealing debt details. | Identity safeguard active; no payment details released. |
| V05 | After identity, say “I already paid on 25 October by UPI.” | Capture the exact date and method; run mock reconciliation; report only the returned status. | Already-paid intent; exact date; reconciliation action selected. |
| V06 | Say a vague payment timing, e.g. “I paid about six or seven days ago.” | Preserve it as approximate; do not invent a calendar date; ask once for the exact date. | Approximate date; exact-date requirement; no reconciliation lookup yet. |
| V07 | After V06, say “I don’t remember.” | Stop repeating the date question; create a manual reconciliation follow-up preserving the approximate timing. | Cannot provide requested detail; manual review selected; original approximate timing retained. |
| V08 | During date collection, ask a question instead of answering, e.g. “Why do you need the date?” | Address the question briefly and explain what detail is needed to check the payment. | Caller asked a question while payment date was pending. |
| V09 | Say “I’ll pay ₹1,200 on 5 November.” | Repeat the amount/date for confirmation; record the commitment only after confirmation. | Commitment fields captured; explicit confirmation required before outcome. |
| V10 | Request a callback, then provide a time or say no preferred time. | Record the callback request accurately; do not invent a preferred time. | Callback rule triggered; follow-up task and requested-time text shown. |
| V11 | Dispute the debt or request no further calls. | Pause collection flow; route a dispute for review or record opt-out, respectively. | Correct dispute or opt-out rule triggered; no payment pitch afterward. |
| V12 | Speak over the bot while it is responding. | Bot audio stops promptly and the interruption is transcribed as the customer’s next turn. | Interruption metric increments; full transcript retains both speakers. |
| V13 | Trigger an LLM timeout or invalid structured output in a development environment. | Deterministic policy fallback remains safe; the bot does not claim the model understood the turn. | Interpretation fallback and error are visible; response source says policy fallback. |
| V14 | Complete several turns, then start another conversation. | Transcript and decision history remain visible with a clear new-conversation marker. | Decision records are chronological and separated by session markers. |
| V15 | After identity confirmation, ask an unrelated question or correct the bot, e.g. “I have multiple cards” or “You called me.” | Acknowledge the specific point, answer only from verified facts, then return naturally to the payment step. If it cannot answer, say so and offer only an available next step. | Console shows the generated acknowledgment and that the response contract check passed. |
| V16 | Give a meaningful but garbled or unclear utterance. | Do not pretend to understand it; ask a concise clarification while preserving the current policy step. | Acknowledgment reflects uncertainty; no unsupported interpretation is shown. |
| V17 | Answer with one word or a very short phrase in context, including “Concern” (previously transcribed as “And so on”) and “Yes, Shiva” (previously transcribed as “Yes, you are”). | Treat short replies as a known voice-recognition risk. Interpret them against the question just asked; if the transcript or meaning is uncertain, clarify briefly instead of switching topics or repeating a generic prompt. | Preserve the mic-only clip and compare it with the live transcript; console shows current pending question and resulting classification. |
| V18 | Say “I paid yesterday by UPI.” | Record the reported date and mode. If the ledger has not updated, explain that it can take up to two working days and should reflect soon; close politely without unnecessary human escalation. | Recent-payment rule selected; customer-reported payment stored; smooth spoken call close. |
| V19 | Report a payment date more than one calendar month ago, then say “Yes” to “Is it the most recent payment you made?” | Note the date and any collected mode, create human payment-review follow-up, and close politely. |
| V20 | At V19, answer “Maybe,” “I think so,” “Not sure,” or “I don’t know.” | Treat the answer as uncertain, note it, and route to a human colleague. Do not repeat the confirmation question. |
| V21 | At V19, answer “No.” | Ask for the date of the most recent payment. If needed, then collect the mode for that newer payment; do not reuse the prior payment’s mode automatically. |

## Acceptance checks

- Never reveal account or debt details before right-party confirmation.
- Opt-outs, disputes, distress escalation, OTP verification, and payment reconciliation remain policy-controlled.
- Approximate dates never become exact dates without explicit information.
- A missing detail is not treated as a successful payment, commitment, or callback time.
- The console shows the interpreted intent/conversation act, rules evaluated or triggered, and response-generation/fallback path for every customer turn.
- For nonterminal turns where generated wording is enabled, the reply specifically acknowledges the latest meaningful caller point before answering and bridging to the policy-selected next step; generic courtesy alone does not pass the acknowledgment check.
- An answer to an out-of-scope question is not invented; the bot states its limitation and offers an allowed next step. Opt-outs, disputes, distress escalation, identity safeguards, and security actions are never bridged back into collection.
- Transcript text and console entries use safe DOM text rendering; caller text is not inserted as HTML.
- Review STT, LLM/policy, TTS first-audio, and total response latency over repeated turns; compare against the dashboard’s timing fields.
