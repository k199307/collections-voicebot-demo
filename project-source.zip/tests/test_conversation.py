"""Offline tests for deterministic collection policy and conversation state."""

from datetime import datetime, timezone
import unittest
from unittest.mock import patch
from uuid import uuid4

from collections_bot.conversation import process_turn, process_otp_code
from collections_bot.schemas import CallSession, OutcomeType, StartCallRequest


def make_session(*, pending=None, right_party_confirmed=False):
    request = StartCallRequest(
        case_id="case-test-001",
        episode_id="episode-test-001",
        customer_id="customer-test-001",
        account_id="account-test-001",
        contact_point_id="contact-test-001",
        timezone="Asia/Kolkata",
        first_name="Asha",
        days_past_due=8,
        eligibility_confirmed=True,
        contact_allowed=True,
        contact_policy_version="test-v1",
    )
    return CallSession(
        session_id=uuid4(),
        attempt_id=uuid4(),
        request=request,
        started_at=datetime.now(timezone.utc),
        pending=pending,
        scratch={"right_party_confirmed": right_party_confirmed},
    )


class ConversationPolicyTests(unittest.TestCase):
    def test_identity_confirmation_allows_payment_topic(self):
        session = make_session(pending="identity_confirmation")

        response = process_turn(
            session,
            "आप बोल रही हूं",
            {"intent": "unclear", "identity_status": "confirmed"},
        )

        self.assertTrue(session.scratch["right_party_confirmed"])
        self.assertIsNone(session.pending)
        self.assertIn("pending Mumbai Bank credit-card payment", response.bot_text)
        self.assertTrue(any(item["rule"] == "Right-party identity safeguard" for item in session.scratch["decision_trace"]))

    def test_unconfirmed_identity_does_not_disclose_account_topic(self):
        session = make_session(pending="identity_confirmation")

        response = process_turn(session, "Hello", {"intent": "unclear", "identity_status": "unclear"})

        self.assertFalse(session.scratch["right_party_confirmed"])
        self.assertNotIn("pending Mumbai Bank credit-card payment", response.bot_text)
        self.assertIn("account holder", response.bot_text)

    def test_unavailable_account_holder_ends_without_disclosure(self):
        session = make_session(pending="identity_confirmation")

        response = process_turn(session, "Wrong number", {"intent": "unclear", "identity_status": "not_confirmed"})

        self.assertTrue(response.terminal)
        self.assertFalse(session.scratch["right_party_confirmed"])
        self.assertNotIn("payment", response.bot_text.casefold())

    @patch("collections_bot.conversation.bank_services.set_contact_preference")
    def test_opt_out_is_recorded_before_other_flow(self, set_contact_preference):
        session = make_session(pending="identity_confirmation")

        response = process_turn(session, "Stop calling")

        self.assertTrue(response.terminal)
        self.assertEqual(response.outcome.type, OutcomeType.OPT_OUT)
        set_contact_preference.assert_called_once()
        self.assertTrue(any(item["rule"] == "Contact opt-out check" and item["status"] == "triggered"
                            for item in session.scratch["decision_trace"]))

    @patch("collections_bot.conversation.bank_services.request_human_transfer", return_value={"transfer_id": "transfer-1", "status": "queued"})
    @patch("collections_bot.conversation.bank_services.create_agent_task", return_value={"task_id": "task-1"})
    def test_distress_requests_human_transfer(self, create_task, request_transfer):
        session = make_session(pending="identity_confirmation")

        response = process_turn(session, "I have a medical emergency")

        self.assertTrue(response.terminal)
        self.assertEqual(response.outcome.fields["reason"], "customer_distress")
        request_transfer.assert_called_once()
        create_task.assert_called_once()

    @patch("collections_bot.conversation.bank_services.create_agent_task", return_value={"task_id": "task-1"})
    def test_debt_dispute_pauses_collections_and_creates_followup(self, create_task):
        session = make_session(right_party_confirmed=True)

        response = process_turn(session, "This is not my account")

        self.assertTrue(response.terminal)
        self.assertEqual(response.outcome.type, OutcomeType.DISPUTE_TRANSFER)
        create_task.assert_called_once()

    def test_approximate_payment_date_is_not_used_as_exact_date(self):
        session = make_session(pending="paid_date", right_party_confirmed=True)
        extracted = {
            "intent": "already_paid",
            "date_iso": None,
            "payment_mode": None,
            "date_precision": "approximate",
            "dialogue_act": "answers_pending",
            "pending_slot_status": "provided",
        }

        response = process_turn(session, "छह सात दिन पहले कर दिया था", extracted)

        self.assertFalse(response.terminal)
        self.assertEqual(session.scratch["reported_payment_date_text"], "छह सात दिन पहले कर दिया था")
        self.assertIsNone(session.scratch.get("reported_payment_date"))
        self.assertIn("exact calendar date", response.bot_text)
        self.assertTrue(any(item["rule"] == "Approximate-date handling" and item["status"] == "triggered"
                            for item in session.scratch["decision_trace"]))

    @patch("collections_bot.conversation.bank_services.create_agent_task", return_value={"task_id": "task-1"})
    def test_cannot_provide_date_creates_manual_review_and_preserves_approximate_timing(self, create_task):
        session = make_session(pending="paid_date", right_party_confirmed=True)
        session.scratch["reported_payment_date_text"] = "छह सात दिन पहले कर दिया था"
        extracted = {
            "intent": "already_paid",
            "dialogue_act": "cannot_provide",
            "pending_slot_status": "cannot_provide",
            "date_precision": "none",
        }

        response = process_turn(session, "याद नहीं है मुझे", extracted)

        self.assertTrue(response.terminal)
        self.assertEqual(response.outcome.type, OutcomeType.ALREADY_PAID_REPORTED)
        self.assertEqual(response.outcome.fields["reported_payment_date_text"], "छह सात दिन पहले कर दिया था")
        self.assertFalse(response.outcome.fields["exact_date_provided"])
        self.assertIn("payment records", response.bot_text)
        self.assertIn("छह सात दिन पहले कर दिया था", create_task.call_args.kwargs["summary"])

    def test_question_during_pending_payment_date_gets_contextual_answer(self):
        session = make_session(pending="paid_date", right_party_confirmed=True)
        extracted = {
            "intent": "already_paid",
            "dialogue_act": "asks_question",
            "pending_slot_status": "question",
            "date_precision": "none",
        }

        response = process_turn(session, "How many days ago was it?", extracted)

        self.assertFalse(response.terminal)
        self.assertIn("without a payment date", response.bot_text)
        self.assertTrue(any(item["rule"] == "Question-during-information-collection" for item in session.scratch["decision_trace"]))

    @patch("collections_bot.conversation.bank_services.reconcile_payment", return_value={
        "status": "confirmed", "payment_id": "payment-1", "reference": "ref-1"
    })
    def test_exact_paid_date_and_mode_run_reconciliation(self, reconcile_payment):
        session = make_session(pending="paid_date", right_party_confirmed=True)
        extracted = {
            "intent": "already_paid",
            "date_iso": "2026-10-25",
            "payment_mode": "UPI",
            "date_precision": "exact",
        }

        response = process_turn(session, "I paid by UPI on 25/10/2026", extracted)

        self.assertTrue(response.terminal)
        self.assertEqual(response.outcome.fields["reconciliation_status"], "confirmed")
        reconcile_payment.assert_called_once_with("account-test-001", "2026-10-25", "UPI")

    def test_future_payment_commitment_requires_confirmation(self):
        session = make_session(right_party_confirmed=True)

        response = process_turn(session, "I will pay ₹1200 on 2026-11-05")

        self.assertFalse(response.terminal)
        self.assertEqual(session.pending, "ptp_confirmation")
        self.assertIn("₹1,200", response.bot_text)
        self.assertIn("5 November", response.bot_text)

    def test_confirmed_commitment_is_recorded(self):
        session = make_session(pending="ptp_confirmation", right_party_confirmed=True)
        session.scratch.update({"ptp_amount": "1200", "ptp_date": "2026-11-05"})

        response = process_turn(session, "Yes")

        self.assertTrue(response.terminal)
        self.assertEqual(response.outcome.type, OutcomeType.PROMISE_TO_PAY)
        self.assertEqual(response.outcome.fields["amount"], "1200")
        self.assertEqual(response.outcome.fields["date"], "2026-11-05")

    @patch("collections_bot.conversation.bank_services.create_agent_task", return_value={"task_id": "task-1"})
    def test_callback_is_recorded_for_human_followup(self, create_task):
        session = make_session(right_party_confirmed=True)

        first = process_turn(session, "Callback please")
        self.assertEqual(session.pending, "callback_time")
        self.assertIn("what day or time", first.bot_text.casefold())

        final = process_turn(session, "Tomorrow afternoon")

        self.assertTrue(final.terminal)
        self.assertEqual(final.outcome.type, OutcomeType.CALLBACK_REQUEST)
        create_task.assert_called_once()

    @patch("collections_bot.conversation.bank_services.verify_otp", return_value={"verified": False, "reason": "invalid_code"})
    def test_otp_is_processed_only_from_explicit_keypad_submission(self, verify_otp):
        session = make_session(pending="otp_code", right_party_confirmed=True)
        session.scratch["otp_challenge_id"] = "challenge-1"

        response = process_otp_code(session, "123456")

        self.assertFalse(response.terminal)
        verify_otp.assert_called_once_with("challenge-1", "123456")


if __name__ == "__main__":
    unittest.main()
