"""Retry only Gemini sequentially and merge that profile into the matrix JSON."""
import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from run_provider_matrix import PROFILES, classify_profile


async def main():
    result = await classify_profile(PROFILES[0], max_concurrency=1)
    path = Path(__file__).with_name("provider_matrix_results_2026-11-03.json")
    matrix = json.loads(path.read_text())
    matrix["classification_profiles"] = [
        result if item["profile"] == result["profile"] else item
        for item in matrix["classification_profiles"]
    ]
    matrix["gemini_retry"] = {
        "retried_at_utc": datetime.now(timezone.utc).isoformat(),
        "requests": len(result["results"]),
        "concurrency": 1,
        "summary": result["summary"],
    }
    path.write_text(json.dumps(matrix, ensure_ascii=False, indent=2) + "\n")
    print("Gemini retry summary:", json.dumps(result["summary"], ensure_ascii=False), flush=True)
    print("Updated", path, flush=True)


if __name__ == "__main__":
    asyncio.run(main())
