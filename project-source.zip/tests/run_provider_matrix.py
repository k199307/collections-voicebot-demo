"""Live, test-only provider matrix for the 30-case assignment suite.

Runs text classification separately from speech probes: the supplied 30 cases
are transcripts, not raw audio. Results are saved to JSON under tests/.
"""
from __future__ import annotations

import asyncio
import json
import re
import statistics
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

from collections_bot.config import settings
from collections_bot.providers import classify_utterance, transcribe_browser_audio, stream_browser_audio


CASES = [
    ("01", "identity_yes", "Yes, this is Asha Mehta.", "identity_confirmation", "unclear", "confirmed", "easy"),
    ("02", "identity_short_affirmative", "Yeah, you are.", "identity_confirmation", "unclear", "confirmed", "tricky"),
    ("03", "preopening_greeting", "Hello?", "outbound_opening", "greeting", "unclear", "tricky"),
    ("04", "preopening_yes", "Yes.", "outbound_opening", "unclear", "unclear", "trap"),
    ("05", "preopening_full_name", "I'm Asha Mehta.", "outbound_opening", "unclear", "unclear", "trap"),
    ("06", "partial_name", "Asha.", "identity_confirmation", "unclear", "unclear", "tricky"),
    ("07", "wrong_person", "No, I'm her colleague.", "identity_confirmation", "unclear", "not_confirmed", "easy"),
    ("08", "hinglish_identity", "Haan, main Asha bol rahi hoon.", "identity_confirmation", "unclear", "confirmed", "tricky"),
    ("09", "due_notice_ack", "Okay, tell me.", "due_notice", "unclear", "unclear", "easy"),
    ("10", "not_paid", "I haven't paid yet.", "payment_status", "payment_not_made", "unclear", "easy"),
    ("11", "paid_yesterday_upi", "I paid yesterday by UPI.", "paid_date", "already_paid", "unclear", "easy"),
    ("12", "approximate_payment_date", "About six or seven days ago, through UPI.", "paid_date", "already_paid", "unclear", "tricky"),
    ("13", "separate_payment_mode", "Net banking.", "paid_mode", "already_paid", "unclear", "tricky"),
    ("14", "old_payment_latest_yes", "Yes.", "paid_most_recent_confirmation", "already_paid", "unclear", "tricky"),
    ("15", "old_payment_uncertain", "I think so.", "paid_most_recent_confirmation", "already_paid", "unclear", "tricky"),
    ("16", "old_payment_not_latest", "No, I made another payment after that.", "paid_most_recent_confirmation", "already_paid", "unclear", "tricky"),
    ("17", "refusal_one_word_answer", "Concern.", "payment_refusal_reason", "unclear", "unclear", "tricky"),
    ("18", "tentative_willingness", "I may be okay to pay.", "general_conversation", "payment_commitment_interest", "unclear", "tricky"),
    ("19", "clear_commitment_date", "I will pay next Friday.", "general_conversation", "promise_to_pay", "unclear", "easy"),
    ("20", "small_volunteered_amount", "I can only pay ₹1 by tomorrow.", "general_conversation", "promise_to_pay", "unclear", "trap"),
    ("21", "customer_estimated_balance", "My balance is only ₹5,000.", "general_conversation", "fee_applicability", "unclear", "tricky"),
    ("22", "fee_threshold_boundary", "It's exactly ₹10,000. Does the ₹750 fee apply?", "general_conversation", "fee_applicability", "unclear", "trap"),
    ("23", "interest_tangential_question", "What is this interest for?", "general_conversation", "interest_question", "unclear", "easy"),
    ("24", "explicit_balance_request", "What is my account balance?", "general_conversation", "balance_question", "unclear", "easy"),
    ("25", "otp_without_balance_request", "Can you send me the OTP?", "general_conversation", "otp_request", "unclear", "trap"),
    ("26", "unsupported_payment_process", "Can I pay in cash?", "general_conversation", "payment_method_question", "unclear", "tricky"),
    ("27", "payment_link", "Send me a payment link.", "general_conversation", "payment_link_request", "unclear", "easy"),
    ("28", "waiver_discount", "Can you waive or discount the late fee?", "general_conversation", "waiver", "unclear", "easy"),
    ("29a", "job_loss_escalation", "I lost my job and can't pay.", "general_conversation", "distress", "unclear", "trap"),
    ("29b", "medical_emergency_escalation", "I have a medical emergency.", "general_conversation", "distress", "unclear", "trap"),
    ("29c", "abuse_escalation", "You're useless, shut up.", "general_conversation", "abuse", "unclear", "trap"),
    ("29d", "debt_dispute", "I dispute this debt; this isn't my account.", "general_conversation", "dispute", "unclear", "trap"),
    ("30a", "opt_out", "Stop calling me.", "general_conversation", "opt_out", "unclear", "trap"),
    ("30b", "credit_score_prohibited", "What will my CIBIL score become?", "general_conversation", "credit_score_question", "unclear", "trap"),
    ("30c", "legal_advice_prohibited", "Can you give me legal advice?", "general_conversation", "legal_question", "unclear", "trap"),
    ("30d", "other_bank_product", "Tell me about a new loan or FD.", "general_conversation", "other_product", "unclear", "tricky"),
    ("30e", "unrelated_topic", "What is the capital of India?", "general_conversation", "unclear", "unclear", "tricky"),
]

PROFILES = [
    ("gemini_standard", "gemini", "gemini-3.5-flash-lite", "standard", "none"),
    ("openai_luna_standard", "openai", "gpt-6-luna", "default", "none"),
    ("openai_luna_fast", "openai", "gpt-6-luna", "fast", "none"),
    ("openai_terra_standard", "openai", "gpt-6.1-terra", "default", "none"),
]

def pctl(vals: list[float], q: float) -> float | None:
    if not vals:
        return None
    arr = sorted(vals)
    return round(arr[min(len(arr)-1, int((len(arr)-1)*q))], 1)

async def classify_profile(profile, max_concurrency=3):
    name, provider, model, tier, reasoning = profile
    object.__setattr__(settings, "llm_provider", provider)
    object.__setattr__(settings, "openai_model", model)
    object.__setattr__(settings, "openai_service_tier", tier)
    object.__setattr__(settings, "openai_reasoning_effort", reasoning)
    object.__setattr__(settings, "gemini_model", model)
    sem = asyncio.Semaphore(max_concurrency)
    async def one(case):
        cid, cname, utterance, pending, expected_intent, expected_identity, difficulty = case
        async with sem:
            start = perf_counter()
            try:
                parsed, meta = await classify_utterance(
                    utterance, pending_state=pending, reference_date="2026-11-03",
                    conversation_history=[], known_fields={},
                )
                timing = meta.get("timings_ms", {})
                actual = parsed.get("intent")
                identity = parsed.get("identity_status")
                error = None
            except Exception as exc:
                parsed = {}
                timing = getattr(exc, "classifier_timing_ms", {}) or {}
                actual = None
                identity = None
                error = f"{type(exc).__name__}: {str(exc)[:300]}"
            if provider == "gemini" and max_concurrency == 1:
                print(f"Gemini {cid}: {'error' if error else actual} ({timing.get('model_request_ms', 'n/a')} ms)", flush=True)
            expected_ok = actual == expected_intent
            identity_applicable = expected_identity != "unclear"
            identity_ok = (not identity_applicable) or identity == expected_identity
            # Scoring is strict on explicit critical intent. In identity cases, score identity_status.
            critical = difficulty == "trap"
            pass_case = identity_ok if identity_applicable else expected_ok
            return {
                "id": cid, "case": cname, "difficulty": difficulty, "pending_state": pending,
                "transcript": utterance, "expected_intent": expected_intent, "actual_intent": actual,
                "intent_correct": expected_ok, "expected_identity_status": expected_identity,
                "actual_identity_status": identity, "identity_correct": identity_ok,
                "case_pass": pass_case, "critical_case": critical,
                "latency_ms": timing.get("total_ms", round((perf_counter()-start)*1000, 1)),
                "model_request_ms": timing.get("model_request_ms"),
                "prompt_build_ms": timing.get("prompt_build_ms"),
                "response_parse_ms": timing.get("response_parse_ms"),
                "input_tokens": timing.get("input_tokens"), "output_tokens": timing.get("output_tokens"),
                "cached_input_tokens": timing.get("cached_input_tokens"),
                "summary": parsed.get("summary"), "dialogue_act": parsed.get("dialogue_act"),
                "confidence": parsed.get("intent_confidence"), "error": error,
            }
    results = await asyncio.gather(*(one(case) for case in CASES))
    times = [float(row["latency_ms"]) for row in results if row["error"] is None]
    req = [float(row["model_request_ms"]) for row in results if row["model_request_ms"] is not None]
    return {
        "profile": name, "provider": provider, "model": model, "service_tier": tier,
        "reasoning_effort": reasoning,
        "summary": {
            "n": len(results), "correct_intents": sum(r["intent_correct"] for r in results),
            "intent_accuracy_pct": round(100*sum(r["intent_correct"] for r in results)/len(results), 1),
            "case_pass": sum(r["case_pass"] for r in results),
            "strict_case_failure_rate_pct": round(100*(len(results)-sum(r["case_pass"] for r in results))/len(results), 1),
            "critical_cases": sum(r["critical_case"] for r in results),
            "critical_intent_errors": sum(r["critical_case"] and not r["intent_correct"] for r in results),
            "errors": sum(r["error"] is not None for r in results),
            "latency_ms": {"mean": round(statistics.mean(times), 1) if times else None,
                           "median": round(statistics.median(times), 1) if times else None,
                           "p95": pctl(times, .95), "min": round(min(times),1) if times else None,
                           "max": round(max(times),1) if times else None,
                           "mean_model_request": round(statistics.mean(req),1) if req else None},
            "mean_tokens_in": round(statistics.mean([r["input_tokens"] for r in results if isinstance(r["input_tokens"], (int,float))]),1) if any(isinstance(r["input_tokens"], (int,float)) for r in results) else None,
            "mean_tokens_out": round(statistics.mean([r["output_tokens"] for r in results if isinstance(r["output_tokens"], (int,float))]),1) if any(isinstance(r["output_tokens"], (int,float)) for r in results) else None,
        },
        "results": results,
    }

async def audio_probes():
    audio_cases = [
        ("audio_1", "/Users/kushal/Downloads/mic-stt-utterance-2026-11-02T19-34-06-011Z.wav", "Concern"),
        ("audio_2", "/Users/kushal/Downloads/mic-stt-utterance-2026-11-02T20-07-46-351Z.wav", "Hello"),
        ("audio_3", "/Users/kushal/Downloads/mic-stt-utterance-2026-11-02T20-07-49-917Z.wav", "Haan / yes affirmative (user-reported)") ,
        ("audio_4", "/Users/kushal/Downloads/mic-stt-utterance-2026-11-02T20-07-52-683Z.wav", "Yes, I am Asha Mehta (user-reported correction)"),
    ]
    output = {"stt": [], "tts": []}
    for voice in ("deepgram", "sarvam"):
        object.__setattr__(settings, "voice_provider", voice)
        for cid, path, reference in audio_cases:
            try:
                audio = Path(path).read_bytes()
                started = perf_counter()
                transcript = await transcribe_browser_audio(audio, "audio/wav")
                output["stt"].append({"provider": voice, "case": cid, "reference_user_reported": reference,
                                      "transcript": transcript, "latency_ms": round((perf_counter()-started)*1000,1),
                                      "exact_normalized_match": bool(re.sub(r"\W+", "", transcript.lower()) == re.sub(r"\W+", "", reference.lower())) if "user-reported" not in reference and "/" not in reference else None,
                                      "error": None})
            except Exception as exc:
                output["stt"].append({"provider": voice, "case": cid, "reference_user_reported": reference,
                                      "transcript": None, "latency_ms": None, "error": f"{type(exc).__name__}: {str(exc)[:300]}"})
        for text in (
            "Thank you for confirming. Your minimum payment is overdue. Have you already paid, or when do you expect to pay?",
            "I understand. I’ll stop the payment discussion and request a human agent now.",
            "Thank you. I’ve noted the payment details and will ask a colleague to follow up.",
        ):
            first_ms = total_ms = 0
            chunks = 0
            try:
                async for kind, payload, first, total in stream_browser_audio(text):
                    if kind == "first_audio":
                        first_ms = first or 0
                        chunks += 1
                    elif kind == "audio":
                        chunks += 1
                    elif kind == "done":
                        total_ms = total or 0
                output["tts"].append({"provider": voice, "text_chars": len(text), "first_audio_ms": first_ms,
                                      "total_ms": total_ms, "audio_chunks": chunks, "error": None})
            except Exception as exc:
                output["tts"].append({"provider": voice, "text_chars": len(text), "first_audio_ms": first_ms or None,
                                      "total_ms": total_ms or None, "audio_chunks": chunks,
                                      "error": f"{type(exc).__name__}: {str(exc)[:300]}"})
    return output

async def main():
    profiles = []
    for profile in PROFILES:
        print("Running", profile[0], flush=True)
        profiles.append(await classify_profile(profile))
    print("Running speech probes", flush=True)
    speech = await audio_probes()
    out = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "protocol": "Live model classifier benchmark on the 30 scripted test cases. Each case is one key turn, no prompt retry; OpenAI profile/LLM repeated independently of speech stack. Deepgram/Sarvam STT measured on four user-supplied WAV utterances; TTS on three fixed utterances per voice provider. No bank API/OTP/transfer side effects executed.",
        "scenario_count": 30, "scored_utterance_count": len(CASES), "classification_profiles": profiles,
        "speech_probes": speech,
        "limitations": [
            "The speech probe set is four short recorded utterances, not a statistically representative Hindi/noise test corpus.",
            "References for clips described by the user are labeled user-reported; no independent human transcription was performed.",
            "The 30-case suite is scored as classification of its decisive turn. Stateful policy actions require dialogue integration testing and are not represented by classifier accuracy alone.",
            "TTS audio was timed at first audio and stream completion only; no listener naturalness/accent scoring is included.",
            "Service-provider latency includes network transit and provider processing and may vary with load and region.",
        ],
    }
    dest = Path(__file__).with_name("provider_matrix_results_2026-11-03.json")
    dest.write_text(json.dumps(out, ensure_ascii=False, indent=2))
    print("Saved", dest, flush=True)
    for profile in profiles:
        print(profile["profile"], json.dumps(profile["summary"]), flush=True)
    print("STT", json.dumps(speech["stt"], ensure_ascii=False), flush=True)
    print("TTS", json.dumps(speech["tts"], ensure_ascii=False), flush=True)

if __name__ == "__main__":
    asyncio.run(main())
