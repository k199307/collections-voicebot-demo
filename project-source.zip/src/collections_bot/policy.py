from .config import settings
from .schemas import FrequencyPolicy


def configured_frequency_policy() -> FrequencyPolicy:
    return FrequencyPolicy(
        version=settings.calling_policy_version,
        allowed_start_hour=settings.allowed_start_hour,
        allowed_end_hour=settings.allowed_end_hour,
        max_attempts_per_local_day=settings.max_attempts_per_local_day,
        max_attempts_per_rolling_7_days=settings.max_attempts_per_rolling_7_days,
        min_interval_minutes=settings.min_interval_minutes,
    )

