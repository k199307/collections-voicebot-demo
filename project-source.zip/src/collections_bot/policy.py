import os

from .business_rules import business_rules
from .schemas import FrequencyPolicy


def configured_frequency_policy() -> FrequencyPolicy:
    configured = business_rules.calling_frequency
    return FrequencyPolicy(
        version=os.getenv("CALLING_POLICY_VERSION") or business_rules.version,
        allowed_start_hour=int(os.getenv("CALLING_ALLOWED_START_HOUR", configured["allowed_start_hour"])),
        allowed_end_hour=int(os.getenv("CALLING_ALLOWED_END_HOUR", configured["allowed_end_hour"])),
        max_attempts_per_local_day=int(os.getenv("CALLING_MAX_ATTEMPTS_PER_LOCAL_DAY", configured["max_attempts_per_local_day"])),
        max_attempts_per_rolling_7_days=int(os.getenv("CALLING_MAX_ATTEMPTS_PER_ROLLING_7_DAYS", configured["max_attempts_per_rolling_7_days"])),
        min_interval_minutes=int(os.getenv("CALLING_MIN_INTERVAL_MINUTES", configured["min_interval_minutes"])),
    )

