from __future__ import annotations

import re
import calendar
from datetime import date, datetime, timezone

from .bank_services import bank_services
from .schemas import CallSession, Outcome, OutcomeType, TurnResponse


_ABUSE = ("idiot", "stupid", "shut up", "bloody", "abusive", "fuck", "shit", "bitch", "asshole", "madarchod", "bhenchod", "chutiya")
_DISTRESS = (
    "medical emergency", "hospitalized", "admitted to hospital", "serious accident", "lost my job", "job loss",
    "unemployed", "jobless", "naukri chali", "medical emergency hai", "financial hardship", "financial difficulty",
    "financial problem", "can't afford", "cannot afford", "no money to pay", "salary delayed", "salary not received",
    "couldn’t manage the payment", "couldn't manage the payment", "पैसे नहीं हैं", "नौकरी चली गई",
)
_PAID = ("already paid", "i paid", "payment done", "paid yesterday", "payment kar diya", "bhar diya")
_LATE_FEE_DISCOUNT = (
    "discount regarding the late fee", "discount regarding late fee", "discount on the late fee",
    "discount on late fee", "discount for the late fee", "late fee discount", "late-fee discount",
    "reduce the late fee", "reduce my late fee",
)
_WAIVER = ("waive", "waiver", "remove the late fee", "reverse the fee", "late fee hata", *_LATE_FEE_DISCOUNT)
_NOT_PAID = (
    "not paid yet", "have not paid", "haven't paid", "have not made the payment",
    "haven't made the payment", "did not pay", "didn't pay", "payment is still pending",
    "abhi tak payment nahi", "payment nahi kiya",
)
_PAYMENT_REFUSAL = (
    "i don't want to pay", "i do not want to pay", "i don't wanna pay", "i do not wanna pay",
    "i won't pay", "i wont pay", "i will not pay", "not gonna pay", "not going to pay",
    "refuse to pay", "not willing to pay", "not ready to pay",
)
_BALANCE = ("what is my balance", "account balance", "how much do i owe", "total due", "kitna due")
_BALANCE_INFO_REQUEST = re.compile(
    r"\b(?:can|could|would)\s+you\s+(?:please\s+)?(?:tell|show|check|confirm|verify|share)\s+(?:me\s+)?(?:the\s+|my\s+)?(?:account\s+)?balance\b"
    r"|\b(?:i\s+)?(?:want|would like)\s+to\s+know\s+(?:the\s+|my\s+)?(?:account\s+)?balance\b"
    r"|\b(?:what\s+is|what's|whats)\s+(?:the\s+|my\s+)?(?:account\s+)?balance\b"
    r"|\bbalance\s+of\s+my\s+account\b",
    re.IGNORECASE,
)
_BALANCE_CHECK_CUES = ("check it", "verify it", "check my balance", "verify my balance", "check the balance")
_DEFER_PAYMENT_CUES = ("is it okay if i pay", "is it okay to pay", "can i pay", "could i pay", "would it be okay if i pay", "would you allow me to pay")
_DEFER_PERIOD_CUES = ("next month", "next week", "later", "after a month", "after one month", "next year")
_PAYMENT_METHOD_QUESTION_CUES = ("can i", "could i", "is it", "would", "will you", "accepted", "okay", "allowed", "possible")
_PAYMENT_TERMS = ("payment", "pay", "paid", "due", "cash", "instalment", "installment", "partial payment", "payment method")
_QUESTION_CUES = ("can i", "can we", "could i", "may i", "is it", "is the", "would it", "should i", "how do i", "how much", "what if", "what is", "what about", "when can", "when should", "do i have to", "do you accept", "can you", "will you")
_CARD_REFERENCE_QUESTION = ("which card", "which credit card", "what card", "what credit card", "which account")
_OTP_QUESTION = ("otp", "one time password", "verification code")
_PAYMENT_PURPOSE_QUESTION = ("what is this payment about", "what's this payment about", "what is this call about", "what is the payment you called about", "what payment are you calling about", "what is the pending payment", "what pending payment")
_PRODUCTS = ("fixed deposit", "fd", "new loan", "insurance", "another product")
_DISPUTE = ("not my account", "wrong amount", "i don't owe", "i do not owe", "dispute", "incorrect charge")
_CALLBACK = ("call me later", "call back", "callback", "busy right now", "later please")
_PAYMENT_LINK = ("payment link", "pay link", "link to pay", "link for payment", "send me a link", "payment ka link")
_COMMITMENT_CUES = (
    "i will pay", "i'll pay", "i can pay", "can pay", "pay by", "pay on",
    "making a payment commitment", "make a payment commitment", "willing to make a payment",
    "ready to make a payment", "okay to make a payment commitment", "ok to make a payment commitment",
    "won't pay", "wont pay", "will not pay", "can't pay", "cannot pay",
    "not willing to pay", "not willing to make a payment", "not ready to pay",
)
_NEGATED_COMMITMENT = (
    "i will not pay", "i won't pay", "i wont pay", "i can't pay", "i cannot pay",
    "i am not willing to pay", "i'm not willing to pay", "i am not willing to make a payment",
    "i'm not willing to make a payment", "i am not ready to pay", "i'm not ready to pay",
    "i will not make a payment commitment", "i won't make a payment commitment",
    "i do not want to pay", "i don't want to pay", "i don't wanna pay", "i do not wanna pay",
    "not gonna pay", "not going to pay", "refuse to pay",
)
_OFFER_REQUEST = ("latest offer", "latest offers", "give me an offer", "give me the offer", "any offer", "any offers", "discount", "settlement offer", "offer before", "offer first")
_INTEREST = (
    "interest rate", "monthly interest", "rate of interest", "interest kitna",
    "what is interest", "why interest", "why was interest", "interest charged", "interest occurred",
    "interest accrue", "interest due to", "interest because",
)
_INTEREST_CONCERN = (
    "interest is too much", "interest too much", "too much interest", "interest is too high",
    "interest too high", "high interest", "interest is high", "interest is excessive",
    "excessive interest", "interest is unfair", "interest is a lot", "interest feels high",
)
_INTEREST_CONCERN_CUE = re.compile(
    r"\b(?:interest|rate)\b.{0,50}\b(?:too\s+)?(?:high|much|excessive|unfair|steep|costly)\b"
    r"|\b(?:too\s+)?(?:high|much|excessive|unfair|steep|costly)\b.{0,50}\binterest\b",
    re.IGNORECASE,
)
_FEE = ("late fee", "late charge", "penalty fee", "late fee kitna")
_CREDIT_SCORE = ("cibil", "credit score", "score improve", "score affect")
_LEGAL = ("legal action", "sue me", "court case", "legal advice", "lawyer")
_IDENTITY_INFO_QUESTION = ("who are you", "who is this", "what is this call", "what's this call", "what is this about",
                           "who's the account holder", "who is the account holder", "who are you trying to reach", "who are you calling for",
                           "कौन हो आप", "आप कौन हैं", "कौन बोल रहा", "कौन बोल रहे", "किसका फोन", "किसका कॉल")
_FRUSTRATION = ("what nonsense", "this is nonsense", "bakwas", "बकवास", "क्या बकवास")
_HURRY = ("hurry up", "speak quickly", "talk quickly", "get to the point", "be quick", "जल्दी बोलो", "बोलो जल्दी", "जल्दी बताओ", "सीधे मुद्दे पर")
_YOU_CALLED = ("you called me", "you rang me", "i didn't call you", "i did not call you", "you contacted me", "आपने मुझे फोन किया", "आपने कॉल किया", "तुमने मुझे फोन किया")
_GREETING = ("hi", "hello", "hey", "hi there", "hello there", "hey there", "good morning", "good afternoon", "good evening", "namaste", "नमस्ते", "हाय", "हेलो", "हेलो जी")
_AFFIRM = ("yes", "yeah", "yep", "correct", "right", "speaking", "this is", "that is me", "haan", "han", "ji bol", "main bol raha", "main bol rahi",
           "हाँ", "हां", "जी", "मैं ही हूं", "मैं ही हूँ")
_NEGATIVE = ("no", "nope", "not correct", "that's wrong", "that is wrong", "nahi", "nahin", "नहीं", "नही")
_UNCERTAIN_CONFIRMATION = (
    "maybe", "not sure", "i am not sure", "i'm not sure", "i don't know", "i do not know", "idk",
    "dont know", "i think so", "i guess so", "i guess", "perhaps", "probably", "possibly",
    "unsure", "pata nahi", "pata nahin", "shayad", "मुझे नहीं पता", "पता नहीं", "शायद",
)
_NEEDS_TIME_TO_CHECK = (
    "give me a minute", "give me a moment", "give me some time", "need a minute", "need a moment",
    "need some time", "let me check", "let me verify", "let me look", "let me see", "let me think",
    "i need to check", "i have to check", "i need to verify", "hold on", "one second", "one moment",
    "just a second", "just a moment", "एक मिनट", "थोड़ा समय", "थोड़ा चेक", "देखने दीजिए",
)
_NOT_AVAILABLE = ("not available", "not here", "not me", "wrong number", "he is not here", "she is not here", "i am not", "not the account holder", "this is not", "that's not me", "my husband", "my wife", "his account", "her account")
_OPT_OUT = ("stop calling", "don't call", "do not call", "don't contact", "do not contact", "remove my number", "opt out", "opt-out", "phone mat karo", "call mat karo", "number hata")
def _has(text: str, phrases: tuple[str, ...]) -> bool:
    return any(phrase in text for phrase in phrases)


def _is_clear_yes(text: str) -> bool:
    value = text.casefold().strip()
    return bool(re.match(r"^(yes|yeah|yep|yup|correct|right|that's right|that is right|it is|it was|haan|han|हाँ|हां|जी)(?:\b|[,!.?])", value))


def _is_clear_no(text: str) -> bool:
    value = text.casefold().strip()
    return bool(re.match(r"^(no|nope|nah|nahi|nahin|नहीं|नही)(?:\b|[,!.?])", value))


def _is_defer_payment_question(text: str) -> bool:
    return _has(text, _DEFER_PAYMENT_CUES) and _has(text, _DEFER_PERIOD_CUES)


def _is_cash_payment_question(text: str) -> bool:
    return "cash" in text and _has(text, _PAYMENT_METHOD_QUESTION_CUES)


def _is_unmapped_payment_question(text: str) -> bool:
    return _has(text, _PAYMENT_TERMS) and _has(text, _QUESTION_CUES)


def _is_payment_purpose_question(text: str) -> bool:
    return _has(text, _PAYMENT_PURPOSE_QUESTION)


def _is_interest_concern(text: str) -> bool:
    return _has(text.casefold(), _INTEREST_CONCERN) or bool(_INTEREST_CONCERN_CUE.search(text))


def _trace_policy(session: CallSession, rule: str, status: str, explanation: str) -> None:
    """Attach a plain-language audit trail for the rule actually evaluated or selected."""
    trace = session.scratch.setdefault("decision_trace", [])
    trace.append({"rule": rule, "status": status, "explanation": explanation})


def _record_waiver_request(session: CallSession, transcript: str) -> TurnResponse:
    task = create_followup_task(session, "waiver_request", transcript, "normal")
    session.outcome = Outcome(
        type=OutcomeType.WAIVER_REQUEST,
        fields={"reason": transcript[:500], "agent_task_id": task["task_id"]},
        follow_up_required=True,
        follow_up_reason="human_review_waiver_request",
    )
    session.pending = None
    session.terminal = True
    return TurnResponse(session_id=session.session_id,
                        bot_text="I can’t approve late-fee discounts or waivers. I’ll note your request, and a human agent will call you back.",
                        terminal=True, outcome=session.outcome)


def _record_dispute(session: CallSession, transcript: str) -> TurnResponse:
    task = create_followup_task(session, "customer_disputes_debt", transcript, "high")
    session.outcome = Outcome(
        type=OutcomeType.DISPUTE_TRANSFER,
        fields={"reason": "customer_disputes_debt", "summary": transcript[:500], "agent_task_id": task["task_id"]},
        follow_up_required=True,
        follow_up_reason="human_review_dispute",
    )
    session.terminal = True
    return TurnResponse(session_id=session.session_id,
                        bot_text="I’m sorry this is causing concern. I’ve noted what you’ve told me, and the team will look into it. I’ll pause the payment discussion and ask a human colleague to follow up.",
                        terminal=True, outcome=session.outcome)


def _record_callback_request(session: CallSession, transcript: str, normalized_text: str | None = None) -> TurnResponse:
    callback_date = _date(normalized_text or transcript)
    task = create_followup_task(session, "customer_requested_callback", transcript, "normal", transcript[:200])
    session.outcome = Outcome(
        type=OutcomeType.CALLBACK_REQUEST,
        fields={"requested_time_text": transcript[:200], "requested_date": callback_date, "agent_task_id": task["task_id"]},
        follow_up_required=True,
        follow_up_reason="customer_requested_callback",
    )
    session.pending = None
    session.terminal = True
    return TurnResponse(session_id=session.session_id,
                        bot_text="Thanks. I’ve passed your preferred callback time to our team.",
                        terminal=True, outcome=session.outcome)


def _record_payment_link_request(session: CallSession, transcript: str) -> TurnResponse:
    task = create_followup_task(session, "payment_link_request", transcript, "normal")
    session.outcome = Outcome(
        type=OutcomeType.PAYMENT_LINK_REQUEST,
        fields={"reason": "customer_requested_payment_link", "agent_task_id": task["task_id"]},
        follow_up_required=True,
        follow_up_reason="payment_link_request",
    )
    session.pending = None
    session.terminal = True
    return TurnResponse(
        session_id=session.session_id,
        bot_text="I’ve noted your request for a payment link. A colleague will call you back about it.",
        terminal=True,
        outcome=session.outcome,
    )


def _record_payment_question_follow_up(session: CallSession, transcript: str, question_type: str) -> TurnResponse:
    task = create_followup_task(
        session,
        "payment_policy_question",
        f"Customer asked about {question_type}. Caller’s question: {transcript[:400]}",
        "normal",
    )
    session.outcome = Outcome(
        type=OutcomeType.NO_COMMITMENT,
        fields={"reason": "payment_policy_not_available_to_bot", "question_type": question_type, "agent_task_id": task["task_id"]},
        follow_up_required=True,
        follow_up_reason="payment_policy_question",
    )
    session.pending = None
    session.terminal = True
    return TurnResponse(
        session_id=session.session_id,
        bot_text="I don’t want to give you incorrect information. I’ve noted your question, and a colleague will look into it and call you back.",
        terminal=True,
        outcome=session.outcome,
    )


def _start_balance_verification(session: CallSession, transcript: str) -> TurnResponse:
    """Start OTP verification as the direct next step for an explicit balance request."""
    _trace_policy(session, "Account-information verification", "triggered", "The customer explicitly asked for the bank-recorded balance; OTP verification is the next action before disclosure.")
    if session.scratch.get("balance_verified"):
        return _reply(session, "Your balance was already checked earlier in this call. Is there anything about the balance or minimum due you’d like me to clarify?")
    try:
        challenge = bank_services.issue_otp(session.request.customer_id, session.request.account_id,
                                            session.request.contact_point_id)
    except ValueError:
        task = create_followup_task(session, "balance_verification_unavailable", transcript, "normal")
        session.outcome = Outcome(type=OutcomeType.NO_COMMITMENT,
                                 fields={"reason": "balance_verification_unavailable", "agent_task_id": task["task_id"]},
                                 follow_up_required=True, follow_up_reason="human_follow_up_needed")
        session.terminal = True
        return TurnResponse(session_id=session.session_id,
                            bot_text="I’m unable to verify the account through the bank service. I’ve noted your request, and the team will look into it and call you back.",
                            terminal=True, outcome=session.outcome)
    session.pending = "otp_code"
    session.scratch["otp_challenge_id"] = challenge["challenge_id"]
    return TurnResponse(session_id=session.session_id,
                        bot_text="I can check that for you. I’ve sent a six-digit verification code to your registered contact. Please enter it in the verification field on the screen; don’t say the code aloud.",
                        metadata={"otp_challenge_id": challenge["challenge_id"], "expires_at": challenge["expires_at"]})
def _date(text: str) -> str | None:
    iso = re.search(r"\b(20\d{2}-\d{2}-\d{2})\b", text)
    if iso:
        try:
            return datetime.fromisoformat(iso.group(1)).date().isoformat()
        except ValueError:
            return None
    numeric = re.search(r"\b([0-3]?\d)[/-]([01]?\d)(?:[/-](20\d{2}))?\b", text)
    if numeric:
        year = int(numeric.group(3) or datetime.now(timezone.utc).year)
        try:
            return datetime(year, int(numeric.group(2)), int(numeric.group(1))).date().isoformat()
        except ValueError:
            return None
    month_numbers = {
        "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
        "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
    }
    ordinals = {
        "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6,
        "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10, "eleventh": 11,
        "twelfth": 12, "thirteenth": 13, "fourteenth": 14, "fifteenth": 15,
        "sixteenth": 16, "seventeenth": 17, "eighteenth": 18, "nineteenth": 19,
        "twentieth": 20, "twenty-first": 21, "twenty second": 22, "twenty-second": 22,
        "twenty-third": 23, "twenty third": 23, "twenty-fourth": 24, "twenty fourth": 24,
        "twenty-fifth": 25, "twenty fifth": 25, "twenty-sixth": 26, "twenty sixth": 26,
        "twenty-seventh": 27, "twenty seventh": 27, "twenty-eighth": 28, "twenty eighth": 28,
        "twenty-ninth": 29, "twenty ninth": 29, "thirtieth": 30, "thirty-first": 31,
        "thirty first": 31,
    }
    day_token = r"(?P<day>\d{1,2}(?:st|nd|rd|th)?|[a-z]+(?:[- ][a-z]+)?)"
    month_pattern = "|".join(month_numbers)
    named = re.search(rf"\b(?P<month>{month_pattern})\s+{day_token}(?:,?\s+(?P<year>20\d{{2}}))?\b", text, re.IGNORECASE)
    if named:
        month, day_text, year_text = named.group("month").lower(), named.group("day").lower(), named.group("year")
        day = int(re.match(r"\d+", day_text).group()) if re.match(r"\d+", day_text) else ordinals.get(day_text)
        if day is None:
            return None
        year = int(year_text) if year_text else datetime.now(timezone.utc).year
        try:
            return datetime(year, month_numbers[month], day).date().isoformat()
        except ValueError:
            return None
    named = re.search(rf"\b{day_token}\s+(?P<month>{month_pattern})(?:,?\s+(?P<year>20\d{{2}}))?\b", text, re.IGNORECASE)
    if named:
        day_text, month, year_text = named.group("day").lower(), named.group("month").lower(), named.group("year")
        day = int(re.match(r"\d+", day_text).group()) if re.match(r"\d+", day_text) else ordinals.get(day_text)
        if day is None:
            return None
        year = int(year_text) if year_text else datetime.now(timezone.utc).year
        try:
            return datetime(year, month_numbers[month], day).date().isoformat()
        except ValueError:
            return None
    return None


def _mode(text: str) -> str | None:
    for word, mode in (("upi", "UPI"), ("net banking", "net_banking"), ("imps", "IMPS"),
                       ("neft", "NEFT"), ("cheque", "cheque"), ("cash", "cash"),
                       ("card", "card"), ("autopay", "autopay")):
        if word in text:
            return mode
    return None


def _record_paid_for_manual_reconciliation(session: CallSession, transcript: str) -> TurnResponse:
    timing = session.scratch.get("reported_payment_date_text")
    mode = session.scratch.get("reported_payment_mode")
    details = "Customer reports a payment but could not provide an exact calendar date"
    if timing:
        details += f"; approximate timing reported: {timing}"
    if not mode:
        details += " and payment mode was not confirmed"
    details += f"; latest response: {transcript[:120]}"
    task = create_followup_task(session, "payment_reconciliation_review", details, "normal")
    fields = {
        "verification_status": "customer_reported",
        "exact_date_provided": False,
        "agent_task_id": task["task_id"],
    }
    if timing:
        fields["reported_payment_date_text"] = timing
    if mode:
        fields["reported_payment_mode"] = mode
    session.outcome = Outcome(
        type=OutcomeType.ALREADY_PAID_REPORTED,
        fields=fields,
        follow_up_required=True,
        follow_up_reason="payment_reconciliation_review",
    )
    session.pending = None
    session.terminal = True
    return TurnResponse(
        session_id=session.session_id,
        bot_text="No problem. I’ve noted that you made a payment, and I’ve asked our team to check the payment records and get back to you. That’s all the information I needed, so I’ll end the call now. Goodbye.",
        terminal=True,
        outcome=session.outcome,
    )


def _payment_age_days(paid_date: str) -> int | None:
    try:
        return (datetime.now(timezone.utc).date() - date.fromisoformat(paid_date)).days
    except (TypeError, ValueError):
        return None


def _more_than_one_month_ago(paid_date: str) -> bool:
    try:
        today = datetime.now(timezone.utc).date()
        previous_month = today.month - 1 or 12
        year = today.year - (1 if today.month == 1 else 0)
        cutoff = date(year, previous_month, min(today.day, calendar.monthrange(year, previous_month)[1]))
        return date.fromisoformat(paid_date) < cutoff
    except (TypeError, ValueError):
        return False


def _is_uncertain_confirmation(text: str, extracted: dict | None) -> bool:
    confidence = (extracted or {}).get("intent_confidence")
    dialogue_act = (extracted or {}).get("dialogue_act")
    return (
        _has(text, _UNCERTAIN_CONFIRMATION)
        or confidence in {"medium", "low"}
        or dialogue_act == "cannot_provide"
        or (extracted or {}).get("pending_slot_status") == "cannot_provide"
    )


def _record_old_payment_for_review(session: CallSession, most_recent_status: str) -> TurnResponse:
    paid_date = session.scratch.get("reported_payment_date") or session.scratch.get("older_payment_date")
    mode = session.scratch.get("reported_payment_mode")
    date_detail = f"dated {paid_date}" if paid_date else "with no date provided"
    summary = f"Customer reported a payment {date_detail}; most-recent status: {most_recent_status}"
    summary += f"; payment mode: {mode}." if mode else "; payment mode was not confirmed."
    task = create_followup_task(session, "payment_reconciliation_review", summary, "normal")
    fields = {
        "verification_status": "customer_reported",
        "most_recent_payment_status": most_recent_status,
        "agent_task_id": task["task_id"],
    }
    if paid_date:
        fields["reported_payment_date"] = paid_date
    if mode:
        fields["reported_payment_mode"] = mode
    session.outcome = Outcome(
        type=OutcomeType.ALREADY_PAID_REPORTED,
        fields=fields,
        follow_up_required=True,
        follow_up_reason="payment_reconciliation_review",
    )
    session.pending = None
    session.terminal = True
    mode_text = f" via {mode.replace('_', ' ')}" if mode else ""
    return TurnResponse(
        session_id=session.session_id,
        bot_text=(f"Thank you. I’ve noted the payment details{mode_text}. "
                  "I’ll share this with a human colleague to check and get back to you. "
                  "That’s all the information I needed, so I’ll end the call now. Goodbye."),
        terminal=True,
        outcome=session.outcome,
    )


def _continue_reported_payment(session: CallSession, paid_date: str, mode: str | None, *, most_recent_confirmed: bool = False) -> TurnResponse:
    age_days = _payment_age_days(paid_date)
    if age_days is not None and age_days < 0:
        session.pending = "paid_date"
        return _reply(session, "That date appears to be in the future. What date did you make the payment?")

    session.scratch["reported_payment_date"] = paid_date
    if mode:
        session.scratch["reported_payment_mode"] = mode
    if _more_than_one_month_ago(paid_date):
        if most_recent_confirmed:
            if mode:
                _trace_policy(session, "Old most-recent payment review", "triggered", "The caller supplied the most recent payment date and mode, but the date is more than one calendar month old; a human colleague will review it.")
                return _record_old_payment_for_review(session, "confirmed")
            session.pending = "paid_most_recent_mode"
            return _reply(session, "Which payment mode did you use for that most recent payment?")
        session.pending = "paid_most_recent_confirmation"
        _trace_policy(session, "Most-recent payment check", "triggered", "The reported payment is more than one calendar month old; the bot asks whether it is the most recent payment.")
        return _reply(session, "That payment was more than a month ago. Is it the most recent payment you made?")
    if age_days is not None and age_days <= 2:
        _trace_policy(session, "Recent payment processing window", "selected", "The reported payment is within two days; if the ledger has not updated, the bot explains the two-working-day posting window without raising an immediate reconciliation task.")
    elif age_days is not None:
        _trace_policy(session, "Payment reconciliation window", "selected", "The reported payment is between three and 30 days old; an unconfirmed ledger entry is referred to a human agent.")
    if not mode:
        session.pending = "paid_mode"
        return _reply(session, "Thank you. Which payment mode did you use—UPI, net banking, cheque, or another method?")
    return _finish_paid(session, paid_date, mode)


def process_turn(
    session: CallSession,
    transcript: str,
    extracted: dict | None = None,
    *,
    heard_before_opening: bool = False,
) -> TurnResponse:
    """Conservative rule-based starter. Critical actions are policy-ordered."""
    session.scratch["decision_trace"] = []
    text = transcript.casefold().strip()
    original_text = text
    approximate_payment_date = bool(extracted and extracted.get("date_precision") == "approximate")
    commitment_intent_uncertain = False
    balance_check_consented = False
    explicit_balance_info_request = bool(_BALANCE_INFO_REQUEST.search(original_text))
    if explicit_balance_info_request and session.scratch.get("right_party_confirmed"):
        extracted = dict(extracted or {})
        extracted.update({
            "intent": "balance_question",
            "intent_confidence": "high",
            "dialogue_act": "asks_question",
            "summary": "The caller explicitly requested their account balance.",
            "acknowledgment": "You’re asking for your account balance.",
        })
        text += " what is my balance"
    if extracted:
        intent = extracted.get("intent")
        # Explicit unwillingness is a distinct caller intent, even if the model
        # loosely labels the utterance as a payment question or unclear.
        if _has(original_text, _PAYMENT_REFUSAL):
            intent = "payment_refusal"
            extracted["intent"] = intent
        # Conditional offer requests are not commitments, even when the utterance
        # also contains wording like “then I will pay”.
        late_fee_discount = _has(original_text, _LATE_FEE_DISCOUNT)
        conditional_offer = not late_fee_discount and (_has(original_text, _OFFER_REQUEST) or (
            "offer" in original_text and any(cue in original_text for cue in ("only then", "before i pay", "before paying", "only if"))
        ))
        if late_fee_discount:
            intent = "waiver"
            extracted["intent"] = intent
        elif conditional_offer:
            intent = "offer_request"
            extracted["intent"] = intent
        if _has(original_text, _PAYMENT_LINK):
            intent = "payment_link_request"
            extracted["intent"] = intent
        elif _is_defer_payment_question(original_text):
            intent = "defer_payment_question"
            extracted["intent"] = intent
        elif _is_cash_payment_question(original_text):
            intent = "payment_method_question"
            extracted["intent"] = intent
        confidence = extracted.get("intent_confidence")
        negated_commitment = (
            not conditional_offer
            and intent in {"promise_to_pay", "unclear"}
            and _has(original_text, _NEGATED_COMMITMENT)
        )
        commitment_language_uncertain = (
            intent == "promise_to_pay" and confidence != "high"
        ) or (
            intent == "unclear" and confidence in {"medium", "low"} and _has(original_text, _COMMITMENT_CUES)
        )
        if intent == "promise_to_pay" or commitment_language_uncertain or negated_commitment:
            if confidence != "high" or negated_commitment:
                commitment_intent_uncertain = True
                intent = "unclear"
                extracted["intent"] = intent
            _trace_policy(
                session,
                "Commitment-intent confidence gate",
                "clarification required" if commitment_intent_uncertain else "passed",
                ("The utterance includes negated payment intent; commitment capture is blocked pending clarification." if negated_commitment
                 else f"The LLM classified payment intent with {confidence or 'missing'} confidence; commitment capture is allowed only for high-confidence intent."),
            )
        dialogue_act = extracted.get("dialogue_act")
        summary = str(extracted.get("summary") or "").casefold()
        # Keep a false-positive balance classification from issuing an OTP. An OTP
        # challenge is allowed only when the caller clearly asks for balance/due data.
        explicit_balance_request = explicit_balance_info_request or _has(original_text, _BALANCE) or any(
            cue in summary for cue in ("asks for balance", "asks about balance", "asks how much is due", "asks amount due")
        )
        if dialogue_act in {"asks_question", "new_request"} and _has(original_text, _OTP_QUESTION):
            intent = "otp_request"
            extracted["intent"] = intent
        elif dialogue_act == "asks_question" and _has(original_text, _CARD_REFERENCE_QUESTION):
            intent = "account_identification_question"
            extracted["intent"] = intent
        elif dialogue_act == "asks_question" and _is_payment_purpose_question(original_text):
            intent = "payment_question"
            extracted["intent"] = intent
        elif intent == "payment_question" and _is_unmapped_payment_question(original_text):
            intent = "payment_policy_question"
            extracted["intent"] = intent
        elif intent == "balance_question" and not explicit_balance_request:
            if _has(original_text, _CARD_REFERENCE_QUESTION) or "which card" in summary or "which account" in summary:
                intent = "account_identification_question"
            elif _is_payment_purpose_question(original_text) or "asks what this payment is about" in summary:
                intent = "payment_question"
            else:
                intent = "unclear"
            extracted["intent"] = intent
            _trace_policy(
                session,
                "Explicit balance request required for OTP",
                "blocked",
                "The classifier suggested a balance question, but the caller did not explicitly request balance or amount-due information; no OTP was issued.",
            )
        if intent == "other_product" and (_has(text, _HURRY) or _has(text, _YOU_CALLED)):
            intent = "unclear"
            extracted["intent"] = intent
        canonical = {
            "already_paid": "already paid", "payment_not_made": "payment has not been made",
            "payment_refusal": "caller does not want to pay",
            "promise_to_pay": "i will pay",
            "payment_commitment_interest": "tentative payment willingness",
            "payment_link_request": "payment link request",
            "defer_payment_question": "question about paying later",
            "payment_method_question": "accepted payment method question",
            "payment_policy_question": "payment policy question needing a colleague",
            "related_question": "related question about the overdue card payment",
            "waiver": "waiver", "dispute": "dispute", "callback": "call me later",
            "distress": "medical emergency", "abuse": "abusive",
            "opt_out": "stop calling",
            "balance_question": "what is my balance", "interest_question": "interest rate",
            "fee_question": "late fee", "fee_applicability": "whether the late fee applies", "credit_score_question": "credit score",
            "legal_question": "legal advice", "other_product": "another product",
            "otp_request": "otp request", "account_identification_question": "which card",
            "payment_question": "pending payment question",
            "offer_request": "offer request",
        }.get(intent)
        if canonical:
            text += " " + canonical
        date_iso = extracted.get("date_iso")
        mode = extracted.get("payment_mode")
        # A model must not turn an explicitly approximate range into a guessed date.
        if date_iso and not approximate_payment_date:
            text += f" {date_iso}"
        if mode:
            text += f" {mode}"
    session.turn_count += 1

    # Safety and required human escalation take precedence over all other intents.
    distress_detected = _has(text, _DISTRESS)
    abuse_detected = _has(text, _ABUSE)
    safety_triggered = distress_detected or abuse_detected
    _trace_policy(
        session,
        "Safety and human-escalation check",
        "triggered" if safety_triggered else "passed",
        "A distress or abuse signal was detected; the bot is escalating." if safety_triggered
        else "No distress or abuse signal was detected.",
    )
    if explicit_balance_info_request and session.scratch.get("right_party_confirmed"):
        _trace_policy(session, "Explicit balance request", "recognized", "The caller explicitly asked for the account balance; the existing OTP verification safeguard will run before any balance is disclosed.")
    if safety_triggered:
        reason = "customer_distress" if distress_detected else "abusive_interaction"
        task = create_followup_task(session, reason, transcript, "urgent" if reason == "customer_distress" else "high")
        transfer = bank_services.request_human_transfer(
            idempotency_key=f"{session.session_id}:{reason}", agent_task_id=task["task_id"],
            case_id=session.request.case_id, episode_id=session.request.episode_id,
            customer_id=session.request.customer_id, account_id=session.request.account_id,
            interaction_id=str(session.session_id), reason=reason,
            priority="urgent" if reason == "customer_distress" else "high",
        )
        session.outcome = Outcome(
            type=OutcomeType.DISPUTE_TRANSFER,
            fields={"reason": reason, "agent_task_id": task["task_id"],
                    "agent_transfer_id": transfer["transfer_id"], "transfer_status": transfer["status"]},
            follow_up_required=True,
            follow_up_reason=reason,
        )
        session.terminal = True
        if distress_detected:
            safety_reply = ("I’m sorry you’re dealing with this. I’ve noted what you shared, and the team will look into it. "
                            "I’ll pause the payment discussion and request a human colleague now. If no one can join, the team will call you back.")
        else:
            safety_reply = ("I’m sorry this call has been frustrating. I’ve noted your concern, and the team will look into it. "
                            "I’ll stop the payment discussion and request a human colleague now. If no one can join, the team will call you back.")
        return TurnResponse(
            session_id=session.session_id,
            bot_text=safety_reply,
            terminal=True,
            outcome=session.outcome,
        )

    opt_out_detected = _has(text, _OPT_OUT)
    _trace_policy(
        session,
        "Contact opt-out check",
        "triggered" if opt_out_detected else "passed",
        "The caller requested no further contact; the opt-out action is being recorded." if opt_out_detected
        else "No opt-out request was detected.",
    )
    if opt_out_detected:
        return record_contact_opt_out(session, "voice_customer_request", transcript[:200])

    if (datetime.now(timezone.utc) - session.started_at).total_seconds() >= 180:
        if session.scratch.get("right_party_confirmed"):
            task = create_followup_task(session, "conversation_time_limit", transcript, "normal")
            session.outcome = Outcome(
                type=OutcomeType.NO_COMMITMENT,
                fields={"reason": "conversation_time_limit", "agent_task_id": task["task_id"]},
                follow_up_required=True,
                follow_up_reason="conversation_time_limit",
            )
            closing = "We’ve reached the end of this call. I’ll ask our team to follow up about your payment. Thank you for your time."
        else:
            session.outcome = Outcome(type=OutcomeType.NO_COMMITMENT, fields={"reason": "identity_confirmation_timeout"})
            closing = "I couldn’t confirm I’m speaking with the right person, so I’ll end this call. Goodbye."
        session.pending = None
        session.terminal = True
        _trace_policy(session, "Three-minute call limit", "triggered", "The conversation reached its three-minute limit; the bot closes with a clear follow-up outcome.")
        return TurnResponse(session_id=session.session_id, bot_text=closing, terminal=True, outcome=session.outcome)

    current_step = session.pending or session.scratch.get("conversation_stage") or "payment_resolution"
    _trace_policy(
        session,
        "Conversation-state check",
        "selected",
        f"The active step is {current_step.replace('_', ' ')}.",
    )

    normalized_greeting = re.sub(r"[^a-z\u0900-\u097f]+", " ", original_text.casefold()).strip()
    # Treat a greeting as a greeting only when the transcript itself is a short
    # greeting. The classifier can label identity answers such as “Yeah, this is
    # Asha Mehta” as `greeting`; allowing that label to take precedence here
    # loops the identity prompt and prevents the identity policy below from
    # seeing the customer's actual answer.
    if normalized_greeting in _GREETING:
        _trace_policy(session, "Greeting handling", "triggered", "A brief greeting was acknowledged while preserving the active identity or payment step.")
        if session.pending == "identity_confirmation":
            contact_name = " ".join(part.strip() for part in (session.request.first_name, session.request.last_name) if part and part.strip()) or "the account holder"
            session.scratch["awaiting_identity_confirmation"] = True
            return _reply(session, f"Hello. Am I speaking with {contact_name}?")
        if session.pending == "paid_date":
            return _reply(session, "Hi. I’m here to help check the payment you mentioned. What date did you make it? If you don’t remember, I can ask our team to check.")
        if session.pending == "paid_mode":
            return _reply(session, "Hi. I’m checking the payment you mentioned. Which method did you use—UPI, net banking, or cheque?")
        if session.pending == "ptp":
            return _reply(session, "Hi. I’m here to help with your overdue minimum payment. When do you expect to pay it?")
        if session.pending == "ptp_confirmation":
            pay_date = session.scratch.get("ptp_date")
            date_label = datetime.fromisoformat(pay_date).strftime("%d %B").lstrip("0") if pay_date else "the date we discussed"
            return _reply(session, f"Hi. I have your expected payment date as {date_label}. Is that correct, or would you like to change it?")
        if session.pending == "callback_time":
            return _reply(session, "Hi. What day or time would be convenient for our team to call you?")
        if session.pending == "balance_check_consent":
            return _reply(session, "Hi. Would you like me to check the bank-recorded balance using OTP verification, or continue with the overdue payment?")
        if session.pending == "otp_code":
            return _reply(session, "Hi. For your security, please enter the six-digit code using the verification field. I can’t accept a spoken code.")
        return _reply(session, "Hi. Your minimum payment on your Mumbai Bank credit card is overdue. Interest is charged at 3.5% per month, and a late fee of ₹750 may apply if your outstanding balance is over ₹10,000. Have you already paid, or when do you expect to pay the minimum amount due?")

    if session.scratch.get("right_party_confirmed"):
        if session.pending == "interest_follow_up_consent":
            if _is_clear_yes(original_text):
                _trace_policy(session, "Interest-charge human review", "accepted", "The customer accepted a colleague follow-up about the account-specific interest concern.")
                concern = session.scratch.pop("interest_concern_transcript", transcript)
                session.pending = None
                return _record_payment_question_follow_up(session, concern, "the account-specific interest charge")
            if _is_clear_no(original_text):
                _trace_policy(session, "Interest-charge human review", "declined", "The customer declined colleague follow-up; the bot stays with the interest topic rather than returning to the payment menu.")
                session.pending = None
                return _reply(session, "Understood. The rate provided for this call is 3.5% per month. I can’t calculate the exact charge here. Is there anything about how the interest works that you’d like me to clarify?")
            if _is_interest_concern(original_text):
                _trace_policy(session, "Interest concern repeated", "acknowledged", "The caller repeated that the interest rate feels too high; the bot acknowledges the concern and keeps the human-review choice active without repeating the generic interest explanation.")
                return _reply(session, "I hear you—the 3.5% monthly interest rate feels too high to you. I can’t change it here, but I can ask a colleague to review your concern and call you. Would you like me to do that?")
            if (extracted or {}).get("dialogue_act") in {"asks_question", "new_request"}:
                session.pending = None
                session.scratch.pop("interest_concern_transcript", None)
            else:
                _trace_policy(session, "Interest-charge human review", "clarification required", "The customer has not clearly accepted or declined a colleague review.")
                return _reply(session, "Would you like me to ask a colleague to look into the interest charge and call you?")
        if session.pending == "balance_check_consent":
            if _has(text, _AFFIRM) or _has(text, _BALANCE_CHECK_CUES) or (extracted or {}).get("intent") == "balance_question":
                balance_check_consented = True
                session.pending = None
                _trace_policy(session, "Balance-verification consent", "confirmed", "The caller agreed to check the bank-recorded balance; the OTP safeguard is now required before disclosure.")
            elif _has(text, _NEGATIVE):
                session.pending = None
                _trace_policy(session, "Balance-verification consent", "declined", "The caller declined the optional balance check; no OTP was issued.")
            elif (
                (extracted or {}).get("intent") not in {None, "unclear", "balance_question"}
                or (extracted or {}).get("dialogue_act") in {"asks_question", "new_request"}
                or _is_defer_payment_question(text)
                or _is_cash_payment_question(text)
                or _has(text, _PAID + _CALLBACK + _PAYMENT_LINK + _WAIVER + _DISPUTE)
            ):
                session.pending = None
                _trace_policy(session, "Balance-verification consent", "cancelled for new request", "The caller changed topic instead of accepting or declining the optional balance check. The pending consent prompt was cleared so the new intent can be handled.")
            else:
                _trace_policy(session, "Balance-verification consent", "clarification required", "The caller’s response did not clearly accept or decline the optional OTP-protected balance check.")
                return _reply(session, "Would you like me to check the bank-recorded balance using OTP verification, or should we continue with the overdue payment?")
        if _has(text, _HURRY) or _has(text, _YOU_CALLED):
            _trace_policy(session, "Keep collections conversation on task", "triggered", "The caller asked for brevity or pointed out that the bank initiated the call; the bot acknowledges this and returns to the payment choices.")
            return _reply(session, "You’re right—I’ll be brief. Your minimum payment is overdue. Interest is charged at 3.5% per month, and a late fee of ₹750 may apply if your outstanding balance is over ₹10,000. Have you already paid, or when do you expect to pay the minimum amount due?")
        if _has(text, _DISPUTE):
            _trace_policy(session, "Debt-dispute handling", "triggered", "The caller disputed the debt; the bot pauses collections and requests human review.")
            return _record_dispute(session, transcript)
        if _has(text, _PAYMENT_LINK) or (extracted or {}).get("intent") == "payment_link_request":
            _trace_policy(session, "Payment-link request", "triggered", "The verified customer requested a payment link. The bot records a colleague follow-up and does not claim to send or trigger the link itself.")
            return _record_payment_link_request(session, transcript)
        if _has(text, _WAIVER):
            _trace_policy(session, "Fee-waiver handling", "triggered", "The caller requested a fee waiver; the bot records a human follow-up task.")
            return _record_waiver_request(session, transcript)
        if _has(text, _CALLBACK) and session.pending != "callback_time":
            has_preferred_time = _date(text) is not None or any(
                marker in text for marker in (" at ", "morning", "afternoon", "evening", " after ", " before ", "between")
            )
            if has_preferred_time:
                _trace_policy(session, "Callback scheduling", "triggered", "The caller requested a callback and supplied a preferred time.")
                return _record_callback_request(session, transcript, text)
            session.pending = "callback_time"
            _trace_policy(session, "Callback scheduling", "triggered", "The caller requested a callback; the bot is collecting a preferred time.")
            return _reply(session, "Of course. What day or time would be convenient for our team to call you?")

        if _has(original_text, _PAYMENT_REFUSAL) or (extracted or {}).get("intent") == "payment_refusal":
            session.pending = None
            _trace_policy(session, "Payment refusal handling", "triggered", "The caller explicitly does not want to pay. The bot asks for the reason; disputes and hardship cases remain governed by their higher-priority escalation rules.")
            return _reply(session, "I understand you don’t want to pay. Is there a concern about the payment, or is something making it difficult to pay?")

    if session.pending == "identity_confirmation":
        _trace_policy(session, "Right-party identity safeguard", "active", "Account details remain protected until the caller confirms they are the account holder.")
        awaiting_full_name = session.scratch.get("awaiting_full_name") is True
        opening_was_delivered = session.scratch.get("identity_opening_delivered") is True
        identity_prompt_was_active = (
            session.scratch.get("awaiting_identity_confirmation") is True
            and opening_was_delivered
            and not heard_before_opening
            and not awaiting_full_name
        )
        # Consume the active prompt. Any clarification response below must
        # explicitly ask the identity question again before a later answer can confirm it.
        session.scratch["awaiting_identity_confirmation"] = False
        _trace_policy(
            session,
            "Identity confirmation prompt state",
            "awaiting response" if identity_prompt_was_active else "no active identity question",
            "A positive answer can confirm identity only when the bot's immediately preceding response asked who it was speaking with.",
        )
        identity_status = (extracted or {}).get("identity_status")
        normalized_identity_reply = re.sub(r"[^a-z\u0900-\u097f]+", " ", text).strip()
        bare_no = normalized_identity_reply in {"no", "nope", "नहीं", "नही", "नहि", "nahi", "nahin"}
        if _has(text, _NOT_AVAILABLE):
            _trace_policy(session, "Identity result", "triggered", "The caller indicated the account holder is unavailable or this is not the account holder.")
            session.pending = None
            session.scratch["right_party_confirmed"] = False
            session.terminal = True
            return TurnResponse(session_id=session.session_id, bot_text="Thank you. I’ll try to reach them another time. Goodbye.", terminal=True)
        contact_name = " ".join(part.strip() for part in (session.request.first_name, session.request.last_name) if part and part.strip()) or "the account holder"
        first_name = re.sub(r"[^a-z0-9\u0900-\u097f]+", " ", (session.request.first_name or "").casefold()).strip()
        last_name = re.sub(r"[^a-z0-9\u0900-\u097f]+", " ", (session.request.last_name or "").casefold()).strip()
        first_present = bool(first_name and re.search(rf"(?<!\w){re.escape(first_name)}(?!\w)", normalized_identity_reply))
        last_present = bool(last_name and re.search(rf"(?<!\w){re.escape(last_name)}(?!\w)", normalized_identity_reply))
        full_name_present = first_present and (last_present or not last_name)
        partial_name_present = (first_present or last_present) and not full_name_present
        self_identification = bool(re.search(
            r"\b(?:i am|i m|this is|my name is|speaking|yes i am|yeah i am)\b|मैं|मेरा नाम|जी मैं|हाँ मैं|हां मैं",
            normalized_identity_reply,
        )) or bool(re.match(r"^(?:yes|yeah|yep|haan|han|ji)\b", normalized_identity_reply))
        exact_full_name = bool(normalized_identity_reply == re.sub(r"[^a-z0-9\u0900-\u097f]+", " ", contact_name.casefold()).strip())
        partial_name_response = partial_name_present and (
            self_identification
            or normalized_identity_reply in {first_name, last_name}
        )

        if partial_name_response:
            attempts = int(session.scratch.get("full_name_clarification_attempts", 0)) + 1
            session.scratch["full_name_clarification_attempts"] = attempts
            if attempts >= 3:
                session.pending = None
                session.terminal = True
                _trace_policy(session, "Full-name verification limit", "triggered", "The caller did not provide the full name after repeated clarification; the call ended without discussing the account.")
                return TurnResponse(session_id=session.session_id, bot_text="I’m unable to confirm I’m speaking with the right person, so I’ll end the call without discussing the account. Goodbye.", terminal=True)
            session.scratch["awaiting_full_name"] = True
            session.scratch["awaiting_identity_confirmation"] = False
            _trace_policy(session, "Partial-name verification", "clarification required", "The caller supplied only part of the named customer’s name; full name is required before discussing the account.")
            return _reply(session, "For security, please confirm your full name, including your first and last name.")

        if awaiting_full_name:
            if full_name_present or exact_full_name:
                identity_prompt_was_active = True
                session.scratch["awaiting_full_name"] = False
                session.scratch["full_name_clarification_attempts"] = 0
            else:
                attempts = int(session.scratch.get("full_name_clarification_attempts", 0)) + 1
                session.scratch["full_name_clarification_attempts"] = attempts
                if attempts >= 3:
                    session.pending = None
                    session.terminal = True
                    _trace_policy(session, "Full-name verification limit", "triggered", "The caller did not provide the full name after repeated clarification; the call ended without discussing the account.")
                    return TurnResponse(session_id=session.session_id, bot_text="I’m unable to confirm I’m speaking with the right person, so I’ll end the call without discussing the account. Goodbye.", terminal=True)
                session.scratch["awaiting_identity_confirmation"] = False
                session.scratch["awaiting_full_name"] = True
                _trace_policy(session, "Full-name verification", "still required", "The caller has not provided both parts of the name needed to complete identity verification.")
                return _reply(session, "I still need your full name, including your first and last name, before I can discuss the account.")

        # A name volunteered before the bot asks the named identity question
        # is not confirmation. The browser-delivered marker is authoritative;
        # the client timing flag is an additional safeguard, not the source of
        # truth.
        unprompted_full_name_confirmation = False
        if (heard_before_opening or not opening_was_delivered) and not awaiting_full_name:
            session.scratch["awaiting_identity_confirmation"] = True
            _trace_policy(session, "Identity opening delivery check", "not delivered", "The server has not recorded that the named identity question was played before this caller response.")
            _trace_policy(session, "Pre-opening caller response", "identity clarification required", "The caller spoke before hearing the named identity prompt; the bot introduces itself and explains that it must confirm the recipient before sharing the specific call reason.")
            return _reply(session, f"Thanks. I’m an automated assistant calling on behalf of Mumbai Bank. Am I speaking with {contact_name}?")

        direct_identity_affirmative = identity_prompt_was_active and normalized_identity_reply in {
            "you are", "yes you are", "yeah you are", "yep you are",
            "you are speaking with me", "you are speaking to me",
        }
        if (identity_status == "not_confirmed" or bare_no) and not direct_identity_affirmative:
            _trace_policy(session, "Identity result", "triggered", "The caller clearly declined or indicated the named person is unavailable after the identity question was asked.")
            session.pending = None
            session.scratch["right_party_confirmed"] = False
            session.terminal = True
            return TurnResponse(session_id=session.session_id, bot_text="Thank you. I’ll try to reach them another time. Goodbye.", terminal=True)

        if _has(text, _FRUSTRATION):
            attempts = int(session.scratch.get("identity_clarification_attempts", 0)) + 1
            session.scratch["identity_clarification_attempts"] = attempts
            if attempts >= 3:
                session.pending = None
                session.terminal = True
                _trace_policy(session, "Identity clarification limit", "triggered", "The caller remained unconfirmed after three turns; the call ended without disclosing account information.")
                return TurnResponse(session_id=session.session_id, bot_text="Sorry, I still can’t confirm I’m speaking with the right person, so I’ll end the call without discussing the account. Goodbye.", terminal=True)
            session.scratch["awaiting_identity_confirmation"] = not awaiting_full_name
            session.scratch["awaiting_full_name"] = False
            return _reply(session, f"I’m sorry this feels frustrating. I’m an automated assistant calling on behalf of Mumbai Bank. Am I speaking with {contact_name}?")
        if _has(text, _IDENTITY_INFO_QUESTION) or (extracted or {}).get("dialogue_act") == "asks_question":
            attempts = int(session.scratch.get("identity_clarification_attempts", 0)) + 1
            session.scratch["identity_clarification_attempts"] = attempts
            _trace_policy(session, "Identity question clarification", "triggered", "The caller asked a question before confirming identity; the bot answers only who it is trying to reach and repeats the identity check.")
            if attempts >= 3:
                session.pending = None
                session.terminal = True
                return TurnResponse(session_id=session.session_id, bot_text="Sorry, I still can’t confirm I’m speaking with the right person, so I’ll end the call without discussing the account. Goodbye.", terminal=True)
            if awaiting_full_name:
                session.scratch["awaiting_full_name"] = True
                session.scratch["awaiting_identity_confirmation"] = False
                return _reply(session, "For your privacy, I need your full name to confirm I’m speaking with the right person. Could you tell me your first and last name?")
            if session.request.first_name or session.request.last_name:
                session.scratch["awaiting_identity_confirmation"] = True
                return _reply(session, f"I’m an automated assistant calling on behalf of Mumbai Bank. Am I speaking with {contact_name}, or are they available?")
            session.scratch["awaiting_identity_confirmation"] = True
            return _reply(session, "I’m an automated assistant calling on behalf of Mumbai Bank. Am I speaking with the account holder, or are they available?")
        llm_confirmed_answer = (
            identity_status == "confirmed"
            and (extracted or {}).get("intent_confidence") == "high"
            and (extracted or {}).get("dialogue_act") == "answers_pending"
        )
        prompted_full_name_answer = full_name_present and (self_identification or exact_full_name)
        if (
            identity_prompt_was_active
            and (_has(text, _AFFIRM) or direct_identity_affirmative or llm_confirmed_answer or prompted_full_name_answer)
        ) or unprompted_full_name_confirmation:
            _trace_policy(session, "Identity result", "confirmed", "The current turn was accepted as confirmation from the account holder.")
            session.pending = None
            session.scratch["right_party_confirmed"] = True
            session.scratch["awaiting_full_name"] = False
            session.scratch["full_name_clarification_attempts"] = 0
            session.scratch["identity_clarification_attempts"] = 0
            session.scratch["conversation_stage"] = "payment_resolution"
            return _reply(session, "Thank you for confirming. Your minimum payment on your Mumbai Bank credit card is overdue. Interest is charged at 3.5% per month, and a late fee of ₹750 may apply if your outstanding balance is over ₹10,000. Have you already paid, or when do you expect to pay the minimum amount due?")
        _trace_policy(session, "Identity result", "not established", "The current turn did not establish that the account holder is speaking; no account details were disclosed.")
        attempts = int(session.scratch.get("identity_clarification_attempts", 0)) + 1
        session.scratch["identity_clarification_attempts"] = attempts
        _trace_policy(session, "Identity clarification limit", "triggered" if attempts >= 3 else "active", f"Unconfirmed identity turn {attempts} of 3; the bot will clarify once more or end without disclosing account information.")
        if attempts >= 3:
            session.pending = None
            session.terminal = True
            return TurnResponse(session_id=session.session_id, bot_text="Sorry, I still can’t confirm I’m speaking with the right person, so I’ll end the call without discussing the account. Goodbye.", terminal=True)
        if session.request.first_name or session.request.last_name:
            session.scratch["awaiting_identity_confirmation"] = True
            return _reply(session, f"Sorry, I didn’t catch that. I’m trying to reach {contact_name}. Are you {contact_name}?")
        session.scratch["awaiting_identity_confirmation"] = True
        return _reply(session, "Sorry, I didn’t catch that. Are you the account holder?")

    # Handle offer requests before pending payment slots. Otherwise a customer
    # asking about an offer while the bot is collecting PTP details gets pushed
    # back into the amount/date question loop.
    late_fee_discount = _has(original_text, _LATE_FEE_DISCOUNT)
    conditional_offer = not late_fee_discount and (_has(original_text, _OFFER_REQUEST) or (
        "offer" in original_text and any(cue in original_text for cue in ("only then", "before i pay", "before paying", "only if"))
    ) or (extracted or {}).get("intent") == "offer_request")
    if session.scratch.get("right_party_confirmed") and conditional_offer:
        _trace_policy(session, "Offer request boundary", "triggered", "A conditional request for an offer is not a payment commitment; no payment amount or date is collected.")
        session.pending = None
        return _reply(session, "I understand you’d like to know the current offer before deciding about payment. I don’t have the offer details available in this call. I can ask our team to contact you about it, or we can continue with the payment options. Which would you prefer?")

    if session.pending == "otp_code":
        # Spoken OTPs are ignored. The voice path also stops forwarding audio to STT in this state.
        return _reply(session, "For your security, please enter the six-digit code using your phone keypad. I can’t accept a spoken code.")

    # An explicit balance question takes priority over whichever conversational
    # prompt was active (for example, payment date or callback timing). Do not
    # send the customer back to the payment menu before starting OTP verification.
    balance_requested_now = (
        explicit_balance_info_request
        or _has(original_text, _BALANCE)
        or (extracted or {}).get("intent") == "balance_question"
    )
    if session.scratch.get("right_party_confirmed") and balance_requested_now:
        session.pending = None
        return _start_balance_verification(session, transcript)

    if session.pending == "ptp_confirmation":
        if _has(text, _AFFIRM):
            _trace_policy(session, "Payment-commitment confirmation", "confirmed", "The caller confirmed the expected payment date; the commitment is recorded.")
            pay_date = session.scratch.get("ptp_date", "")
            session.outcome = Outcome(type=OutcomeType.PROMISE_TO_PAY, fields={"date": pay_date})
            session.pending = None
            session.terminal = True
            return TurnResponse(session_id=session.session_id,
                                bot_text="Thank you for confirming. I’ve recorded your payment commitment. That’s all the information I needed, so I’ll end the call now. Goodbye.",
                                terminal=True, outcome=session.outcome)
        if _has(text, _NEGATIVE):
            _trace_policy(session, "Payment-commitment correction", "triggered", "The caller rejected the proposed date; the bot asks for a replacement date.")
            session.pending = "ptp"
            session.scratch.pop("ptp_date", None)
            return _reply(session, "No problem. What date should I note instead?")
        return _reply(session, "I have your expected payment date as stated. Is that correct, or would you like to change the date?")

    if session.pending == "callback_time":
        _trace_policy(session, "Callback scheduling", "selected", "The bot is recording the requested callback preference for the team.")
        return _record_callback_request(session, transcript, text)

    if session.pending == "paid_most_recent_confirmation":
        supplied_mode = _mode(original_text)
        if supplied_mode:
            session.scratch["reported_payment_mode"] = supplied_mode
        if _has(original_text, _UNCERTAIN_CONFIRMATION):
            _trace_policy(session, "Most-recent payment check", "uncertain", "The caller was unsure whether this was the most recent payment; the bot records the uncertainty and routes it to a human colleague instead of repeating the question.")
            return _record_old_payment_for_review(session, "uncertain")
        if _is_clear_no(original_text):
            _trace_policy(session, "Most-recent payment check", "answered-no", "The caller said the reported old payment was not the most recent; the bot asks for the most recent payment date.")
            session.scratch["older_payment_date"] = session.scratch.pop("reported_payment_date", None)
            session.scratch["older_payment_mode"] = session.scratch.pop("reported_payment_mode", None)
            session.pending = "paid_most_recent_date"
            return _reply(session, "Understood. What date did you make your most recent payment?")
        if _is_clear_yes(original_text):
            _trace_policy(session, "Most-recent payment check", "answered-yes", "The caller confirmed that the reported old payment is their most recent; a human colleague will review it.")
            return _record_old_payment_for_review(session, "confirmed")
        if supplied_mode:
            return _reply(session, "I’ve noted the payment mode. Is that your most recent payment, or was there a later one?")
        if _is_uncertain_confirmation(original_text, extracted):
            _trace_policy(session, "Most-recent payment check", "uncertain", "The caller was unsure whether this was the most recent payment; the bot records the uncertainty and routes it to a human colleague instead of repeating the question.")
            return _record_old_payment_for_review(session, "uncertain")
        return _reply(session, "I’ve noted the payment. Is it your most recent payment, or was there a later one?")

    if session.pending == "paid_most_recent_date":
        if (extracted or {}).get("dialogue_act") == "cannot_provide" or (extracted or {}).get("pending_slot_status") == "cannot_provide":
            return _record_old_payment_for_review(session, "newer_payment_date_not_provided")
        paid_date = _date(text) or (extracted or {}).get("date_iso")
        if not paid_date:
            return _reply(session, "What calendar date did you make your most recent payment?")
        session.scratch["reported_payment_date"] = paid_date
        mode = _mode(text)
        if mode:
            session.scratch["reported_payment_mode"] = mode
            return _continue_reported_payment(session, paid_date, mode, most_recent_confirmed=True)
        session.pending = "paid_most_recent_mode"
        return _reply(session, "Thank you. Which payment mode did you use for that most recent payment?")

    if session.pending == "paid_most_recent_mode":
        mode = _mode(text)
        if mode:
            session.scratch["reported_payment_mode"] = mode
            return _continue_reported_payment(session, session.scratch["reported_payment_date"], mode, most_recent_confirmed=True)
        if (extracted or {}).get("dialogue_act") == "cannot_provide" or (extracted or {}).get("pending_slot_status") == "cannot_provide":
            return _record_old_payment_for_review(session, "confirmed_latest_date_mode_unavailable")
        return _reply(session, "Which payment mode did you use for that most recent payment—UPI, net banking, cheque, cash, or another method?")

    if session.pending in {"paid_date", "paid_mode"}:
        dialogue_act = (extracted or {}).get("dialogue_act")
        pending_slot_status = (extracted or {}).get("pending_slot_status")
        _trace_policy(session, "Payment reconciliation information check", "evaluated", "The bot is checking whether the caller supplied a usable payment date or payment method.")
        # Use facts in the utterance before trusting the classifier's dialogue-act label.
        # In live speech, a date can arrive as a separate short utterance after a fragment
        # such as “I made it on”; the classifier may otherwise call that fragment missing.
        paid_date = _date(text) or (extracted or {}).get("date_iso") or session.scratch.get("reported_payment_date")
        mode = _mode(text) or (extracted or {}).get("payment_mode") or session.scratch.get("reported_payment_mode")
        if paid_date:
            _trace_policy(session, "Payment date and age handling", "selected", "A specific payment date was supplied; date extraction takes precedence over a conflicting missing-detail label.")
            return _continue_reported_payment(session, paid_date, mode)
        if mode:
            session.scratch["reported_payment_mode"] = mode
        if approximate_payment_date:
            _trace_policy(session, "Approximate-date handling", "triggered", "The caller gave an approximate time, so the bot will not treat it as an exact date or run a reconciliation lookup.")
            session.scratch["reported_payment_date_text"] = transcript[:120]
            mode = _mode(text)
            if mode:
                session.scratch["reported_payment_mode"] = mode
            attempts = int(session.scratch.get("payment_date_clarification_attempts", 0)) + 1
            session.scratch["payment_date_clarification_attempts"] = attempts
            if attempts >= 2:
                return _record_paid_for_manual_reconciliation(session, transcript)
            return _reply(session, "I understand the timing is approximate. I need an exact calendar date to check the payment. What date should I use? If you’re not sure, tell me and I’ll ask our team to check.")
        if dialogue_act == "asks_question" or pending_slot_status == "question":
            _trace_policy(session, "Question-during-information-collection", "triggered", "The caller asked a question while a payment detail is pending; the reply explains why that detail is needed.")
            return _reply(session, "I can’t calculate that without a payment date. If you remember the exact date or roughly when you paid, tell me; if not, I can ask our team to check.")
        if _has(text, _NEEDS_TIME_TO_CHECK) or dialogue_act == "cannot_provide" or pending_slot_status == "cannot_provide":
            attempts = int(session.scratch.get("payment_date_wait_attempts", 0)) + 1
            session.scratch["payment_date_wait_attempts"] = attempts
            if attempts == 1 or _has(text, _NEEDS_TIME_TO_CHECK):
                _trace_policy(session, "Give customer time to check payment date", "triggered", "The customer needs time or the classifier marked a fragmented response as missing; the date question stays open and no follow-up call is created yet.")
                return _reply(session, "No problem—take a moment to check your message or statement. I can wait; tell me the date when you’re ready. If you can’t find it, I can ask a colleague to check.")
            _trace_policy(session, "Payment date unavailable after time to check", "triggered", "The caller still cannot provide a date after being given time; the bot records a human reconciliation follow-up.")
            return _record_paid_for_manual_reconciliation(session, transcript)
        if mode:
            session.pending = "paid_date"
            return _reply(session, "Got it. Take a moment if you need to check—what date did you make the payment?")
        return _reply(session, "Okay, I can check that for you. What date did you pay, and was it through UPI, net banking, or cheque?")

    if session.pending == "paid_mode":
        mode = _mode(text)
        if mode:
            return _finish_paid(session, session.scratch["reported_payment_date"], mode)
        return _reply(session, "And how did you make the payment—through UPI, net banking, or cheque?")

    if _has(original_text, _NOT_PAID) or (extracted or {}).get("intent") == "payment_not_made":
        _trace_policy(session, "Unpaid-status handling", "triggered", "The caller said the payment has not been made; the bot asks about the reason or expected date without treating this as a commitment.")
        session.pending = None
        return _reply(session, "I understand you haven’t paid yet. Is something making it difficult to pay, or do you know when you can make the payment?")

    if session.pending == "ptp":
        if commitment_intent_uncertain:
            _trace_policy(session, "Pending commitment clarification", "triggered", "The LLM did not confirm willingness to pay with high confidence; the bot clarifies instead of collecting or confirming a date.")
            return _reply(session, "I want to make sure I understood. Are you willing to make a payment, or are you unable to commit right now?")
        _trace_policy(session, "Payment-commitment capture", "evaluated", "The bot needs only the expected payment date; amount is not required by the assignment flow.")
        pay_date = _date(original_text) or (extracted or {}).get("date_iso") or session.scratch.get("ptp_date")
        if pay_date and datetime.fromisoformat(pay_date).date() < datetime.now(timezone.utc).date():
            session.scratch["ptp_date_clarification_attempts"] = int(session.scratch.get("ptp_date_clarification_attempts", 0)) + 1
            if session.scratch["ptp_date_clarification_attempts"] >= 2:
                task = create_followup_task(session, "payment_commitment_date_unclear", transcript, "normal")
                session.outcome = Outcome(type=OutcomeType.NO_COMMITMENT, fields={"reason": "past_or_unclear_payment_date", "agent_task_id": task["task_id"]}, follow_up_required=True, follow_up_reason="payment_commitment_date_unclear")
                session.pending = None
                session.terminal = True
                return TurnResponse(session_id=session.session_id, bot_text="I’m unable to confirm a future payment date, so I’ll ask our team to follow up with you. Thank you for your time.", terminal=True, outcome=session.outcome)
            session.pending = "ptp"
            date_label = datetime.fromisoformat(pay_date).strftime("%d %B").lstrip("0")
            return _reply(session, f"{date_label} has already passed. What future date should I note for your payment?")
        if pay_date:
            session.scratch["ptp_date"] = pay_date
            session.pending = "ptp_confirmation"
            date_label = datetime.fromisoformat(pay_date).strftime("%d %B").lstrip("0")
            return _reply(session, f"You expect to make the payment by {date_label}. Have I got that right?")
        session.pending = "ptp"
        return _reply(session, "When do you expect to make the payment?")

    if _has(text, _PAID):
        _trace_policy(session, "Already-paid handling", "triggered", "The caller reports that payment was made; the bot gathers details needed for reconciliation.")
        if approximate_payment_date:
            session.scratch["reported_payment_date_text"] = transcript[:120]
            session.scratch["payment_date_clarification_attempts"] = 1
            mode = _mode(text)
            if mode:
                session.scratch["reported_payment_mode"] = mode
            session.pending = "paid_date"
            return _reply(session, "I understand the timing is approximate. I need an exact calendar date to check the payment. What date should I use? If you’re not sure, tell me and I’ll ask our team to check.")
        paid_date, mode = _date(text), _mode(text)
        if paid_date:
            _trace_policy(session, "Payment date and age handling", "selected", "An exact reported payment date is available; the policy checks its age before reconciliation or follow-up.")
            return _continue_reported_payment(session, paid_date, mode)
        if mode:
            session.scratch["reported_payment_mode"] = mode
            session.pending = "paid_date"
            return _reply(session, "Thank you. On what date did you make the payment?")
        session.pending = "paid_date"
        return _reply(session, "When did you make the payment, and through which mode?")

    if _has(text, _WAIVER):
        _trace_policy(session, "Fee-waiver handling", "triggered", "The caller requested a late-fee discount or waiver; the bot records a human follow-up and does not approve it.")
        return _record_waiver_request(session, transcript)

    if _has(text, _DISPUTE):
        _trace_policy(session, "Debt-dispute handling", "triggered", "The caller disputed the debt; the bot pauses collections and requests human review.")
        return _record_dispute(session, transcript)

    if _has(text, _CALLBACK):
        _trace_policy(session, "Callback scheduling", "triggered", "The caller requested a callback; the bot is collecting a preferred time.")
        session.pending = "callback_time"
        return _reply(session, "Of course. What day or time would be convenient for our team to call you?")

    classified_intent = (extracted or {}).get("intent")
    if classified_intent == "fee_applicability":
        _trace_policy(session, "Late-fee threshold clarification", "triggered", "The caller asked whether the late fee applies or corrected a balance in response to the fee threshold. The bot acknowledges the point, gives the approved rule, and offers OTP verification without treating a caller-stated amount as verified bank data.")
        session.pending = "balance_check_consent"
        if (extracted or {}).get("dialogue_act") == "corrects_previous":
            reply = "Thanks for clarifying. If the amount you mentioned is accurate, it’s below the ₹10,000 threshold for the ₹750 late fee. I can check the bank-recorded balance after OTP verification. Would you like me to check it now?"
        else:
            reply = "The ₹750 late fee applies only if the bank-recorded outstanding is over ₹10,000. I can check the bank-recorded balance after OTP verification. Would you like me to check it now?"
        return _reply(session, reply)
    if classified_intent == "payment_commitment_interest":
        _trace_policy(session, "Tentative payment-willingness clarification", "triggered", "The caller sounds open to paying but has not made a definite commitment; the bot asks whether they can agree on a date or want to explain a difficulty, without collecting an amount or recording a commitment.")
        return _reply(session, "I hear you may be open to paying. Would you be comfortable agreeing on a date, or would you like to tell me what’s making payment difficult?")
    if classified_intent == "defer_payment_question" or _is_defer_payment_question(original_text):
        _trace_policy(session, "Unconfirmed payment deferral policy", "triggered", "The caller asked whether payment can be postponed. The assignment context does not define an extension policy, so the bot records a colleague follow-up rather than approving or rejecting the request.")
        return _record_payment_question_follow_up(session, transcript, "whether payment can be postponed")
    if classified_intent == "payment_method_question" or _is_cash_payment_question(original_text):
        _trace_policy(session, "Unconfirmed payment-method policy", "triggered", "The caller asked about an unsupported payment method. The bot does not guess bank policy and records a colleague follow-up.")
        return _record_payment_question_follow_up(session, transcript, "whether cash is accepted")
    if classified_intent == "payment_policy_question":
        _trace_policy(session, "Unsupported payment-policy question", "triggered", "The caller asked a payment-process question that is not covered by approved information; the bot records a colleague follow-up instead of improvising.")
        return _record_payment_question_follow_up(session, transcript, "an unsupported payment policy or process")
    if (
        classified_intent in {None, "unclear"}
        and (
            _is_unmapped_payment_question(original_text)
            or (
                _has(original_text, _PAYMENT_TERMS)
                and (extracted or {}).get("dialogue_act") in {"asks_question", "new_request"}
            )
        )
    ):
        _trace_policy(session, "Unmapped payment question", "triggered", "The caller asked a payment-related question that did not match an approved answer. The bot records a colleague follow-up rather than guessing.")
        return _record_payment_question_follow_up(session, transcript, "an unsupported payment policy or process")
    if commitment_intent_uncertain and session.scratch.get("right_party_confirmed"):
        _trace_policy(session, "Ambiguous payment-intent clarification", "triggered", "The LLM did not classify the customer's payment intent with high confidence, so the bot asks what they mean instead of entering commitment capture.")
        return _reply(session, "Just to check I understood: are you willing to make a payment, or are you unable to commit right now?")
    if classified_intent == "offer_request":
        _trace_policy(session, "Offer request boundary", "triggered", "A conditional request for an offer is not a payment commitment; no payment amount or date is collected.")
        return _reply(session, "I understand you’d like to know the current offer before deciding about payment. I don’t have the offer details available in this call. I can ask our team to contact you about it, or we can continue with the payment options. Which would you prefer?")
    if (extracted or {}).get("dialogue_act") == "corrects_previous" and session.scratch.get("right_party_confirmed"):
        _trace_policy(session, "Contextual correction clarification", "triggered", "The caller is correcting or qualifying an earlier point, but the specific correction did not map to an approved topic. The bot acknowledges the correction and asks a focused clarification instead of repeating the generic payment menu.")
        return _reply(session, "Thanks for clarifying. I want to make sure I respond to the right point—what would you like me to correct or explain?")
    if classified_intent == "account_identification_question":
        _trace_policy(session, "Card-reference clarification", "triggered", "The caller asked which card this call concerns; the bot uses only the masked account reference attached to this call.")
        account_reference = session.request.masked_account_reference or ""
        last_four = re.search(r"(\d{4})\D*$", account_reference)
        if last_four:
            reply = (f"I’m referring to the Mumbai Bank card ending in {last_four.group(1)}, which is the account linked to this call. "
                     "I can’t see your other cards here. Have you already paid this card, would you like to tell me when you can pay, or would you prefer a callback?")
        else:
            reply = ("I can only see the Mumbai Bank account linked to this call, and I don’t have its card reference available here. "
                     "Would you prefer a callback to confirm the card, or should we continue with the pending payment?")
        return _reply(session, reply)

    if classified_intent == "payment_question":
        _trace_policy(session, "Pending-payment explanation", "triggered", "The caller asked what payment this call concerns; the bot explains the call purpose without treating it as a balance request.")
        return _reply(session, "This call is about the overdue minimum payment on your Mumbai Bank credit card. Interest is charged at 3.5% per month, and a late fee of ₹750 may apply if the outstanding balance is over ₹10,000. What would you like me to clarify about the payment?")

    if classified_intent == "otp_request":
        _trace_policy(session, "OTP request without protected-data request", "blocked", "The caller asked for an OTP but did not request protected account data; no OTP challenge was created.")
        return _reply(session, "You don’t need an OTP to discuss this payment. I only request one before sharing protected information such as a balance. Are you asking for your balance, or would you like to discuss the pending payment?")

    if _has(text, _BALANCE) or explicit_balance_info_request or balance_check_consented:
        session.pending = None
        return _start_balance_verification(session, transcript)

    if re.search(r"\binterest\b", text) or _has(text, _INTEREST + ("ब्याज",)) or classified_intent == "interest_question":
        if _is_interest_concern(original_text):
            session.pending = "interest_follow_up_consent"
            session.scratch["interest_concern_transcript"] = transcript[:500]
            _trace_policy(session, "Interest concern acknowledgment", "triggered", "The customer expressed concern that interest feels too high. The bot acknowledges the concern, gives only the approved rate, and offers a colleague review instead of reopening the payment menu.")
            return _reply(session, "I understand you’re concerned that the interest feels high. The rate provided for this call is 3.5% per month. I can’t review the exact charge here, but a colleague can look into it. Would you like me to ask them to call you?")
        _trace_policy(session, "Related question: interest explanation", "triggered", "The caller asked a tangential but relevant question about card interest. The bot gives the approved rate and a plain-language explanation, avoids calculating an account-specific charge, and lets the customer continue the related discussion.")
        return _reply(session, "Interest is a charge on an unpaid credit-card balance and may accrue when it remains unpaid past the due date. The rate provided for this call is 3.5% per month; I can’t calculate the exact charge here. Is there anything about the interest you’d like me to clarify?")

    if _has(text, _FEE):
        _trace_policy(session, "Fee disclosure safeguard", "triggered", "The bot gives only the configured fee information and does not claim the fee applies to this account without verification.")
        session.pending = "balance_check_consent"
        return _reply(session, "The late fee is ₹750 when the outstanding balance is over ₹10,000. I can’t confirm whether it applies to your account without secure OTP verification. Would you like me to check the bank-recorded balance now?")

    if classified_intent == "related_question":
        _trace_policy(session, "Related question: approved-context boundary", "triggered", "The caller asked a tangential question connected to the overdue card payment. No approved answer matched, so the bot records a colleague follow-up rather than guessing or dismissing it as unrelated.")
        return _record_payment_question_follow_up(session, transcript, "a related card-payment question not covered by the approved information")

    if _has(text, _CREDIT_SCORE):
        _trace_policy(session, "Collections scope control", "triggered", "Credit-score advice is outside this bot’s scope; the caller is directed to the bank helpline.")
        return _reply(session, "I can’t help with credit-score questions. Please contact the bank helpline for that query. I’m here to help with your pending payment.")

    if _has(text, _LEGAL):
        _trace_policy(session, "Legal-advice boundary", "triggered", "The bot does not provide legal advice and directs the caller to the bank helpline.")
        return _reply(session, "I can’t provide legal advice. Please contact the bank helpline for guidance. I’m here to help with your pending payment.")

    if _has(text, _PRODUCTS):
        _trace_policy(session, "Collections scope control", "triggered", "The requested product is outside this collections conversation.")
        return _reply(session, "I’m only here for your pending payment. For other queries, please visit a branch or call the helpline.")

    if extracted and (
        extracted.get("intent") == "unclear"
        or extracted.get("dialogue_act") in {"asks_question", "new_request"}
    ):
        payment_adjacent = _has(original_text, _PAYMENT_TERMS + _BALANCE + _FEE + _INTEREST) or explicit_balance_info_request
        if payment_adjacent:
            _trace_policy(session, "Payment-adjacent clarification", "triggered", "The caller raised an unclear topic related to the payment; the bot offers a focused clarification and approved next steps.")
            return _reply(session, "I’m not sure which payment detail you mean. Are you asking whether a payment has been received, or would you like me to check the bank-recorded balance after OTP verification?")
        _trace_policy(session, "Unrelated-topic boundary", "triggered", "The caller asked about a topic outside this collections call; the bot declines briefly and returns to the overdue-payment outcome choices.")
        return _reply(session, "I hear you’re asking about something outside this call. I can’t help with unrelated questions here. I’m here about your overdue Mumbai Bank minimum payment. Can you confirm your payment status or by when you will pay?")

    if classified_intent == "promise_to_pay" and (extracted or {}).get("intent_confidence") == "high" and not _has(original_text, _NEGATED_COMMITMENT):
        _trace_policy(session, "Payment-commitment capture", "triggered", "The caller is discussing a future payment; the bot records the expected date without requiring an amount.")
        session.pending = "ptp"
        pay_date = _date(original_text) or (extracted or {}).get("date_iso") or _date(text)
        if pay_date and datetime.fromisoformat(pay_date).date() < datetime.now(timezone.utc).date():
            session.scratch["ptp_date_clarification_attempts"] = int(session.scratch.get("ptp_date_clarification_attempts", 0)) + 1
            if session.scratch["ptp_date_clarification_attempts"] >= 2:
                task = create_followup_task(session, "payment_commitment_date_unclear", transcript, "normal")
                session.outcome = Outcome(type=OutcomeType.NO_COMMITMENT, fields={"reason": "past_or_unclear_payment_date", "agent_task_id": task["task_id"]}, follow_up_required=True, follow_up_reason="payment_commitment_date_unclear")
                session.pending = None
                session.terminal = True
                return TurnResponse(session_id=session.session_id, bot_text="I’m unable to confirm a future payment date, so I’ll ask our team to follow up with you. Thank you for your time.", terminal=True, outcome=session.outcome)
            date_label = datetime.fromisoformat(pay_date).strftime("%d %B").lstrip("0")
            return _reply(session, f"{date_label} has already passed. What future date should I note for your payment?")
        if pay_date:
            session.scratch["ptp_date"] = pay_date
            session.pending = "ptp_confirmation"
            date_label = datetime.fromisoformat(pay_date).strftime("%d %B").lstrip("0")
            return _reply(session, f"You expect to make the payment by {date_label}. Have I got that right?")
        return _reply(session, "When do you expect to make the payment?")

    if session.turn_count >= 8:
        task = create_followup_task(session, "conversation_limit_reached", transcript, "normal")
        session.outcome = Outcome(
            type=OutcomeType.NO_COMMITMENT,
            fields={"reason": "conversation_limit_reached", "agent_task_id": task["task_id"]},
            follow_up_required=True,
            follow_up_reason="human_follow_up_needed",
        )
        session.terminal = True
        return TurnResponse(session_id=session.session_id, bot_text="I’ll arrange for a human agent to follow up. Thank you for your time.", terminal=True, outcome=session.outcome)

    _trace_policy(session, "Payment-resolution prompt", "selected", "No higher-priority intent was selected; the bot offers the supported payment, commitment, and callback paths.")
    return _reply(session, "I can help with the pending payment. Have you already paid, when do you expect to pay, or would you prefer a callback?")


def record_contact_opt_out(session: CallSession, source: str, reason: str = "customer_requested_no_contact") -> TurnResponse:
    bank_services.set_contact_preference(
        session.request.customer_id, session.request.contact_point_id, "voice", True,
        reason[:200], source, "collections-bot",
    )
    session.outcome = Outcome(type=OutcomeType.OPT_OUT, fields={"channel": "voice", "source": source})
    session.pending = None
    session.terminal = True
    return TurnResponse(session_id=session.session_id,
                        bot_text="Understood. I’ve recorded your request not to receive collection calls at this contact point.",
                        terminal=True, outcome=session.outcome)


def process_otp_code(session: CallSession, code: str) -> TurnResponse:
    if session.pending != "otp_code":
        return TurnResponse(session_id=session.session_id, bot_text="There is no active verification request.", terminal=session.terminal, outcome=session.outcome)
    challenge_id = session.scratch.get("otp_challenge_id")
    if not challenge_id or len(code) != 6 or not code.isdigit():
        return _reply(session, "Please enter the six-digit code using your phone keypad.")
    result = bank_services.verify_otp(challenge_id, code)
    if not result["verified"]:
        if result["reason"] == "attempt_limit":
            task = create_followup_task(session, "otp_verification_failed", "OTP verification attempt limit reached", "high")
            session.pending = None
            session.outcome = Outcome(type=OutcomeType.NO_COMMITMENT,
                                     fields={"reason": "otp_verification_failed", "agent_task_id": task["task_id"]},
                                     follow_up_required=True, follow_up_reason="human_follow_up_needed")
            session.terminal = True
            return TurnResponse(session_id=session.session_id,
                                bot_text="I couldn’t complete verification. I’ll arrange for a human agent to help you.",
                                terminal=True, outcome=session.outcome)
        return _reply(session, "That code couldn’t be verified. Please try again using your phone keypad, or say ‘callback’ for help.")
    try:
        balance = bank_services.get_balance(session.request.account_id, result["verification_token"])
    except (PermissionError, LookupError):
        task = create_followup_task(session, "verified_balance_lookup_failed", "Verified balance lookup failed", "high")
        session.pending = None
        session.outcome = Outcome(type=OutcomeType.NO_COMMITMENT,
                                 fields={"reason": "verified_balance_lookup_failed", "agent_task_id": task["task_id"]},
                                 follow_up_required=True, follow_up_reason="human_follow_up_needed")
        session.terminal = True
        return TurnResponse(session_id=session.session_id,
                            bot_text="Verification succeeded, but I couldn’t retrieve the account details. I’ll arrange a human callback.",
                            terminal=True, outcome=session.outcome)
    session.pending = None
    session.scratch["balance_verified"] = True
    session.scratch["otp_challenge_id"] = None
    session.outcome = None
    return TurnResponse(
        session_id=session.session_id,
        bot_text=(f"Your verified current balance is {balance['currency']} {balance['balance']}. "
                  f"The minimum due is {balance['currency']} {balance['minimum_due']}, due by {balance['due_date']}. "
                  "Would you like me to clarify any of those details?"),
    )


def create_followup_task(session: CallSession, reason: str, summary: str, priority: str,
                         callback_time: str | None = None) -> dict:
    return bank_services.create_agent_task(
        idempotency_key=f"{session.session_id}:{reason}",
        case_id=session.request.case_id,
        episode_id=session.request.episode_id,
        customer_id=session.request.customer_id,
        account_id=session.request.account_id,
        reason=reason,
        priority=priority,
        summary=summary,
        callback_time=callback_time,
    )


def _finish_paid(session: CallSession, paid_date: str, mode: str) -> TurnResponse:
    reconciliation = bank_services.reconcile_payment(session.request.account_id, paid_date, mode)
    age_days = _payment_age_days(paid_date)
    recent_payment = age_days is not None and 0 <= age_days <= 2
    ledger_confirmed = reconciliation["status"] == "confirmed"
    needs_follow_up = not ledger_confirmed and not recent_payment
    fields = {
        "reported_payment_date": paid_date,
        "reported_payment_mode": mode,
        "verification_status": "customer_reported",
        "reconciliation_status": reconciliation["status"],
    }
    task_id = None
    if reconciliation.get("payment_id"):
        fields["payment_id"] = reconciliation["payment_id"]
        fields["payment_reference"] = reconciliation.get("reference")
    if needs_follow_up:
        task = create_followup_task(session, "payment_reconciliation_review",
                                     f"Customer reported payment on {paid_date} via {mode}; ledger status: {reconciliation['status']}", "normal")
        task_id = task["task_id"]
        fields["agent_task_id"] = task_id
    session.outcome = Outcome(
        type=OutcomeType.ALREADY_PAID_REPORTED,
        fields=fields,
        follow_up_required=needs_follow_up,
        follow_up_reason="payment_reconciliation_review" if task_id else None,
    )
    session.pending = None
    session.terminal = True
    if ledger_confirmed:
        reply = "Thank you. The bank ledger confirms this payment."
        if recent_payment:
            reply += " It can take up to 2 working days to appear in the account view."
    elif recent_payment:
        reply = "Thank you. I’ve recorded your payment details. It can take up to 2 working days to reflect, so it should appear soon."
    else:
        reply = "Thank you. I’ve recorded the payment details, but the bank ledger hasn’t confirmed the payment yet. I’ve asked a human agent to check the records and get back to you."
    reply += " That’s all the information I needed, so I’ll end the call now. Goodbye."
    return TurnResponse(
        session_id=session.session_id,
        bot_text=reply,
        terminal=True,
        outcome=session.outcome,
    )


def _reply(session: CallSession, text: str) -> TurnResponse:
    return TurnResponse(session_id=session.session_id, bot_text=text, terminal=False, outcome=None)

