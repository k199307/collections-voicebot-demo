from __future__ import annotations

import json
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from .schemas import AttemptDisposition, AttemptRecord, CallSession, FrequencyPolicy
from .storage import connect, is_postgres


class CallBlocked(Exception):
    def __init__(self, reason: str, policy_version: str):
        super().__init__(reason)
        self.reason = reason
        self.policy_version = policy_version


class Repository:
    """SQLite-backed prototype repository with atomic attempt reservations."""

    def __init__(self, path: str):
        self.path = path
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self):
        return connect(self.path)

    @contextmanager
    def _db(self):
        db = self._connect()
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def _initialize(self) -> None:
        with self._db() as db:
            if not is_postgres(self.path):
                db.execute("PRAGMA journal_mode=WAL")
            db.execute(
                """CREATE TABLE IF NOT EXISTS attempts (
                    attempt_id TEXT PRIMARY KEY,
                    case_id TEXT NOT NULL,
                    episode_id TEXT NOT NULL,
                    customer_id TEXT NOT NULL,
                    account_id TEXT NOT NULL,
                    contact_point_id TEXT NOT NULL,
                    campaign_id TEXT,
                    attempted_at TEXT NOT NULL,
                    timezone TEXT NOT NULL,
                    disposition TEXT NOT NULL,
                    ruleset_version TEXT NOT NULL,
                    contact_policy_version TEXT,
                    policy_reason TEXT NOT NULL
                )"""
            )
            db.execute("CREATE INDEX IF NOT EXISTS idx_attempts_customer_time ON attempts(customer_id, attempted_at)")
            db.execute(
                """CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    attempt_id TEXT NOT NULL,
                    case_id TEXT NOT NULL,
                    customer_id TEXT NOT NULL,
                    account_id TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    completed INTEGER NOT NULL DEFAULT 0
                )"""
            )
            db.execute("CREATE INDEX IF NOT EXISTS idx_sessions_case ON sessions(case_id)")
            db.execute(
                """CREATE TABLE IF NOT EXISTS policy_evaluations (
                    evaluation_id TEXT PRIMARY KEY,
                    case_id TEXT NOT NULL,
                    episode_id TEXT NOT NULL,
                    customer_id TEXT NOT NULL,
                    account_id TEXT NOT NULL,
                    contact_point_id TEXT NOT NULL,
                    campaign_id TEXT,
                    evaluated_at TEXT NOT NULL,
                    timezone TEXT NOT NULL,
                    allowed INTEGER NOT NULL,
                    reason TEXT NOT NULL,
                    ruleset_version TEXT NOT NULL,
                    contact_policy_version TEXT,
                    attempt_id TEXT
                )"""
            )
            db.execute("CREATE INDEX IF NOT EXISTS idx_policy_eval_case ON policy_evaluations(case_id, evaluated_at)")
            db.execute(
                """CREATE TABLE IF NOT EXISTS outcome_events (
                    event_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    case_id TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    delivery_status TEXT NOT NULL,
                    delivery_attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT
                )"""
            )

    def reserve_attempt(
        self,
        request: dict[str, Any],
        policy: FrequencyPolicy,
        now: datetime,
    ) -> AttemptRecord:
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        try:
            tz = ZoneInfo(request["timezone"])
        except ZoneInfoNotFoundError as exc:
            raise CallBlocked("invalid_timezone", policy.version) from exc
        local_now = now.astimezone(tz)
        if not (policy.allowed_start_hour <= local_now.hour < policy.allowed_end_hour):
            raise CallBlocked("outside_allowed_call_window", policy.version)

        week_start = now.astimezone(timezone.utc) - timedelta(days=7)
        local_day_start = local_now.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(timezone.utc)

        with self._lock, self._db() as db:
            if is_postgres(self.path):
                # Serialize policy reservations for this customer across app workers/replicas.
                # The lock is transaction-scoped and released when _db commits or rolls back.
                db.execute("SELECT pg_advisory_xact_lock(hashtext(?))", (request["customer_id"],))
            else:
                db.execute("BEGIN IMMEDIATE")
            rows = db.execute(
                """SELECT attempted_at FROM attempts
                   WHERE customer_id = ? AND attempted_at >= ?
                   ORDER BY attempted_at DESC""",
                (request["customer_id"], week_start.isoformat()),
            ).fetchall()
            instants = [datetime.fromisoformat(row["attempted_at"]) for row in rows]
            today_count = sum(1 for item in instants if item >= local_day_start)
            if today_count >= policy.max_attempts_per_local_day:
                raise CallBlocked("local_day_attempt_cap", policy.version)
            if len(instants) >= policy.max_attempts_per_rolling_7_days:
                raise CallBlocked("rolling_7_day_attempt_cap", policy.version)
            if instants and now - instants[0] < timedelta(minutes=policy.min_interval_minutes):
                raise CallBlocked("minimum_interval_not_elapsed", policy.version)

            attempt = AttemptRecord(
                attempt_id=uuid4(),
                case_id=request["case_id"],
                episode_id=request["episode_id"],
                customer_id=request["customer_id"],
                account_id=request["account_id"],
                contact_point_id=request["contact_point_id"],
                campaign_id=request.get("campaign_id"),
                attempted_at=now,
                timezone=request["timezone"],
                disposition=AttemptDisposition.RESERVED,
                ruleset_version=policy.version,
                contact_policy_version=request.get("contact_policy_version"),
            )
            db.execute(
                """INSERT INTO attempts
                   (attempt_id, case_id, episode_id, customer_id, account_id, contact_point_id,
                    campaign_id, attempted_at, timezone, disposition, ruleset_version,
                    contact_policy_version, policy_reason)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    str(attempt.attempt_id), attempt.case_id, attempt.episode_id,
                    attempt.customer_id, attempt.account_id, attempt.contact_point_id,
                    attempt.campaign_id, attempt.attempted_at.isoformat(), attempt.timezone,
                    attempt.disposition.value, attempt.ruleset_version,
                    attempt.contact_policy_version, attempt.policy_reason,
                ),
            )
            db.execute(
                """INSERT INTO policy_evaluations
                   (evaluation_id, case_id, episode_id, customer_id, account_id, contact_point_id,
                    campaign_id, evaluated_at, timezone, allowed, reason, ruleset_version,
                    contact_policy_version, attempt_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'allowed', ?, ?, ?)""",
                (
                    str(uuid4()), request["case_id"], request["episode_id"], request["customer_id"],
                    request["account_id"], request["contact_point_id"], request.get("campaign_id"),
                    now.isoformat(), request["timezone"], policy.version,
                    request.get("contact_policy_version"), str(attempt.attempt_id),
                ),
            )
            return attempt

    def record_blocked_evaluation(self, request: dict[str, Any], at: datetime, version: str, reason: str) -> None:
        with self._db() as db:
            db.execute(
                """INSERT INTO policy_evaluations
                   (evaluation_id, case_id, episode_id, customer_id, account_id, contact_point_id,
                    campaign_id, evaluated_at, timezone, allowed, reason, ruleset_version,
                    contact_policy_version, attempt_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, NULL)""",
                (
                    str(uuid4()), request["case_id"], request["episode_id"], request["customer_id"],
                    request["account_id"], request["contact_point_id"], request.get("campaign_id"),
                    at.isoformat(), request["timezone"], reason, version,
                    request.get("contact_policy_version"),
                ),
            )

    def create_session(self, session: CallSession) -> None:
        with self._db() as db:
            db.execute(
                """INSERT INTO sessions
                   (session_id, attempt_id, case_id, customer_id, account_id, started_at, payload)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    str(session.session_id), str(session.attempt_id), session.request.case_id,
                    session.request.customer_id, session.request.account_id,
                    session.started_at.isoformat(), session.model_dump_json(),
                ),
            )

    def get_session(self, session_id: UUID) -> CallSession | None:
        with self._db() as db:
            row = db.execute("SELECT payload FROM sessions WHERE session_id = ?", (str(session_id),)).fetchone()
        return CallSession.model_validate_json(row["payload"]) if row else None

    def save_session(self, session: CallSession) -> None:
        with self._db() as db:
            db.execute(
                "UPDATE sessions SET payload = ? WHERE session_id = ?",
                (session.model_dump_json(), str(session.session_id)),
            )

    def mark_completed(self, session: CallSession) -> bool:
        with self._db() as db:
            cursor = db.execute(
                "UPDATE sessions SET payload = ?, completed = 1 WHERE session_id = ? AND completed = 0",
                (session.model_dump_json(), str(session.session_id)),
            )
            return cursor.rowcount == 1

    def is_completed(self, session_id: UUID) -> bool:
        with self._db() as db:
            row = db.execute("SELECT completed FROM sessions WHERE session_id = ?", (str(session_id),)).fetchone()
        return bool(row["completed"]) if row else False

    def update_attempt_disposition(self, attempt_id: UUID, disposition: AttemptDisposition) -> None:
        with self._db() as db:
            db.execute(
                "UPDATE attempts SET disposition = ? WHERE attempt_id = ?",
                (disposition.value, str(attempt_id)),
            )

    def save_event(self, event_id: UUID, session_id: UUID, case_id: str, occurred_at: datetime, payload: str) -> None:
        with self._db() as db:
            db.execute(
                """INSERT INTO outcome_events
                   (event_id, session_id, case_id, occurred_at, payload, delivery_status)
                   VALUES (?, ?, ?, ?, ?, 'pending')""",
                (str(event_id), str(session_id), case_id, occurred_at.isoformat(), payload),
            )

    def update_delivery(self, event_id: UUID, status: str, attempts: int, error: str | None = None) -> None:
        with self._db() as db:
            db.execute(
                """UPDATE outcome_events SET delivery_status = ?, delivery_attempts = ?, last_error = ?
                   WHERE event_id = ?""",
                (status, attempts, error, str(event_id)),
            )

    def case_history(self, case_id: str) -> dict[str, list[dict[str, Any]]]:
        with self._db() as db:
            attempts = db.execute(
                "SELECT * FROM attempts WHERE case_id = ? ORDER BY attempted_at DESC", (case_id,)
            ).fetchall()
            outcomes = db.execute(
                "SELECT event_id, occurred_at, payload, delivery_status, delivery_attempts, last_error "
                "FROM outcome_events WHERE case_id = ? ORDER BY occurred_at DESC", (case_id,)
            ).fetchall()
            evaluations = db.execute(
                "SELECT * FROM policy_evaluations WHERE case_id = ? ORDER BY evaluated_at DESC", (case_id,)
            ).fetchall()
        return {
            "attempts": [dict(row) for row in attempts],
            "outcomes": [dict(row) for row in outcomes],
            "policy_evaluations": [dict(row) for row in evaluations],
        }

