from __future__ import annotations

import hashlib
import json
import secrets
import threading
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from uuid import uuid4

from .config import settings
from .storage import connect


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


class MockBankServices:
    """Assignment mock of bank-owned OTP, ledger, agent, and contact-preference APIs."""

    def __init__(self, target: str):
        self.target = target
        self._lock = threading.RLock()
        if settings.mock_bank_enabled:
            self._initialize()

    @contextmanager
    def _db(self):
        if not settings.mock_bank_enabled:
            raise RuntimeError("Mock bank services are disabled; configure the real bank integration adapter")
        db = connect(self.target)
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def _initialize(self) -> None:
        with self._db() as db:
            statements = [
                """CREATE TABLE IF NOT EXISTS mock_accounts (
                    account_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL, balance TEXT NOT NULL,
                    minimum_due TEXT NOT NULL, currency TEXT NOT NULL, due_date TEXT NOT NULL)""",
                """CREATE TABLE IF NOT EXISTS otp_challenges (
                    challenge_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL, account_id TEXT NOT NULL,
                    contact_point_id TEXT NOT NULL, code_hash TEXT NOT NULL, created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'active', verification_token_hash TEXT,
                    token_expires_at TEXT, token_consumed_at TEXT)""",
                """CREATE TABLE IF NOT EXISTS mock_otp_delivery (
                    challenge_id TEXT PRIMARY KEY, code TEXT NOT NULL, sent_at TEXT NOT NULL)""",
                """CREATE TABLE IF NOT EXISTS mock_payments (
                    payment_id TEXT PRIMARY KEY, account_id TEXT NOT NULL, payment_date TEXT NOT NULL,
                    payment_mode TEXT NOT NULL, amount TEXT, status TEXT NOT NULL,
                    reference TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL)""",
                """CREATE TABLE IF NOT EXISTS agent_tasks (
                    task_id TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE,
                    case_id TEXT NOT NULL, episode_id TEXT NOT NULL, customer_id TEXT NOT NULL,
                    account_id TEXT NOT NULL, reason TEXT NOT NULL, priority TEXT NOT NULL,
                    summary TEXT NOT NULL, callback_time TEXT, status TEXT NOT NULL,
                    assigned_to TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""",
                """CREATE TABLE IF NOT EXISTS human_transfers (
                    transfer_id TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE,
                    agent_task_id TEXT NOT NULL, case_id TEXT NOT NULL, episode_id TEXT NOT NULL,
                    customer_id TEXT NOT NULL, account_id TEXT NOT NULL, interaction_id TEXT,
                    reason TEXT NOT NULL, priority TEXT NOT NULL, status TEXT NOT NULL,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""",
                """CREATE TABLE IF NOT EXISTS contact_preferences (
                    customer_id TEXT NOT NULL, contact_point_id TEXT NOT NULL, channel TEXT NOT NULL,
                    opted_out INTEGER NOT NULL, reason TEXT, source TEXT NOT NULL,
                    updated_by TEXT NOT NULL, updated_at TEXT NOT NULL,
                    PRIMARY KEY(customer_id, contact_point_id, channel))""",
                """CREATE TABLE IF NOT EXISTS bank_audit_events (
                    audit_id TEXT PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL,
                    resource_type TEXT NOT NULL, resource_id TEXT NOT NULL,
                    occurred_at TEXT NOT NULL, details_json TEXT NOT NULL)""",
            ]
            for statement in statements:
                db.execute(statement)
            if self.target.startswith(("postgres://", "postgresql://")):
                columns = db.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'human_transfers'").fetchall()
                names = {row["column_name"] for row in columns}
                if "call_sid" in names and "interaction_id" not in names:
                    db.execute("ALTER TABLE human_transfers RENAME COLUMN call_sid TO interaction_id")
            else:
                columns = db.execute("PRAGMA table_info(human_transfers)").fetchall()
                names = {row["name"] for row in columns}
                if "call_sid" in names and "interaction_id" not in names:
                    db.execute("ALTER TABLE human_transfers RENAME COLUMN call_sid TO interaction_id")
            if self.target.startswith(("postgres://", "postgresql://")):
                db.execute("ALTER TABLE otp_challenges ADD COLUMN IF NOT EXISTS token_consumed_at TEXT")
            else:
                columns = db.execute("PRAGMA table_info(otp_challenges)").fetchall()
                if not any(column["name"] == "token_consumed_at" for column in columns):
                    db.execute("ALTER TABLE otp_challenges ADD COLUMN token_consumed_at TEXT")
            seed = db.execute("SELECT account_id FROM mock_accounts WHERE account_id = ?", ("acct-demo-001",)).fetchone()
            if seed is None:
                db.execute(
                    "INSERT INTO mock_accounts (account_id, customer_id, balance, minimum_due, currency, due_date) VALUES (?, ?, ?, ?, ?, ?)",
                    ("acct-demo-001", "cust-demo-001", "18500.00", "1200.00", "INR", date.today().isoformat()),
                )

    def _audit(self, db, actor: str, action: str, resource_type: str, resource_id: str, details: dict[str, Any] | None = None) -> None:
        db.execute(
            "INSERT INTO bank_audit_events (audit_id, actor, action, resource_type, resource_id, occurred_at, details_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (str(uuid4()), actor, action, resource_type, resource_id, _utcnow().isoformat(), json.dumps(details or {}, separators=(",", ":"))),
        )

    def issue_otp(self, customer_id: str, account_id: str, contact_point_id: str, actor: str = "collections-bot") -> dict[str, str]:
        with self._lock, self._db() as db:
            account = db.execute("SELECT customer_id FROM mock_accounts WHERE account_id = ?", (account_id,)).fetchone()
            if account is None or account["customer_id"] != customer_id:
                raise ValueError("account_customer_mismatch")
            challenge_id = str(uuid4())
            code = f"{secrets.randbelow(1_000_000):06d}"
            created = _utcnow()
            expires = created + timedelta(seconds=settings.mock_otp_ttl_seconds)
            db.execute(
                "INSERT INTO otp_challenges (challenge_id, customer_id, account_id, contact_point_id, code_hash, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (challenge_id, customer_id, account_id, contact_point_id, _hash(f"{challenge_id}:{code}"), created.isoformat(), expires.isoformat()),
            )
            # This mock delivery sink is only available through the dev-only, admin-protected API.
            db.execute("INSERT INTO mock_otp_delivery (challenge_id, code, sent_at) VALUES (?, ?, ?)", (challenge_id, code, created.isoformat()))
            self._audit(db, actor, "otp.challenge_issued", "otp_challenge", challenge_id)
            return {"challenge_id": challenge_id, "expires_at": expires.isoformat(), "delivery_status": "mock_sent"}

    def create_browser_demo_account(self, customer_id: str, account_id: str) -> None:
        """Create synthetic identity/account data for the gated browser demo."""
        if settings.app_env not in {"development", "demo"}:
            raise RuntimeError("browser_demo_accounts_are_demo_only")
        with self._db() as db:
            db.execute(
                "INSERT INTO mock_accounts (account_id, customer_id, balance, minimum_due, currency, due_date) VALUES (?, ?, ?, ?, ?, ?)",
                (account_id, customer_id, "18500.00", "1200.00", "INR", date.today().isoformat()),
            )

    def dev_otp_code(self, challenge_id: str, actor: str) -> str | None:
        with self._db() as db:
            row = db.execute("SELECT code FROM mock_otp_delivery WHERE challenge_id = ?", (challenge_id,)).fetchone()
            if row:
                self._audit(db, actor, "otp.dev_code_read", "otp_challenge", challenge_id)
                return row["code"]
        return None

    def verify_otp(self, challenge_id: str, code: str, actor: str = "collections-bot") -> dict[str, Any]:
        with self._lock, self._db() as db:
            challenge = db.execute("SELECT * FROM otp_challenges WHERE challenge_id = ?", (challenge_id,)).fetchone()
            now = _utcnow()
            if challenge is None:
                return {"verified": False, "reason": "challenge_not_found"}
            if challenge["status"] != "active" or now >= datetime.fromisoformat(challenge["expires_at"]):
                db.execute("UPDATE otp_challenges SET status = 'expired' WHERE challenge_id = ?", (challenge_id,))
                self._audit(db, actor, "otp.verification_rejected", "otp_challenge", challenge_id, {"reason": "expired_or_inactive"})
                return {"verified": False, "reason": "expired_or_inactive"}
            attempts = int(challenge["attempts"]) + 1
            if attempts > 5:
                db.execute("UPDATE otp_challenges SET attempts = ?, status = 'locked' WHERE challenge_id = ?", (attempts, challenge_id))
                self._audit(db, actor, "otp.verification_rejected", "otp_challenge", challenge_id, {"reason": "attempt_limit"})
                return {"verified": False, "reason": "attempt_limit"}
            if not secrets.compare_digest(challenge["code_hash"], _hash(f"{challenge_id}:{code}")):
                status = "locked" if attempts >= 5 else "active"
                db.execute("UPDATE otp_challenges SET attempts = ?, status = ? WHERE challenge_id = ?", (attempts, status, challenge_id))
                self._audit(db, actor, "otp.verification_rejected", "otp_challenge", challenge_id, {"reason": "invalid_code", "attempt": attempts})
                return {"verified": False, "reason": "attempt_limit" if status == "locked" else "invalid_code"}
            token = secrets.token_urlsafe(32)
            token_expires = now + timedelta(minutes=10)
            db.execute(
                "UPDATE otp_challenges SET attempts = ?, status = 'verified', verification_token_hash = ?, token_expires_at = ? WHERE challenge_id = ?",
                (attempts, _hash(token), token_expires.isoformat(), challenge_id),
            )
            self._audit(db, actor, "otp.verified", "otp_challenge", challenge_id)
            return {"verified": True, "verification_token": token, "expires_at": token_expires.isoformat(), "account_id": challenge["account_id"]}

    def get_balance(self, account_id: str, verification_token: str, actor: str = "collections-bot") -> dict[str, str]:
        denied = False
        result = None
        with self._lock, self._db() as db:
            now = _utcnow().isoformat()
            grant = db.execute(
                "SELECT challenge_id, account_id FROM otp_challenges WHERE verification_token_hash = ? AND status = 'verified' AND token_expires_at > ? AND token_consumed_at IS NULL",
                (_hash(verification_token), now),
            ).fetchone()
            if grant is None or grant["account_id"] != account_id:
                self._audit(db, actor, "account.balance_access_denied", "account", account_id)
                denied = True
            else:
                consumed = db.execute(
                    "UPDATE otp_challenges SET token_consumed_at = ? WHERE challenge_id = ? AND token_consumed_at IS NULL",
                    (now, grant["challenge_id"]),
                )
                if consumed.rowcount != 1:
                    self._audit(db, actor, "account.balance_access_denied", "account", account_id, {"reason": "grant_already_used"})
                    denied = True
                else:
                    account = db.execute("SELECT balance, minimum_due, currency, due_date FROM mock_accounts WHERE account_id = ?", (account_id,)).fetchone()
                    if account is None:
                        raise LookupError("account_not_found")
                    self._audit(db, actor, "account.balance_read", "account", account_id)
                    result = dict(account)
        if denied:
            raise PermissionError("valid_otp_grant_required")
        return result or {}

    def reconcile_payment(self, account_id: str, payment_date: str, payment_mode: str, actor: str = "collections-bot") -> dict[str, Any]:
        with self._db() as db:
            row = db.execute(
                "SELECT payment_id, amount, status, reference FROM mock_payments WHERE account_id = ? AND payment_date = ? AND lower(payment_mode) = lower(?) ORDER BY created_at DESC LIMIT 1",
                (account_id, payment_date, payment_mode),
            ).fetchone()
            if row is None:
                result = {"status": "unmatched", "payment_id": None, "amount": None, "reference": None}
            else:
                result = {"status": row["status"], "payment_id": row["payment_id"], "amount": row["amount"], "reference": row["reference"]}
            self._audit(db, actor, "payment.reconciliation_checked", "account", account_id, {"status": result["status"], "reported_date": payment_date, "mode": payment_mode})
            return result

    def seed_payment(self, account_id: str, payment_date: str, payment_mode: str, status: str, reference: str, amount: Decimal | None = None, actor: str = "mock-bank-admin") -> dict[str, Any]:
        if status not in {"confirmed", "pending", "reversed"}:
            raise ValueError("invalid_payment_status")
        with self._db() as db:
            payment_id = str(uuid4())
            created_at = _utcnow().isoformat()
            db.execute(
                "INSERT INTO mock_payments (payment_id, account_id, payment_date, payment_mode, amount, status, reference, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (payment_id, account_id, payment_date, payment_mode, str(amount) if amount is not None else None, status, reference, created_at),
            )
            self._audit(db, actor, "payment.mock_seeded", "payment", payment_id, {"status": status, "reference": reference})
            return {"payment_id": payment_id, "status": status, "reference": reference}

    def create_agent_task(self, *, idempotency_key: str, case_id: str, episode_id: str, customer_id: str,
                          account_id: str, reason: str, priority: str, summary: str,
                          callback_time: str | None = None, actor: str = "collections-bot") -> dict[str, Any]:
        with self._lock, self._db() as db:
            existing = db.execute("SELECT * FROM agent_tasks WHERE idempotency_key = ?", (idempotency_key,)).fetchone()
            if existing:
                return dict(existing)
            task_id = str(uuid4())
            now = _utcnow().isoformat()
            db.execute(
                "INSERT INTO agent_tasks (task_id, idempotency_key, case_id, episode_id, customer_id, account_id, reason, priority, summary, callback_time, status, assigned_to, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', NULL, ?, ?)",
                (task_id, idempotency_key, case_id, episode_id, customer_id, account_id, reason, priority, summary[:500], callback_time, now, now),
            )
            self._audit(db, actor, "agent_task.created", "agent_task", task_id, {"reason": reason, "priority": priority})
            return dict(db.execute("SELECT * FROM agent_tasks WHERE task_id = ?", (task_id,)).fetchone())

    def list_agent_tasks(self, status: str | None = None) -> list[dict[str, Any]]:
        with self._db() as db:
            if status is None:
                rows = db.execute("SELECT * FROM agent_tasks ORDER BY created_at").fetchall()
            else:
                rows = db.execute("SELECT * FROM agent_tasks WHERE status = ? ORDER BY created_at", (status,)).fetchall()
            return [dict(row) for row in rows]

    def update_agent_task(self, task_id: str, status: str, assigned_to: str | None, actor: str) -> dict[str, Any] | None:
        if status not in {"queued", "assigned", "in_progress", "completed", "cancelled"}:
            raise ValueError("invalid_task_status")
        with self._db() as db:
            now = _utcnow().isoformat()
            db.execute("UPDATE agent_tasks SET status = ?, assigned_to = ?, updated_at = ? WHERE task_id = ?", (status, assigned_to, now, task_id))
            row = db.execute("SELECT * FROM agent_tasks WHERE task_id = ?", (task_id,)).fetchone()
            if row:
                self._audit(db, actor, "agent_task.updated", "agent_task", task_id, {"status": status})
                return dict(row)
            return None

    def request_human_transfer(self, *, idempotency_key: str, agent_task_id: str, case_id: str,
                               episode_id: str, customer_id: str, account_id: str,
                               interaction_id: str | None, reason: str, priority: str,
                               actor: str = "collections-bot") -> dict[str, Any]:
        with self._lock, self._db() as db:
            existing = db.execute("SELECT * FROM human_transfers WHERE idempotency_key = ?", (idempotency_key,)).fetchone()
            if existing:
                return dict(existing)
            transfer_id = str(uuid4())
            now = _utcnow().isoformat()
            db.execute(
                "INSERT INTO human_transfers (transfer_id, idempotency_key, agent_task_id, case_id, episode_id, customer_id, account_id, interaction_id, reason, priority, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', ?, ?)",
                (transfer_id, idempotency_key, agent_task_id, case_id, episode_id, customer_id, account_id,
                 interaction_id, reason, priority, now, now),
            )
            self._audit(db, actor, "human_transfer.requested", "human_transfer", transfer_id,
                        {"reason": reason, "priority": priority, "agent_task_id": agent_task_id})
            return dict(db.execute("SELECT * FROM human_transfers WHERE transfer_id = ?", (transfer_id,)).fetchone())

    def list_human_transfers(self, status: str | None = None) -> list[dict[str, Any]]:
        with self._db() as db:
            if status is None:
                rows = db.execute("SELECT * FROM human_transfers ORDER BY created_at").fetchall()
            else:
                rows = db.execute("SELECT * FROM human_transfers WHERE status = ? ORDER BY created_at", (status,)).fetchall()
            return [dict(row) for row in rows]

    def update_human_transfer(self, transfer_id: str, status: str, actor: str) -> dict[str, Any] | None:
        if status not in {"queued", "accepted", "connected", "callback_required", "completed", "failed"}:
            raise ValueError("invalid_transfer_status")
        with self._db() as db:
            now = _utcnow().isoformat()
            db.execute("UPDATE human_transfers SET status = ?, updated_at = ? WHERE transfer_id = ?", (status, now, transfer_id))
            row = db.execute("SELECT * FROM human_transfers WHERE transfer_id = ?", (transfer_id,)).fetchone()
            if row:
                self._audit(db, actor, "human_transfer.updated", "human_transfer", transfer_id, {"status": status})
                return dict(row)
            return None

    def set_contact_preference(self, customer_id: str, contact_point_id: str, channel: str, opted_out: bool,
                               reason: str, source: str, actor: str) -> dict[str, Any]:
        now = _utcnow().isoformat()
        with self._db() as db:
            exists = db.execute(
                "SELECT customer_id FROM contact_preferences WHERE customer_id = ? AND contact_point_id = ? AND channel = ?",
                (customer_id, contact_point_id, channel),
            ).fetchone()
            if exists:
                db.execute(
                    "UPDATE contact_preferences SET opted_out = ?, reason = ?, source = ?, updated_by = ?, updated_at = ? WHERE customer_id = ? AND contact_point_id = ? AND channel = ?",
                    (int(opted_out), reason[:200], source, actor, now, customer_id, contact_point_id, channel),
                )
            else:
                db.execute(
                    "INSERT INTO contact_preferences (customer_id, contact_point_id, channel, opted_out, reason, source, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (customer_id, contact_point_id, channel, int(opted_out), reason[:200], source, actor, now),
                )
            self._audit(db, actor, "contact_preference.updated", "contact_point", contact_point_id, {"channel": channel, "opted_out": opted_out, "source": source})
            return {"customer_id": customer_id, "contact_point_id": contact_point_id, "channel": channel,
                    "opted_out": int(opted_out), "reason": reason[:200], "source": source,
                    "updated_by": actor, "updated_at": now}

    def get_contact_preference(self, customer_id: str, contact_point_id: str, channel: str = "voice") -> dict[str, Any]:
        with self._db() as db:
            row = db.execute(
                "SELECT * FROM contact_preferences WHERE customer_id = ? AND contact_point_id = ? AND channel = ?",
                (customer_id, contact_point_id, channel),
            ).fetchone()
        return dict(row) if row else {"customer_id": customer_id, "contact_point_id": contact_point_id, "channel": channel, "opted_out": 0, "reason": None, "source": "default"}

    def is_opted_out(self, customer_id: str, contact_point_id: str, channel: str = "voice") -> bool:
        return bool(self.get_contact_preference(customer_id, contact_point_id, channel)["opted_out"])

    def list_audit_events(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._db() as db:
            rows = db.execute("SELECT * FROM bank_audit_events ORDER BY occurred_at DESC LIMIT ?", (limit,)).fetchall()
            return [dict(row) for row in rows]


bank_services = MockBankServices(settings.database_url or settings.db_path)
