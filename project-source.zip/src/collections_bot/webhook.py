from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

from .config import settings


def deliver_event(payload: dict) -> tuple[str, int, str | None]:
    if not settings.webhook_url:
        return "not_configured", 0, None

    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    last_error = None
    for attempt in range(1, settings.webhook_retries + 1):
        request = urllib.request.Request(
            settings.webhook_url,
            data=body,
            headers={"Content-Type": "application/json", "Idempotency-Key": payload["event_id"]},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=settings.webhook_timeout_seconds) as response:
                if 200 <= response.status < 300:
                    return "delivered", attempt, None
                last_error = f"HTTP {response.status}"
        except (urllib.error.URLError, TimeoutError) as exc:
            last_error = str(exc)[:500]
        if attempt < settings.webhook_retries:
            time.sleep(min(2 ** (attempt - 1), 4))
    return "failed", settings.webhook_retries, last_error

