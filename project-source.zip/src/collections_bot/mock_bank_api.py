from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field

from .bank_services import bank_services
from .config import settings
from .security import authorize


def _mock_enabled() -> None:
    if not settings.mock_bank_enabled:
        raise HTTPException(status_code=404, detail="not_found")


router = APIRouter(prefix="/mock-bank/v1", tags=["mock-bank-apis"], dependencies=[Depends(_mock_enabled)])


class OtpChallengeRequest(BaseModel):
    customer_id: str
    account_id: str
    contact_point_id: str


class OtpVerifyRequest(BaseModel):
    code: str = Field(pattern=r"^\d{6}$")


class PaymentSeedRequest(BaseModel):
    account_id: str
    payment_date: str = Field(pattern=r"^20\d{2}-\d{2}-\d{2}$")
    payment_mode: str
    status: Literal["confirmed", "pending", "reversed"]
    reference: str
    amount: str | None = None


class PaymentReconcileRequest(BaseModel):
    account_id: str
    payment_date: str = Field(pattern=r"^20\d{2}-\d{2}-\d{2}$")
    payment_mode: str


class AgentTaskRequest(BaseModel):
    idempotency_key: str
    case_id: str
    episode_id: str
    customer_id: str
    account_id: str
    reason: str
    priority: Literal["low", "normal", "high", "urgent"] = "normal"
    summary: str = Field(max_length=500)
    callback_time: str | None = None


class AgentTaskUpdate(BaseModel):
    status: Literal["queued", "assigned", "in_progress", "completed", "cancelled"]
    assigned_to: str | None = None


class HumanTransferRequest(BaseModel):
    idempotency_key: str
    agent_task_id: str
    case_id: str
    episode_id: str
    customer_id: str
    account_id: str
    interaction_id: str | None = None
    reason: str
    priority: Literal["normal", "high", "urgent"]


class HumanTransferUpdate(BaseModel):
    status: Literal["queued", "accepted", "connected", "callback_required", "completed", "failed"]


class ContactPreferenceRequest(BaseModel):
    opted_out: bool
    reason: str = Field(default="", max_length=200)
    source: str = Field(default="agent", max_length=80)
    channel: str = Field(default="voice", max_length=30)


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "mock-bank-apis"}


@router.post("/otp/challenges")
def create_otp_challenge(body: OtpChallengeRequest, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization)
    try:
        return bank_services.issue_otp(body.customer_id, body.account_id, body.contact_point_id, actor)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/otp/challenges/{challenge_id}/dev-code")
def get_mock_otp_code(challenge_id: str, authorization: str | None = Header(default=None)) -> dict[str, str | bool]:
    actor = authorize(authorization, admin_only=True)
    if settings.app_env != "development":
        raise HTTPException(status_code=404, detail="not_found")
    code = bank_services.dev_otp_code(challenge_id, actor)
    if code is None:
        raise HTTPException(status_code=404, detail="challenge_not_found")
    return {"challenge_id": challenge_id, "code": code, "mock_only": True}


@router.post("/otp/challenges/{challenge_id}/verify")
def verify_otp(challenge_id: str, body: OtpVerifyRequest, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization)
    result = bank_services.verify_otp(challenge_id, body.code, actor)
    if not result["verified"]:
        # Avoid telling the caller whether a challenge, account, or delivery target exists.
        return {"verified": False, "reason": "verification_failed"}
    return result


@router.get("/accounts/{account_id}/balance")
def get_balance(account_id: str, otp_verification_token: str | None = Header(default=None, alias="X-OTP-Verification-Token"),
                authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization)
    if not otp_verification_token:
        raise HTTPException(status_code=401, detail="otp_verification_required")
    try:
        return bank_services.get_balance(account_id, otp_verification_token, actor)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail="valid_otp_grant_required") from exc
    except LookupError as exc:
        raise HTTPException(status_code=404, detail="account_not_found") from exc


@router.post("/payments")
def seed_payment(body: PaymentSeedRequest, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization, admin_only=True)
    amount = None
    if body.amount is not None:
        try:
            amount = Decimal(body.amount)
        except InvalidOperation as exc:
            raise HTTPException(status_code=422, detail="invalid_amount") from exc
        if amount <= 0:
            raise HTTPException(status_code=422, detail="invalid_amount")
    try:
        return bank_services.seed_payment(body.account_id, body.payment_date, body.payment_mode,
                                          body.status, body.reference, amount, actor)
    except Exception as exc:
        raise HTTPException(status_code=409, detail=f"payment_seed_failed: {type(exc).__name__}") from exc


@router.post("/payments/reconcile")
def reconcile_payment(body: PaymentReconcileRequest, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization)
    return bank_services.reconcile_payment(body.account_id, body.payment_date, body.payment_mode, actor)


@router.post("/agent-tasks")
def create_agent_task(body: AgentTaskRequest, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization)
    return bank_services.create_agent_task(
        idempotency_key=body.idempotency_key,
        case_id=body.case_id,
        episode_id=body.episode_id,
        customer_id=body.customer_id,
        account_id=body.account_id,
        reason=body.reason,
        priority=body.priority,
        summary=body.summary,
        callback_time=body.callback_time,
        actor=actor,
    )


@router.get("/agent-tasks")
def list_agent_tasks(status: str | None = None, authorization: str | None = Header(default=None)) -> dict:
    authorize(authorization, admin_only=True)
    return {"tasks": bank_services.list_agent_tasks(status)}


@router.patch("/agent-tasks/{task_id}")
def update_agent_task(task_id: str, body: AgentTaskUpdate, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization, admin_only=True)
    result = bank_services.update_agent_task(task_id, body.status, body.assigned_to, actor)
    if result is None:
        raise HTTPException(status_code=404, detail="agent_task_not_found")
    return result


@router.post("/human-transfers")
def request_human_transfer(body: HumanTransferRequest, authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization)
    return bank_services.request_human_transfer(
        idempotency_key=body.idempotency_key, agent_task_id=body.agent_task_id,
        case_id=body.case_id, episode_id=body.episode_id, customer_id=body.customer_id,
        account_id=body.account_id, interaction_id=body.interaction_id, reason=body.reason,
        priority=body.priority, actor=actor,
    )


@router.get("/human-transfers")
def list_human_transfers(status: str | None = None, authorization: str | None = Header(default=None)) -> dict:
    authorize(authorization, admin_only=True)
    return {"transfers": bank_services.list_human_transfers(status)}


@router.patch("/human-transfers/{transfer_id}")
def update_human_transfer(transfer_id: str, body: HumanTransferUpdate,
                          authorization: str | None = Header(default=None)) -> dict:
    actor = authorize(authorization, admin_only=True)
    result = bank_services.update_human_transfer(transfer_id, body.status, actor)
    if result is None:
        raise HTTPException(status_code=404, detail="human_transfer_not_found")
    return result


@router.get("/contact-preferences/{customer_id}/{contact_point_id}")
def get_contact_preference(customer_id: str, contact_point_id: str, channel: str = "voice",
                           authorization: str | None = Header(default=None)) -> dict:
    authorize(authorization)
    return bank_services.get_contact_preference(customer_id, contact_point_id, channel)


@router.put("/contact-preferences/{customer_id}/{contact_point_id}")
def set_contact_preference(customer_id: str, contact_point_id: str, body: ContactPreferenceRequest,
                           authorization: str | None = Header(default=None)) -> dict:
    # A bot or agent can record an opt-out; only privileged bank ops can revoke it.
    actor = authorize(authorization, admin_only=not body.opted_out)
    if body.channel not in {"voice", "sms", "email"}:
        raise HTTPException(status_code=422, detail="unsupported_channel")
    return bank_services.set_contact_preference(customer_id, contact_point_id, body.channel,
                                                body.opted_out, body.reason, body.source, actor)


@router.get("/audit-events")
def audit_events(limit: int = 100, authorization: str | None = Header(default=None)) -> dict:
    authorize(authorization, admin_only=True)
    if not 1 <= limit <= 500:
        raise HTTPException(status_code=422, detail="limit_must_be_1_to_500")
    return {"events": bank_services.list_audit_events(limit)}
