from __future__ import annotations

import sqlite3
import threading
from contextlib import AbstractContextManager
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from .config import settings


class PostgresConnection:
    """Small DB-API compatibility wrapper for this prototype's qmark SQL."""

    def __init__(self, connection, pool_context: AbstractContextManager | None = None):
        self.connection = connection
        self.pool_context = pool_context

    def execute(self, statement: str, parameters=()):
        statement = statement.replace("BEGIN IMMEDIATE", "BEGIN")
        statement = statement.replace("?", "%s")
        return self.connection.execute(statement, parameters)

    def commit(self):
        self.connection.commit()

    def rollback(self):
        self.connection.rollback()

    def close(self):
        if self.pool_context:
            self.pool_context.__exit__(None, None, None)
        else:
            self.connection.close()


_pool_lock = threading.Lock()
_pools = {}


def connect(target: str):
    if settings.app_env == "production" and not target.startswith(("postgres://", "postgresql://")):
        raise RuntimeError("APP_ENV=production requires COLLECTIONS_DATABASE_URL to use PostgreSQL")
    if target.startswith(("postgres://", "postgresql://")):
        try:
            import psycopg
            from psycopg.rows import dict_row
        except ImportError as exc:
            raise RuntimeError("PostgreSQL configured; install the psycopg[binary] dependency") from exc
        parsed = urlparse(target)
        query = parse_qs(parsed.query)
        query.setdefault("sslmode", ["verify-full"])
        target = urlunparse(parsed._replace(query=urlencode(query, doseq=True)))
        try:
            from psycopg_pool import ConnectionPool
        except ImportError as exc:
            raise RuntimeError("PostgreSQL configured; install the psycopg[pool,binary] dependency") from exc
        with _pool_lock:
            pool = _pools.get(target)
            if pool is None:
                pool = ConnectionPool(target, kwargs={"row_factory": dict_row}, min_size=1, max_size=12, timeout=5, open=True)
                _pools[target] = pool
        pool_context = pool.connection()
        connection = pool_context.__enter__()
        return PostgresConnection(connection, pool_context)

    path = target
    if target.startswith("sqlite:///"):
        path = target.removeprefix("sqlite:///")
    if path != ":memory:":
        Path(path).expanduser().parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=10, check_same_thread=False)
    connection.row_factory = sqlite3.Row
    return connection


def is_postgres(target: str) -> bool:
    return target.startswith(("postgres://", "postgresql://"))


def close_pools() -> None:
    with _pool_lock:
        pools = list(_pools.values())
        _pools.clear()
    for pool in pools:
        pool.close()
