"""Collections voicebot prototype."""

