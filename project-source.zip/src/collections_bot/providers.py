from __future__ import annotations

import base64
from functools import lru_cache
import json
import re
from datetime import date, timedelta
from time import perf_counter
from urllib.parse import urlencode

import httpx
from openai import AsyncOpenAI
from websockets.legacy.client import connect as websocket_connect

from .config import settings

_BROWSER_TTS_MODEL = "flux-naveen-en"


def voice_provider_name() -> str:
    return settings.voice_provider if settings.voice_provider in {"deepgram", "sarvam"} else "deepgram"


def voice_provider_configured() -> bool:
    if voice_provider_name() == "sarvam":
        return bool(settings.sarvam_api_key)
    return bool(settings.deepgram_api_key)


def llm_provider_name() -> str:
    return settings.llm_provider if settings.llm_provider in {"openai", "gemini"} else "openai"


def classifier_configured() -> bool:
    if llm_provider_name() == "gemini":
        return bool(settings.gemini_api_key)
    return bool(settings.openai_api_key)


INTENT_SCHEMA = {
    "type": "object",
    "properties": {
        "intent": {
            "type": "string",
            "enum": ["greeting", "already_paid", "payment_not_made", "payment_refusal", "promise_to_pay", "payment_commitment_interest", "payment_link_request", "defer_payment_question", "payment_method_question", "payment_policy_question", "related_question", "offer_request", "waiver", "dispute", "callback", "distress", "abuse", "opt_out", "balance_question", "payment_question", "account_identification_question", "otp_request", "interest_question", "fee_question", "fee_applicability", "credit_score_question", "legal_question", "other_product", "unclear"],
        },
        "intent_confidence": {"type": "string", "enum": ["high", "medium", "low"]},
        "amount_inr": {"type": ["string", "null"]},
        "date_iso": {"type": ["string", "null"]},
        "payment_mode": {"type": ["string", "null"]},
        "summary": {"type": "string"},
        "dialogue_act": {
            "type": "string",
            "enum": ["answers_pending", "cannot_provide", "asks_question", "corrects_previous", "new_request", "no_clear_act"],
        },
        "pending_slot_status": {
            "type": "string",
            "enum": ["provided", "cannot_provide", "question", "not_applicable", "unclear"],
        },
        "date_precision": {"type": "string", "enum": ["exact", "approximate", "none"]},
        "date_phrase": {"type": ["string", "null"]},
        "identity_status": {"type": "string", "enum": ["confirmed", "not_confirmed", "unclear"]},
        "acknowledgment": {"type": "string"},
    },
    "required": ["intent", "intent_confidence", "amount_inr", "date_iso", "payment_mode", "summary", "dialogue_act",
                 "pending_slot_status", "date_precision", "date_phrase", "identity_status", "acknowledgment"],
    "additionalProperties": False,
}

INTENT_CANONICAL = {
    "already_paid": "already paid",
    "payment_not_made": "payment has not been made",
    "payment_refusal": "caller does not want to pay",
    "promise_to_pay": "i will pay",
    "payment_commitment_interest": "tentative payment willingness",
    "payment_link_request": "payment link request",
    "defer_payment_question": "question about paying later",
    "payment_method_question": "accepted payment method question",
    "payment_policy_question": "payment policy question needing a colleague",
    "related_question": "related question about the overdue card payment",
    "offer_request": "offer request",
    "waiver": "waiver",
    "dispute": "dispute",
    "callback": "call me later",
    "distress": "medical emergency",
    "abuse": "abusive",
    "opt_out": "stop calling",
    "balance_question": "what is my balance",
    "interest_question": "interest rate",
    "fee_question": "late fee",
    "fee_applicability": "whether the late fee applies",
    "credit_score_question": "credit score",
    "legal_question": "legal advice",
    "other_product": "another product",
    "payment_question": "pending payment question",
    "account_identification_question": "which card",
    "otp_request": "otp request",
}

_FAST_INTENT_PHRASES = {
    "already_paid": ("already paid", "i paid", "payment done", "paid yesterday", "payment kar diya", "bhar diya"),
    "callback": ("call me later", "call back", "callback", "busy right now", "later please"),
}
_DETAIL_MARKERS = re.compile(
    r"\d|\b(today|tomorrow|yesterday|tonight|monday|tuesday|wednesday|thursday|friday|saturday|sunday|"
    r"upi|imps|neft|cheque|check|cash|card|net banking|evening|morning|afternoon|after|before)\b",
    re.IGNORECASE,
)


def fast_classify_utterance(
    transcript: str,
    pending_state: str | None = None,
    reference_date: str | None = None,
) -> dict[str, str | None] | None:
    """Skip the network round trip for simple, high-confidence turns with no details to extract."""
    text = transcript.casefold().strip()
    normalized_greeting = re.sub(r"[^a-z\u0900-\u097f]+", " ", text).strip()
    if normalized_greeting in {
        "hi", "hello", "hey", "hi there", "hello there", "hey there",
        "good morning", "good afternoon", "good evening", "namaste",
        "नमस्ते", "हाय", "हेलो", "हेलो जी",
    }:
        return {
            "intent": "greeting", "intent_confidence": "high", "amount_inr": None,
            "date_iso": None, "payment_mode": None, "summary": "The caller greeted the assistant.",
            "dialogue_act": "answers_pending", "pending_slot_status": "not_applicable",
            "date_precision": "none", "date_phrase": None, "identity_status": "unclear",
        "acknowledgment": "Hello.",
        }
    if any(phrase in text for phrase in (
        "discount regarding the late fee", "discount regarding late fee", "discount on the late fee",
        "discount on late fee", "discount for the late fee", "late fee discount", "late-fee discount",
        "reduce the late fee", "reduce my late fee",
    )):
        return {
            "intent": "waiver", "intent_confidence": "high", "amount_inr": None,
            "date_iso": None, "payment_mode": None, "summary": "The caller requested a discount on the late fee.",
            "dialogue_act": "new_request", "pending_slot_status": "not_applicable",
            "date_precision": "none", "date_phrase": None, "identity_status": "unclear",
            "acknowledgment": "You’re asking for a discount on the late fee.",
        }
    if any(phrase in text for phrase in (
        "not paid yet", "have not paid", "haven't paid", "havent paid", "not made the payment",
        "have not made the payment", "haven't made the payment", "havent made the payment",
        "did not pay", "didn't pay", "didnt pay", "payment is still pending",
        "abhi tak payment nahi", "payment nahi kiya",
    )):
        return {
            "intent": "payment_not_made", "intent_confidence": "high", "amount_inr": None,
            "date_iso": None, "payment_mode": None, "summary": "The caller has not made the payment yet.",
            "dialogue_act": "answers_pending", "pending_slot_status": "provided",
            "date_precision": "none", "date_phrase": None, "identity_status": "unclear",
            "acknowledgment": "You haven’t made the payment yet.",
        }
    cash_question = "cash" in text and any(
        cue in text for cue in ("can i", "could i", "is it", "would", "will you", "accepted", "okay", "allowed", "possible")
    )
    if cash_question:
        return {"intent": "payment_method_question", "intent_confidence": "high", "amount_inr": None, "date_iso": None, "payment_mode": "cash", "summary": "The caller asked whether cash is an accepted payment method."}
    defer_question = any(cue in text for cue in ("is it okay if i pay", "is it okay to pay", "can i pay", "could i pay", "would it be okay if i pay", "would you allow me to pay")) and any(
        cue in text for cue in ("next month", "next week", "later", "after a month", "after one month", "next year")
    )
    if defer_question:
        return {"intent": "defer_payment_question", "intent_confidence": "high", "amount_inr": None, "date_iso": None, "payment_mode": None, "summary": "The caller asked whether they can delay payment."}
    if any(phrase in text for phrase in ("payment link", "pay link", "link to pay", "link for payment", "send me a link", "payment ka link")):
        return {"intent": "payment_link_request", "intent_confidence": "high", "amount_inr": None, "date_iso": None, "payment_mode": None, "summary": "The caller requested a payment link."}
    if any(phrase in text for phrase in (
        "latest offer", "latest offers", "give me an offer", "give me the offer",
        "any offer", "any offers", "discount", "settlement offer", "offer before", "offer first",
    )) or ("offer" in text and any(cue in text for cue in ("only then", "before i pay", "before paying", "only if"))):
        return {"intent": "offer_request", "amount_inr": None, "date_iso": None, "payment_mode": None, "summary": text[:160]}
    if pending_state == "identity_confirmation" and normalized_greeting in {
        "yes", "yeah", "yep", "yes speaking", "speaking", "this is", "this is me",
        "yes this is me", "yes i am", "yes i am speaking", "yeah i am", "yep i am",
        "you are", "yes you are", "yeah you are", "yep you are",
        "you are speaking with me", "you are speaking to me",
        "yes you are speaking with me", "yes you are speaking to me",
        "haan", "han", "haan ji", "han ji", "ji", "ji boliye",
    }:
        return {"intent": "unclear", "amount_inr": None, "date_iso": None, "payment_mode": None, "summary": "Identity confirmation."}
    if pending_state == "ptp_confirmation" and text in {"yes", "yes that's right", "correct", "haan", "han", "ji", "right"}:
        return {"intent": "unclear", "amount_inr": None, "date_iso": None, "payment_mode": None, "summary": "Commitment confirmed."}
    for intent, phrases in _FAST_INTENT_PHRASES.items():
        if not any(phrase in text for phrase in phrases):
            continue
        number = r"[0-9,]+(?:\.[0-9]{1,2})?"
        amount_match = re.search(rf"(?:₹\s*|rs\.?\s*|inr\s*|pay(?:\s+only)?\s+)({number})", text, re.IGNORECASE)
        if not amount_match:
            amount_match = re.search(rf"\b({number})\s*(?:rupees?|inr)\b", text, re.IGNORECASE)
        amount = amount_match.group(1).replace(",", "") if amount_match else None
        date_value = None
        date_match = re.search(r"\b(20\d{2}-\d{2}-\d{2})\b", text)
        if date_match:
            try:
                date_value = date.fromisoformat(date_match.group(1)).isoformat()
            except ValueError:
                return None
        else:
            relative = {"today": 0, "tomorrow": 1, "yesterday": -1,
                        "day after tomorrow": 2}
            matched_relative = next((days for phrase, days in relative.items() if phrase in text), None)
            if matched_relative is not None:
                try:
                    reference = date.fromisoformat(reference_date) if reference_date else date.today()
                    date_value = (reference + timedelta(days=matched_relative)).isoformat()
                except ValueError:
                    return None
        mode_match = re.search(r"\b(upi|net banking|imps|neft|cheque|check|cash|card|autopay)\b", text)
        mode = mode_match.group(1).replace(" ", "_") if mode_match else None
        if _DETAIL_MARKERS.search(text) and not any((amount, date_value, mode)):
            return None
        if _DETAIL_MARKERS.search(text) and any(word in text for word in ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "morning", "afternoon", "evening", "after", "before")):
            return None
        return {"intent": intent, "amount_inr": amount, "date_iso": date_value, "payment_mode": mode, "summary": text[:160]}
    return None


@lru_cache(maxsize=1)
def _openai_client() -> AsyncOpenAI:
    # A retry can double the wait in a live voice turn. The application has a
    # deterministic policy fallback when a single model request times out.
    return AsyncOpenAI(api_key=settings.openai_api_key, timeout=5.0, max_retries=0)


@lru_cache(maxsize=1)
def _gemini_client():
    # Import lazily so existing OpenAI installations do not need to initialize Gemini.
    from google import genai
    from google.genai import types

    return genai.Client(
        api_key=settings.gemini_api_key,
        http_options=types.HttpOptions(timeout=10000),
    )


async def classify_utterance(
    transcript: str,
    pending_state: str | None = None,
    known_fields: dict[str, str] | None = None,
    reference_date: str | None = None,
    conversation_history: list[dict[str, str]] | None = None,
) -> tuple[dict[str, str | None], dict[str, object]]:
    """Interpret the caller's turn and return a brief acknowledgment for policy-approved composition."""
    classifier_started = perf_counter()
    provider = llm_provider_name()
    if provider == "gemini" and not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured")
    if provider == "openai" and not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured")
    prompt_started = perf_counter()
    instructions = (
        "Classify the caller's latest utterance in an Indian credit-card collections call. "
        "Use greeting for a brief greeting such as 'hi' or 'hello' when it does not contain another substantive request; the policy will acknowledge it and continue the current step. "
        "Classify an explicit request for a payment link, pay link, or a link to make the payment as payment_link_request. The application will record a colleague follow-up; do not claim the link has been generated, sent, or triggered. This is not a payment commitment. Use defer_payment_question when the caller asks whether it is acceptable to postpone payment (for example, 'Is it okay if I pay next month?'); this is a question, not a commitment. Use payment_method_question when the caller asks whether a method such as cash is accepted. Use payment_policy_question for other questions about payment policies or processes whose answer is not explicitly supplied in the approved context, such as partial-payment rules, payment allocation, extensions, accepted channels, or how to arrange a payment. These payment-policy questions must be referred to a colleague; do not guess or make up bank policy. Classify a request for a current offer, discount, or settlement terms as offer_request, especially when payment is conditional on receiving an offer; it is not a payment commitment. Use payment_commitment_interest for hedged or tentative willingness, such as 'I may be okay to pay', 'I might pay', or 'maybe I can pay'; this is not yet a commitment and must not enter date capture. The policy will ask whether the caller could agree on a date or wants to explain a difficulty. Use promise_to_pay only for clear, unhedged willingness or a definite future commitment, such as 'I’m okay making a payment commitment' or 'I will pay'. If the caller is clearly willing but has not stated when, ask only for the expected payment date; never ask for an amount or treat amount as a required slot. If the caller volunteers an amount, acknowledge it only if useful and continue by asking for the expected date. Do not record a commitment until the caller confirms the expected date. Do not extract an amount or date from a conditional offer request. "
        "Use payment_not_made when the customer clearly says the overdue payment has not been made yet; this reports status, not a payment commitment. Use payment_refusal when the caller explicitly says they do not want or will not pay (including colloquial forms such as 'I don't wanna pay'); this is a refusal, not a payment question or commitment. The application will acknowledge it and ask for the reason, unless a dispute or hardship rule takes priority. Use waiver for a request to reduce, discount, remove, or waive a late fee; the application records a human follow-up. Use offer_request for other offers or settlement terms. "
        "Set intent_confidence=high only when the intent is explicit and the whole utterance and context support it without contradiction. Use medium when one interpretation is more likely but ambiguity remains; use low for unclear, garbled, contradictory, or unrelated speech. Negated statements such as 'I will not pay', 'I cannot pay', 'I won't make a commitment', or 'I am not willing to pay' must never be promise_to_pay. If a statement can mean either willingness or refusal, use unclear or promise_to_pay with medium/low confidence so policy asks a clarification and does not enter commitment capture. "
        "Interpret the complete recent conversation, not just the latest words. Understand English and Hindi in Devanagari and Latin transliteration, including code-switching. "
        "Use conversation_state and the last assistant question to determine what the caller is answering, correcting, questioning, or unable to provide. "
        "Set dialogue_act=answers_pending when the caller answers the current question; cannot_provide only when they clearly say they do not know, cannot remember, or cannot supply the requested detail. Saying they need a moment, are checking, or will look for the information is not cannot_provide; treat it as a request for time and keep the pending detail open. A fragmented sentence such as 'I made it on' is not proof that the caller cannot provide the date. Use asks_question when they ask a question; corrects_previous when they correct something; new_request for a separate request; otherwise no_clear_act. "
        "Set pending_slot_status based on the specific detail currently requested, not on the overall collections intent. A caller may still be reporting a payment while being unable to provide its exact date. "
        "Extract only facts clearly stated. Normalize an unambiguous relative date such as today, yesterday, or tomorrow using reference_date_local and mark it exact. Set date_precision=exact for a specific day, approximate for a range or imprecise timing, and none when no payment timing is stated. Keep date_iso null for approximate timing; never turn an approximate period into a guessed date. date_phrase may contain only the caller's short stated timing phrase. "
        "If the transcription is garbled, appears to be an unrelated language, or does not clearly express an intent, use unclear with low confidence; never guess a nearby intent. "
        "Write summary as a short, neutral English paraphrase of what the caller meant; do not copy a possibly garbled transcript as the summary. "
        "Also return acknowledgment: a short, specific, speakable English acknowledgment (maximum 15 words) of the caller's latest meaningful point. It must not answer a bank-policy question, state account facts, make promises, ask a question, or select an action. Use an empty string if the caller's meaning is unclear. The application will append this acknowledgment to the deterministic policy response and validate the complete text before speech. "
        "During identity_confirmation, interpret the caller's response to the assistant's question. A direct affirmative that the named person is speaking confirms identity even if the caller does not repeat the name; this includes 'you are' in direct response to 'Am I speaking with [name]?'. Do not require a specific keyword or exact phrase. Set not_confirmed only for a clear denial or unavailable person; otherwise use unclear. In all other states set identity_status to unclear. "
        "Before identity confirmation, if asked who you are or why you are calling, identify yourself as an automated assistant calling on behalf of Mumbai Bank, say you are trying to reach the named person, and ask whether they are speaking. Do not explain the reason for the call until identity is confirmed. "
        "If the caller is frustrated, acknowledge that briefly and respond to their concern without repeating the same question verbatim. "
        "Classify other_product only when the caller explicitly asks about a different bank product. Requests to hurry, get to the point, or reminders that the bank called are conversational cues, not other_product; use unclear unless another clear intent is stated. "
        "Use payment_question when the caller asks what this pending-payment call is about or asks for clarification about the collection purpose. Use account_identification_question when they ask which card/account this call concerns. Use otp_request when they ask for an OTP or verification code. "
        "Use related_question for a brief, tangential question about this overdue card/payment that is not already covered by a dedicated intent—for example, asking what interest means, why interest may accrue, or how the overdue-payment process works. This is still in scope: answer only from approved facts supplied in the context, acknowledge the question, then return naturally to payment status or timing. Do not label such a question unrelated. If the requested detail is not in the approved context, do not guess; the application will arrange a colleague follow-up. Use dedicated interest_question and fee_question when asking for the rate or fee rule, balance_question for bank-recorded amount due, and payment_policy_question for unsupported payment terms or methods. "
        "Use balance_question when the caller explicitly asks for their bank-recorded balance or amount due, including 'Can you tell me the balance?', 'I want to know the balance of my account', 'What is my balance?', and equivalent wording. Asking what pending payment the call concerns, which card is involved, or asking for an OTP alone is NOT a balance request. An OTP must not be requested or sent unless the caller explicitly requests protected account information that requires it. "
        "Use fee_applicability when the caller asks whether a late fee applies, or gives/corrects a balance in response to the late-fee threshold mentioned by the assistant (for example, 'my balance is only five thousand'). This is a contextual statement about the fee rule, not a request to reveal or verify the bank-held balance, and not a payment commitment or a payment amount. Acknowledge the point, explain only the approved fee threshold, and distinguish a customer-stated estimate from the bank-recorded balance, which can be checked after OTP verification. Do not classify it as a generic correction or unclear just because the caller did not phrase it as a question. "
        "Medical emergency, job loss, serious hardship => distress. "
        "Insults or threats directed at the bot => abuse. A request to dispute/not recognize debt => dispute. "
        "For approximate payment timing, leave date_iso null; never normalize an approximate period into a specific calendar date. "
        "Never claim a payment is confirmed, a balance is verified, a fee is due, or an action was completed unless the application state explicitly says so. "
        "Do not reveal debt or account details before right-party confirmation, request spoken OTPs, or contradict an opt-out, dispute, or human-review outcome. "
        "Do not provide financial, legal, or bank facts beyond the supplied context. Return only the required schema."
    )
    input_context = {
        "conversation_state": pending_state or "general conversation",
        "known_fields": known_fields or {},
        "reference_date_local": reference_date,
        "recent_conversation": (conversation_history or [])[-6:],
        "latest_utterance": transcript,
    }
    llm_input = json.dumps(input_context, ensure_ascii=False)
    response_format = {"type": "json_schema", "name": "collection_intent", "strict": True, "schema": INTENT_SCHEMA}
    prompt_build_ms = round((perf_counter() - prompt_started) * 1000, 1)
    request_started = perf_counter()
    try:
        if provider == "gemini":
            from google.genai import types

            response = await _gemini_client().aio.models.generate_content(
                model=settings.gemini_model,
                contents=llm_input,
                config=types.GenerateContentConfig(
                    system_instruction=instructions,
                    response_mime_type="application/json",
                    response_json_schema=INTENT_SCHEMA,
                    max_output_tokens=600,
                    thinking_config=types.ThinkingConfig(thinking_level="minimal"),
                ),
            )
        else:
            response = await _openai_client().responses.create(
                model=settings.openai_model,
                reasoning={"effort": settings.openai_reasoning_effort},
                service_tier=settings.openai_service_tier,
                store=False,
                # The schema is compact; keep generated output bounded to reduce latency.
                max_output_tokens=600,
                instructions=instructions,
                input=llm_input,
                text={"format": response_format},
            )
    except Exception as exc:
        timing = {
            "prompt_build_ms": prompt_build_ms,
            "model_request_ms": round((perf_counter() - request_started) * 1000, 1),
            "response_parse_ms": 0.0,
            "total_ms": round((perf_counter() - classifier_started) * 1000, 1),
            "instructions_chars": len(instructions),
            "input_chars": len(llm_input),
            "recent_turn_count": len(input_context["recent_conversation"]),
            "input_tokens": None,
            "output_tokens": None,
            "cached_input_tokens": None,
        }
        try:
            setattr(exc, "classifier_timing_ms", timing)
        except Exception:
            pass
        raise
    model_request_ms = round((perf_counter() - request_started) * 1000, 1)
    parse_started = perf_counter()
    try:
        response_status = "completed" if provider == "gemini" else response.status
        if response_status != "completed":
            reason = getattr(getattr(response, "incomplete_details", None), "reason", None)
            raise RuntimeError(f"LLM response status={response_status}; incomplete_reason={reason or 'unknown'}")
        output_text = response.text if provider == "gemini" else response.output_text
        if not output_text or not output_text.strip():
            raise RuntimeError("LLM completed without structured output")
        parsed = json.loads(output_text)
    except Exception as exc:
        timing = {
            "prompt_build_ms": prompt_build_ms,
            "model_request_ms": model_request_ms,
            "response_parse_ms": round((perf_counter() - parse_started) * 1000, 1),
            "total_ms": round((perf_counter() - classifier_started) * 1000, 1),
            "instructions_chars": len(instructions),
            "input_chars": len(llm_input),
            "recent_turn_count": len(input_context["recent_conversation"]),
            "input_tokens": None,
            "output_tokens": None,
            "cached_input_tokens": None,
        }
        try:
            setattr(exc, "classifier_timing_ms", timing)
        except Exception:
            pass
        raise
    response_parse_ms = round((perf_counter() - parse_started) * 1000, 1)
    if provider == "gemini":
        usage = getattr(response, "usage_metadata", None)
        input_tokens = getattr(usage, "prompt_token_count", None)
        output_tokens = getattr(usage, "candidates_token_count", None)
        cached_input_tokens = getattr(usage, "cached_content_token_count", None)
        model_name = settings.gemini_model
        service_tier = "standard"
        response_status = "completed"
    else:
        usage = getattr(response, "usage", None)
        input_tokens = getattr(usage, "input_tokens", None)
        output_tokens = getattr(usage, "output_tokens", None)
        input_token_details = getattr(usage, "input_tokens_details", None)
        cached_input_tokens = getattr(input_token_details, "cached_tokens", None)
        model_name = settings.openai_model
        service_tier = getattr(response, "service_tier", settings.openai_service_tier)
        response_status = response.status
    classifier_timings = {
        "prompt_build_ms": prompt_build_ms,
        "model_request_ms": model_request_ms,
        "response_parse_ms": response_parse_ms,
        "total_ms": round((perf_counter() - classifier_started) * 1000, 1),
        "instructions_chars": len(instructions),
        "input_chars": len(llm_input),
        "recent_turn_count": len(input_context["recent_conversation"]),
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cached_input_tokens": cached_input_tokens,
    }
    return parsed, {
        "status": response_status,
        "provider": provider,
        "model": model_name,
        "service_tier": service_tier,
        "timings_ms": classifier_timings,
        "instructions": instructions,
        "input": input_context,
        "response_format": response_format,
        "output_raw": output_text,
        "output_parsed": parsed,
    }


async def transcribe_browser_audio(audio: bytes, content_type: str = "audio/webm") -> str:
    """Transcribe a browser-recorded turn with the configured speech provider."""
    if voice_provider_name() == "sarvam":
        if not settings.sarvam_api_key:
            raise RuntimeError("SARVAM_API_KEY is not configured")
        async with httpx.AsyncClient(timeout=45.0) as client:
            response = await client.post(
                "https://api.sarvam.ai/speech-to-text",
                headers={"api-subscription-key": settings.sarvam_api_key},
                data={"model": settings.sarvam_stt_model, "mode": settings.sarvam_stt_mode},
                files={"file": ("customer-turn.webm", audio, content_type)},
            )
            response.raise_for_status()
        return response.json().get("transcript", "").strip()
    if not settings.deepgram_api_key:
        raise RuntimeError("DEEPGRAM_API_KEY is not configured")
    query = urlencode([
        ("model", settings.deepgram_stt_model), ("language", "multi"),
        ("language_hint", "en-IN"), ("language_hint", "hi"), ("smart_format", "true"),
    ])
    async with httpx.AsyncClient(timeout=45.0) as client:
        response = await client.post(
            f"{settings.deepgram_api_base_url}/v1/listen?{query}",
            headers={"Authorization": f"Token {settings.deepgram_api_key}", "Content-Type": content_type},
            content=audio,
        )
        response.raise_for_status()
    result = response.json()
    return result.get("results", {}).get("channels", [{}])[0].get("alternatives", [{}])[0].get("transcript", "").strip()


async def stream_browser_audio(text: str):
    """Yield configured-provider audio chunks and timing for progressive playback."""
    if voice_provider_name() == "sarvam":
        if not settings.sarvam_api_key:
            raise RuntimeError("SARVAM_API_KEY is not configured")
        started = perf_counter()
        query = urlencode({"model": settings.sarvam_tts_model, "send_completion_event": "true"})
        url = f"wss://api.sarvam.ai/text-to-speech/ws?{query}"
        first_audio_ms = None
        async with websocket_connect(
            url,
            extra_headers={"api-subscription-key": settings.sarvam_api_key},
            open_timeout=15,
            close_timeout=3,
            ping_interval=20,
            max_size=2_000_000,
        ) as socket:
            await socket.send(json.dumps({
                "type": "config",
                "data": {
                    "language_code": "en-IN",
                    "speaker": settings.sarvam_tts_speaker,
                    "speech_sample_rate": 24000,
                    "output_audio_codec": "mp3",
                    "pace": 1.0,
                    "enable_preprocessing": True,
                },
            }))
            await socket.send(json.dumps({"type": "text", "data": {"text": text}}))
            await socket.send(json.dumps({"type": "flush"}))
            yield ("format", "audio/mpeg", None, None)
            async for message in socket:
                if isinstance(message, bytes):
                    chunk = message
                    event = None
                else:
                    try:
                        event = json.loads(message)
                    except (TypeError, ValueError):
                        continue
                    if event.get("type") == "error":
                        raise RuntimeError("Sarvam TTS streaming failed")
                    if event.get("type") == "audio":
                        audio_data = event.get("data", {}).get("audio")
                        if not audio_data:
                            continue
                        chunk = base64.b64decode(audio_data)
                    else:
                        chunk = None
                if chunk:
                    if first_audio_ms is None:
                        first_audio_ms = round((perf_counter() - started) * 1000, 1)
                        yield ("first_audio", chunk, first_audio_ms, None)
                    else:
                        yield ("audio", chunk, None, None)
                    continue
                if event and event.get("type") == "event" and event.get("data", {}).get("event_type") == "final":
                    total_ms = round((perf_counter() - started) * 1000, 1)
                    yield ("done", None, first_audio_ms, total_ms)
                    break
        return
    if not settings.deepgram_api_key:
        raise RuntimeError("DEEPGRAM_API_KEY is not configured")
    started = perf_counter()
    query = urlencode({
        "model": _BROWSER_TTS_MODEL,
        "encoding": "linear16",
        "sample_rate": 24000,
        "mip_opt_out": "true",
    })
    url = f"{settings.deepgram_api_base_url.replace('https://', 'wss://').replace('http://', 'ws://')}/v2/speak?{query}"
    first_audio_ms = None
    async with websocket_connect(
        url,
        extra_headers={"Authorization": f"Token {settings.deepgram_api_key}"},
        open_timeout=15,
        close_timeout=3,
        ping_interval=20,
        max_size=2_000_000,
    ) as socket:
        await socket.send(json.dumps({"type": "Speak", "text": text}))
        await socket.send(json.dumps({"type": "Flush"}))
        async for message in socket:
            if isinstance(message, bytes):
                if first_audio_ms is None:
                    first_audio_ms = round((perf_counter() - started) * 1000, 1)
                    yield ("first_audio", message, first_audio_ms, None)
                else:
                    yield ("audio", message, None, None)
                continue
            try:
                event = json.loads(message)
            except (TypeError, ValueError):
                continue
            if event.get("type") == "Error":
                raise RuntimeError("Deepgram streaming TTS failed")
            if event.get("type") == "SpeechMetadata":
                total_ms = round((perf_counter() - started) * 1000, 1)
                yield ("done", None, first_audio_ms, total_ms)
                break
