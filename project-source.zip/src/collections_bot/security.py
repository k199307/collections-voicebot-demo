from __future__ import annotations

import hmac
from functools import lru_cache

from fastapi import HTTPException

from .config import settings


@lru_cache(maxsize=1)
def _jwks_client():
    import jwt

    if not settings.oidc_jwks_url:
        raise RuntimeError("OIDC_JWKS_URL is required when AUTH_MODE=oidc")
    return jwt.PyJWKClient(settings.oidc_jwks_url, cache_keys=True)


def _authorize_oidc(token: str, admin_only: bool) -> str:
    import jwt

    if not all((settings.oidc_issuer, settings.oidc_audience, settings.oidc_jwks_url)):
        raise HTTPException(status_code=503, detail="oidc_not_configured")
    try:
        key = _jwks_client().get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            audience=settings.oidc_audience,
            issuer=settings.oidc_issuer,
            leeway=30,
            options={"require": ["exp", "iat", "sub"]},
        )
    except Exception as exc:
        raise HTTPException(status_code=401, detail="invalid_access_token") from exc
    roles = claims.get("roles", [])
    if isinstance(roles, str):
        roles = [roles]
    if "mock-bank-admin" in roles:
        return str(claims["sub"])
    if not admin_only and "collections-service" in roles:
        return str(claims["sub"])
    raise HTTPException(status_code=403, detail="insufficient_scope")


def authorize(authorization: str | None, *, admin_only: bool = False) -> str:
    """JWT role validation in production; separate static service/admin tokens for local demos."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="bearer_token_required")
    presented = authorization[7:]
    if settings.app_env == "production" and settings.auth_mode != "oidc":
        raise HTTPException(status_code=503, detail="production_requires_oidc_auth")
    if settings.auth_mode == "oidc":
        return _authorize_oidc(presented, admin_only)
    if settings.auth_mode != "static":
        raise HTTPException(status_code=503, detail="unsupported_auth_mode")
    admin_token = settings.mock_bank_admin_token
    service_token = settings.collections_api_token
    if admin_token and service_token and hmac.compare_digest(admin_token, service_token):
        raise HTTPException(status_code=503, detail="service_and_admin_tokens_must_differ")
    if admin_token and hmac.compare_digest(presented, admin_token):
        return "mock-bank-admin"
    if not admin_only and service_token and hmac.compare_digest(presented, service_token):
        return "collections-service"
    raise HTTPException(status_code=403, detail="insufficient_scope")
