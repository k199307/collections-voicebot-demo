# Collections voice agent — project history and test coverage

**Review period:** 1–3 November 2026  
**Purpose:** Record the major product improvements, scenario work, measured results, and remaining gaps from our conversation.

> The version names below are retrospective milestones for this document; they are not formal Git releases. The day-by-day grouping follows the conversation and dated artifacts. Ideas are distinguished from implemented behavior and tested results.

## 1. Version history

| Version | Date | Name | Marked improvements and status |
|---|---|---|---|
| **V0.1** | **1 Nov** | **Collections domain blueprint** | **Designed.** Broadened the model from four systems to customer identity, accounts/cards, delinquency episodes, payment/reconciliation, contact points and contact policy, CRM, offers, audit, human follow-up, and outcome tracking. Joint accounts excluded from scope. Chose an account-level collection workflow with a recorded resolution outcome. |
| **V0.2** | **1 Nov** | **Browser voice MVP** | **Built as an assignment prototype.** Added the STT → interpretation → policy → TTS path, mock bank OTP and payment-reconciliation integrations, human follow-up/transfer outcomes, persistence, access controls, and browser-based testing. Twilio was later removed from the demo path at the user’s direction. |
| **V0.3** | **2 Nov** | **Stateful, policy-controlled conversation** | **Iterated from observed failures.** Added an explicit identity state, response contract and validation, context-sensitive dialogue acts, protected balance checks, payment-date/mode retention, payment-age handling, formal opt-out, and deterministic safety/escalation rules. The LLM interprets and acknowledges; policy selects the permitted response/action. |
| **V0.4** | **2 Nov** | **Voice diagnostics and Indian speech stack** | **Added and exercised.** Added Sarvam as a selectable speech provider, selected the Sunny English voice, retained Deepgram as an alternative, preserved the whole transcript, added call and mic-only audio downloads, and exposed rule triggers, LLM input/output, and per-step latency in the “Under the hood” console. |
| **V0.5** | **3 Nov** | **Scenario suite and measured model choice** | **Evaluated.** Defined 30 customer scenarios, expanded them to 37 classifier utterances, ran policy and provider evaluations, and compared Gemini, Luna standard/Fast, Terra, Deepgram, and Sarvam. The live setting was then switched to **OpenAI `gpt-6-luna`, Fast**, with Sarvam voice services retained. |

## 2. Product and architecture improvements

### Domain and system boundaries

The model now distinguishes the key business records and systems:

- Customer identity and contact preferences; one customer may have multiple accounts. Joint accounts are out of scope.
- Card/account status, minimum due, due date, balance, and transactions.
- Delinquency episode, collection case/campaign, contact attempts, frequency rules, and dispositions.
- Customer-reported payment versus ledger-confirmed payment, reconciliation status, and human review.
- OTP challenge, contact opt-out, CRM/contact history, offer or waiver request, human follow-up task, and auditable outcome.

The architecture considered CRM, account/ledger, collection orchestration and policy, bank OTP/reconciliation APIs, offers, human-agent workflow, audit/metrics, and the voice UI. Assignment integrations are mocks; this is not yet a production bank integration or real outbound dialer.

### Current turn design

```mermaid
flowchart LR
    A[Browser microphone] --> B[Capture and VAD]
    B --> C[STT: Sarvam or Deepgram]
    C --> D[LLM: intent, dialogue act, stated fields, acknowledgment]
    D --> E[Deterministic policy and conversation state]
    E --> F[Validate acknowledgment and policy response]
    F --> G[TTS: Sarvam or Deepgram]
    G --> H[Playback and full transcript]
    E --> I[Rule trace, outcome, mock bank or human task]
```

The LLM does not decide whether to disclose a balance, honor an opt-out, record a commitment, waive a fee, or transfer a caller. It returns structured interpretation and a short English acknowledgment. Deterministic rules select the action and response; the acknowledgment is checked before use. This keeps one model call per turn and prevents generated wording from overriding policy.

### Behavioral changes emphasized in the conversation

- **Opening and identity:** say the bank and named person; an affirmative confirms identity only after the bot asks that named question. A pre-opening “yes” or name alone is not confirmation. Hindi/English affirmatives and short answers must be interpreted in the current dialogue state; partial names require clarification.
- **Due notice:** say that the minimum payment is overdue; state 3.5% monthly interest and a ₹750 late fee only when the outstanding balance is over ₹10,000. Begin with two choices: already paid or expected payment date. Do not ask for an amount.
- **Commitments:** tentative willingness is not a promise. Ask/confirm the date only, retain volunteered amounts without changing them, and record a commitment only after date confirmation.
- **Payments:** preserve exact versus approximate timing; keep date and mode across turns. Within two days, explain the two-working-day posting window. For a payment more than one calendar month old, ask whether it is the most recent; “yes,” uncertainty, or “I don’t know” goes to human review, while “no” asks for the newer date.
- **Related and unsupported questions:** answer tangential questions about the overdue payment only from approved facts. Refer unsupported payment methods/extensions to a human. Record payment-link and fee-waiver requests for a colleague; do not claim completion or approve a waiver.
- **Protection and escalation:** OTP only follows an explicit protected-balance request and is keypad-only. Stop the pitch for dispute, medical emergency, serious hardship/job loss, or abuse. Record opt-outs and end collection contact. Never predict CIBIL, provide legal advice, or threaten legal action; route other products to a branch/helpline.
- **Natural close:** summarize what was recorded, explain any pending ledger check or human follow-up, thank the caller, then close politely.
- **Voice and observability:** English bot voice with Hindi/English customer input; full transcript remains visible. Browser downloads include complete call audio and mic-only WAVs. “Under the hood” shows LLM inputs/outputs, policy rules, response source, and timings for STT, LLM, TTS, API, and browser round trip.

## 3. Scenario work by day

| Date | Scenarios explored or formalized | What the work surfaced |
|---|---|---|
| **1 Nov — scope and design** | Identity/account association; one customer with multiple accounts; overdue payment; paid vs. not paid; payment commitment; callback; balance/OTP; offers/discounts; frequency rules; CRM/audit; human-agent path. | Established entities, system boundaries, and the desired call outcomes. These were design scenarios, not a scored live run. |
| **2 Nov — manual browser/audio conversations** | Customer greeting before bot; “yes” before/after named identity; full/partial/wrong name; Hindi and code-switching; due notice; not paid/refusal/tentative commitment; small volunteered amount; exact and approximate paid dates; date and mode in separate turns; old payment/current-cycle confirmation; balance and OTP; interest/fee questions; unsupported payment method; payment link; waiver/discount; callback; dispute, job loss, medical emergency, abuse, opt-out, unrelated/product/CIBIL/legal questions. | Revealed repeated questions, weak one-word handling, Hindi/STT errors, amount/date corruption, identity loops, incorrect OTP triggers, generic acknowledgments, interruptions, high mic sensitivity, and slow turn latency. The user supplied audio clips to compare recognition with intent. |
| **3 Nov — scripted evaluation and provider comparison** | Formal 30-scenario suite (below), expanded to 37 classifier utterances; four supplied WAVs per STT provider; three fixed TTS phrases per provider; deterministic 15-case policy evaluation. | Measured classifier latency/labels, STT request times and observed hypotheses, TTS first-audio/completion times, and V1 vs. golden-intent policy results. This was component testing, not 30 complete end-to-end calls per provider combination. |

### Formal 30-scenario suite

The full scripts and pass criteria are in [`voice_agent_scenarios_30.md`](../tests/voice_agent_scenarios_30.md). Cases 29 and 30 contain several variants, giving 37 scored utterances for the classifier benchmark.

| # | Scenario | # | Scenario |
|---:|---|---:|---|
| 1 | Straightforward identity confirmation | 16 | Old payment was not the latest |
| 2 | Short affirmative (“Yeah, you are”) | 17 | Refusal followed by one-word reason (“Concern”) |
| 3 | Customer greets before bot opening | 18 | Tentative willingness is not a commitment |
| 4 | Pre-opening “yes” is not confirmation | 19 | Clear commitment date; no amount volunteered |
| 5 | Customer says full name before bot asks it | 20 | Customer volunteers a very small amount |
| 6 | Partial name only | 21 | Customer-estimated balance and fee threshold |
| 7 | Wrong person answers | 22 | Fee threshold boundary at exactly ₹10,000 |
| 8 | Hindi/English identity confirmation | 23 | Tangential interest question |
| 9 | Due notice, rate, fee, and two initial choices | 24 | Explicit balance request and OTP |
| 10 | Customer has not paid | 25 | OTP request without a balance request |
| 11 | Payment within two days | 26 | Unsupported payment process/method question |
| 12 | Approximate payment date | 27 | Payment-link request |
| 13 | Payment date and mode in separate turns | 28 | Late-fee waiver/discount request |
| 14 | Old payment confirmed as most recent | 29 | Job loss, medical emergency, abuse, and dispute variants |
| 15 | Old payment with uncertain answer | 30 | Opt-out, CIBIL/legal, other product, unrelated topic |

Other manual probes documented during 2 Nov include “Concern” heard as “And so on,” “Yes, you are” heard as “Yes, Shiva,” “net banking” heard as “Mumbai Bank,” the approximate-date/current-cycle loop, balance/OTP misrouting, greeting duplication, simultaneous speech, and background noise. These are observations, not all individually scored test cases.

## 4. Results as of 3 November

### Classifier benchmark — 37 utterances

| Profile | Exact labels | Mean request time | p95 | High-risk label errors |
|---|---:|---:|---:|---:|
| Gemini Flash Lite | 27/37 (73.0%) | 1.63 s | 2.14 s | 2 |
| OpenAI Luna standard | 33/37 (89.2%) | 1.99 s | 3.80 s | 0 |
| **OpenAI Luna Fast — selected** | **31/37 (83.8%)** | **1.54 s** | **1.83 s** | **0** |
| OpenAI Terra standard | 34/37 (91.9%) | 2.15 s | 2.41 s | 0 |

Luna Fast was selected for its lower response time, accepting a lower exact-label score than Terra in this small sample. Gemini’s main failure was confirming identity on a pre-opening “Yes” and unsolicited “I’m Asha Mehta”; other errors included treating “I think so” as a payment promise and “Concern” as distress. The deterministic identity gate remains necessary.

### Speech and policy measurements

- **STT:** four WAV probes/provider; mean request time was 174 ms for Deepgram and 194 ms for Sarvam. On the user-identified “Concern” clip, Deepgram returned blank and Sarvam returned “Pansan.” References are incomplete, so there is no aggregate accuracy score. Sarvam was in `translate` mode.
- **TTS:** three fixed responses/provider; mean first audio was 217 ms Deepgram and 234 ms Sarvam. Mean stream completion was 2.44 s and 0.92 s. No listener study for accent/naturalness was run.
- **Deterministic policy evaluator:** V1 fast-path baseline passed 11/15 (26.7% failure rate); V2 with expected/golden intents passed 14/15 (6.7% failure rate). V2 is a policy-path ceiling, not a live LLM score. Its remaining fixture failure was the payment-link case returning no response.
- In the limited policy fixtures, due facts, opt-out, distress/abuse transfer, dispute pause, and OTP protection passed. This does not establish broad live-response compliance. OpenAI had no incorrect labels among the 12 high-risk classifier cases; Gemini had two identity-label errors.

Detailed results: [`provider_matrix_report_2026-11-03.md`](../tests/provider_matrix_report_2026-11-03.md), [`provider_matrix_results_2026-11-03.json`](../tests/provider_matrix_results_2026-11-03.json), and [`assignment_eval_results.json`](../tests/assignment_eval_results.json).

## 5. Remaining gaps and next improvements

1. Add live regression coverage proving identity cannot be confirmed before the named question, including Gemini’s observed misclassification.
2. Build a larger labeled audio set for short replies, Hindi/code-switching, names, payment modes, accent variation, speakerphone, and background noise.
3. Score contextual dialogue acts and extracted slots—not just exact intent labels—for separate date/mode turns and old-payment yes/uncertain/no.
4. Fix and rerun the payment-link policy fixture.
5. Run full multi-turn audio conversations for each LLM × STT/TTS pairing; current provider results are component measurements.
6. Evaluate VAD, echo cancellation, barge-in, mic sensitivity, and voice naturalness with repeated user listening sessions.
7. Keep the final assignment write-up within its five-page limit, moving prompt versions and the full evaluation table to appendices. State clearly that bank APIs and agent transfer are mocked.

## 6. AI tools and decision ownership

Codex/ChatGPT supported architecture, implementation, debugging, scenario design, and result analysis. OpenAI Luna, OpenAI Terra, Gemini, Deepgram, and Sarvam were evaluated as runtime speech/language services. The user’s product decisions were to avoid amount solicitation, require a bot-asked identity question, keep English output with Hindi/English input, prefer state-aware behavior over phrase-only patches, remove Twilio from the browser demo path, preserve the full transcript/audio, and choose Luna Fast for latency despite Terra’s higher score in this sample.

## Source artifacts

- [`TEST_PLAN.md`](../tests/TEST_PLAN.md) — broader manual and automated acceptance plan.
- [`test_conversation.py`](../tests/test_conversation.py) and [`assignment_eval.py`](../tests/assignment_eval.py) — policy tests/evaluator.
- [`run_provider_matrix.py`](../tests/run_provider_matrix.py) and [`retry_gemini_matrix.py`](../tests/retry_gemini_matrix.py) — provider benchmark runners.
